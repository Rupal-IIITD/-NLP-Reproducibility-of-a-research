Repro Data Editor
by Zuoming Shi
Last Updated: 8/13/13

PURPOSE: This is a Java GUI interface for editing data.txt files used in the reproducibility project.

USAGE: use the BROWSE button to navigate to the folder containing the paper's pdf file and data.txt
and open the pdf file. The pdf file will be opened in the operating system, and any existing information
in data.txt will be filled out to the editor, assuming data.txt is formated correctly. Fill in all other
fields and click SAVE to save changes to data.txt. A backup of the prior data.txt will be saved as
data.txt1, data.txt2... etc.
Note that for emails to be added, "+" must be pressed once for each email. Use "C" to clear the 
current list of emails.
The AUTO feature automatically inputs the number of minutes elapsed since the last opening of a file
or pressing of the AUTO button. Use this button if you wish the program to automatically track 
analysis time.

ASSUMPTIONS: a data.txt exists in the same directory as the pdf file. The data.txt is formated relatively
well (no tags are deleted or changed, the input to the fields are space-seperated from the tags, fields
that are instructed to be underscore-seperated in the tags are in fact underscore-seperated in data.txt).
The user has permission to read the pdf file and edit the data.txt files.

NOTE: The functionality of the editor is not currently tested in Mac OSX, feedback would be appreciated.

UPDATE LOG:

8/13/13
-support for new data.txt fields
-fixed bug regarding shuffle function of names
-the name input field now automatically parses names with dash inside
-now automatically inserts underscore when a space is enountered in a inputted name.

8/8/13
-support for new data.txt fields

7/16/13
-minor bug fixes

7/14/13
-Support for new data.txt
-Rearranged panels for better workflow
-Added a shuffle button that will move the last email/author name on a list to the top. For name-email matching purposes.

6/4/13
-Updated to reflect recent changes to data.txt
-Added collapse and expand buttons for two sides.
-Added a new skin that requires less room than the default skin.
-Clicking on a radio button will not deselect the button.

5/30/13
-Added error messages
-Added Email parsing that ignores seperating commas. However, it does not forcibly change data.txt yet.
-Reports warnings if the analyzer name field is filled-out, but other required fields are empty
	-This currently works for ANALYSIS_TIME, COMMERCIAL_EFFORT, ARTICLE_STATUS, GRANT_SUPPORT, and
	LINK fields for ARTICLE. But EMAIL:STATUS and BUILD_STATUS does not have this function yet, since
	I'm unsure if these fields should be required.

5/29/13
-Fixed the fix automatic name input not working bug
-Error log now (really) automatically scrolls to the bottom.

5/28/13
-Fix automatic name input not working bug
-Error log now automatically scrolls to the bottom.
	
5/27/13
-Automatic retention of analyzer name when relevant.
-Email clear button now only clears the last email address in the text area.
-Larger email text field.
-Got rid of unncessesary warning messages in the error log area.
-Clicking on the grant bar will now set the grant button to "yes" automatically.
-The autofill option with no implementaion and no link buttons are now no longer strictly enforced onto
	the user.
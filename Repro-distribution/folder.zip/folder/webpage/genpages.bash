
#!/bin/bash
arg_list=( "asplos12" "ccs12" "oopsla12" "osdi12" "pldi12" "sigmod12" "sosp11" "taco9" "tissec15" "tocs30" "tods37" "toplas34" "vldb12" "ALL")

for conf in ${arg_list[@]}
do
	echo "Generating html for $conf"
	html='
	<!DOCTYPE HTML>
	<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Repro Project Status Webpage</title>
		<LINK href="style.css" rel="stylesheet" type="text/css">
	</head>
		<div id="content">
			<h1>'$conf'</h1>
			<P id=txt>Link Sources Chart (Non-theoretical only)</P>
			<br/>
			<img id="bar" src = "data/bar/'$conf'-bar.png" alt = "bar chart here">
			<br/>

			<P id=txt>Build Progress Chart</P>
			<br/>
			<img id="pie" src = "data/pie/'$conf'-pie.png" alt = "pie chart here">

			<P id=txt>Build Progress Chart (Non-theoretical only)</P>
			<br/>
			<img id="pie" src = "data/pie_greyless/'$conf'-pie-greyless.png" alt = "pie chart here">
			<div id="lnk">
				<a id="mainlink" href="MAIN.html">BACK</a>
			</div>
			<br/>
		</div>
	</html>'
	echo "$html" > "$conf"".html"
done
import java.util.ArrayList;

// Author: Alex Warren
// Description: program that goes through all the conferences and generates an email list
//              that excludes duplicate emails to the same person. Finally it makes small
//              scripts for each email message to be sent.
public class MakeEmailerScripts {

	public static void main(String[] args) {
		ArrayList<String> conferences = new ArrayList<String>();
		for (String arg : args){
			if (arg.charAt(0) == '-'){
				
			}else{
				if (arg.equals("all")){
					conferences.add("asplos12");
					conferences.add("ccs12");
					conferences.add("oopsla12");
					conferences.add("osdi12");
					conferences.add("sigmod12");
					conferences.add("sosp11");
					conferences.add("taco9");
					conferences.add("tissec15");
					conferences.add("tocs30");
					conferences.add("tods37");
					conferences.add("toplas34");
					conferences.add("vldb12");
				}else{
					conferences.add(arg);
				}
			}
		}
		//Now that the arguments are parsed time to start the sequence
	}
}

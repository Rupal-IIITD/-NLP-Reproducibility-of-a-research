
public class FirstEmailManager {
	
	public boolean ShouldRecieve(Model m){
		return false;
	}
	
	public String makeMessage(Model m){
		String email = "";
		return email;
	}
}


public class Reverifier {
	
	public static void main(String args[]){
		if(args.length == 0){System.out.print("Too few arguements. Usage: java -jar Reverify [filename]");System.exit(1);}
		if(args.length == 1){
			Controller c = new Controller(false);
			if(!c.read(args[0])){System.out.println("Read failed, exiting with status of 1.");System.exit(1);}
			Model m = c.model;
			if(!m.comment.trim().isEmpty()){m.comment = m.name + ": " + m.comment;
				if(!m.verify_comment.trim().isEmpty()){m.comment = m.comment.concat(" | ");}
			}
			if(!m.verify_comment.trim().isEmpty()){
				m.comment = m.comment.concat(m.verify_name + ": " + m.verify_comment);
			}
			m.name = m.verify_name;
			if(m.verify_status.equals("unknown") ||
				m.verify_status.equals("needed") ||
				m.verify_status.equals("started")){
				m.progress = "not_finished";
			}
			if(m.verify_status.equals("finished") ||
					m.verify_status.equals("not_needed")){
					m.progress = "finished";
			}
			m.verify_name = "";
			m.verify_comment = "";
			m.verify_status = "";
			
			if(!c.save(args[0], c.model)){System.out.println("Write failed, exiting with status of 1.");System.exit(1);}
			System.out.println("done");
		}
		if(args.length >=2){System.out.print("Too many arguements. Usage: java -jar Reverify [filename]");System.exit(1);}
	}
	
}

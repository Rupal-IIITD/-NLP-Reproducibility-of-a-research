import java.util.ArrayList;

public class CopyOfModel {
	
	public String name="";
	public String dir="";
	public int time = 0;
	public ArrayList<String> emails = new ArrayList<String>();
	public String link="";
	public String comment="";
	public String commercial="";
	public String implementation="";
	public String progress="";
	public String result="";
	public String grant="";
	public String parsedString = "";
	public String tool_name="";
	public String tool_link="";
	public String link_found="";
	public String verify_name="";
	public String verify_status="";
	public String verify_comment="";
	public String build_status="";
	public String email_status="";
	public boolean build_download = false;
	public boolean build_compiles = false;
	public boolean build_runs = false;
	public boolean email_needed = false;
	public boolean email_request_1 = false;
	public boolean email_response_1 = false;
	public boolean email_sent_thank_you = false;
	public String build_name="";
	public int build_time=0;
	public String build_comment="";
	public String bibtex_link="";
	public String bibtex_label="";
	
	public CopyOfModel(){
		 ArrayList<String> emails = new ArrayList<String>();
	}
	
	public void print(){
		System.out.println(reconstructString());
	}
	
	public String reconstructString(){
		parsedString = "";
		parsedString=parsedString.concat("ARTICLE:ANALYSIS_BY[name] "+name+"\n");
		
		if(time>0)
			parsedString=parsedString.concat("ARTICLE:ANALYSIS_TIME[minutes] "+time+"\n");
		else
			parsedString=parsedString.concat("ARTICLE:ANALYSIS_TIME[minutes] "+"\n");
		
		parsedString=parsedString.concat("ARTICLE:COMMENT[string] "+comment+"\n");
		parsedString=parsedString.concat("ARTICLE:COMMERCIAL_EFFORT[none,part,full] "+commercial+"\n");
		parsedString=parsedString.concat("ARTICLE:GRANT_SUPPORT[none or string] "+grant+"\n");
		parsedString=parsedString.concat("ARTICLE:IMPLEMENTATION_EXISTS[unknown,yes,no] " +implementation+"\n");
		parsedString=parsedString.concat("ARTICLE:LINK[url] "+link+"\n");
		parsedString=parsedString.concat("ARTICLE:STATUS[one of {not_started,started,finished} and one of {broken_link,no_link,found_link}] "+progress+" "+result+"\n");
		parsedString=parsedString.concat("AUTHOR:EMAIL_REAL[list of strings] ");
		for(String s: emails){
			parsedString=parsedString.concat(s+" ");}
		parsedString=parsedString.concat("\n");
		parsedString=parsedString.concat("BIBTEX:LABEL[string] "+bibtex_label+"\n");
		parsedString=parsedString.concat("BIBTEX:LINK[url] "+bibtex_link+"\n");
		parsedString=parsedString.concat("BUILD:ANALYSIS_BY[name] "+build_name+"\n");
		if(build_time>0)
			parsedString=parsedString.concat("BUILD:ANALYSIS_TIME[minutes] "+build_time+"\n");
		else
			parsedString=parsedString.concat("BUILD:ANALYSIS_TIME[minutes] "+"\n");
		parsedString=parsedString.concat("BUILD:COMMENT[string] "+build_comment+"\n");
		parsedString=parsedString.concat("BUILD:STATUS[one of {unknown,needed,not_needed,started,finished} and list of {downloaded,compiles,runs}] "+build_status+" ");
		if(build_download)parsedString=parsedString.concat("downloaded ");
		if(build_compiles)parsedString=parsedString.concat("compiles ");
		if(build_runs)parsedString=parsedString.concat("runs ");
		parsedString=parsedString.concat("\n");
		parsedString=parsedString.concat("EMAIL:STATUS[unknown,not_needed or list of {needed,request_1,response_1,sent_thank_you}] "+email_status+" ");
		//if(email_needed)parsedString=parsedString.concat("needed ");
		if(email_request_1)parsedString=parsedString.concat("request_1 ");
		if(email_response_1)parsedString=parsedString.concat("response_1 ");
		if(email_sent_thank_you)parsedString=parsedString.concat("sent_thank_you ");
		parsedString=parsedString.concat("\n");
		parsedString=parsedString.concat("PI:COMMENT_CC[string] "+"\n");
		parsedString=parsedString.concat("PI:COMMENT_TP[string] "+"\n");
		parsedString=parsedString.concat("TOOL:LINK[url] "+tool_link+"\n");
		parsedString=parsedString.concat("TOOL:LINK_FOUND[no,article,google,email] "+ link_found +"\n");
		parsedString=parsedString.concat("TOOL:NAME[string] "+tool_name+"\n");
		parsedString=parsedString.concat("VERIFY:ANALYSIS_BY[name] "+verify_name+"\n");
		parsedString=parsedString.concat("VERIFY:STATUS[unknown,needed,not_needed,started,finished] "+verify_status+"\n");
		parsedString=parsedString.concat("VERIFY:COMMENT[string] "+verify_comment);
		
		return parsedString;
	}
}

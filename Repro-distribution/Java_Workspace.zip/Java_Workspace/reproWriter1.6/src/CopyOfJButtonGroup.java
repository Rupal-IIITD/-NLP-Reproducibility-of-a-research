import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.ButtonGroup;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class CopyOfJButtonGroup extends JPanel{

	public ButtonGroup bg = new ButtonGroup();
	public ArrayList<JRadioButton> buttonArray = new ArrayList<JRadioButton>();
	public JPanel radioPanel = new JPanel(new GridLayout(0, 1, 0, 0));
    //public JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
	
    public CopyOfJButtonGroup(){
		super();
		this.add(radioPanel);
    }
	
	public void add(JRadioButton jc){
		radioPanel.add(jc);
		buttonArray.add(jc);
		bg.add(jc);
	}
	
	public void add_label(JLabel jc){
		radioPanel.add(jc);
	}
	
	public JRadioButton getSelection(){
		for(JRadioButton jrb:buttonArray){
			//System.out.print("test"+jrb.getText());
			if(jrb.isSelected()){return jrb;}
		}
		return null;
	}
}

import java.io.File;
import java.util.ArrayList;


public class ModelLoader {

	private ArrayList<Model> modelList;
	private String fullConfAddress;
	
	public static void main(String[] args){
		if(args.length != 2){System.out.print("Incorrect arguement count. Usage: java -jar Loader REPRO_DIRECTORY CONF_NAME ");System.exit(1);}
		else{
			new ModelLoader(args[0], args[1]);
		}
	}
	
	public ModelLoader(String _repro, String _conf){
		int paperCount = 0;
		modelList = new ArrayList<Model>();
		
		//Concatenates a file separator if one is not given in the user input
		if(_repro.substring(_repro.length()-1) != File.separator){
			_repro = _repro.concat(File.separator);
		}
		//Creates full conference address from the repro address and the conference name
		String fullConfAddress = _repro.concat(_conf);

		File folder = new File(fullConfAddress);
		File[] listOfFiles = folder.listFiles();
		for(int i = 0; i < listOfFiles.length; i++) {
			if (listOfFiles[i].isDirectory()){
				//System.out.println("Directory " + listOfFiles[i].getName());
				File paperFolder = listOfFiles[i].getAbsoluteFile();
				
				//It is possible to add check if "data.txt exists in the paper folder here. But it is assumed to be true."
				String paperAddress = paperFolder.getAbsolutePath().concat(File.separator).concat("data.txt");
				
				/*Start Controller to create a model for that data.txt from its address. The true turns on quiet mode to
				  Suppress warnings and errors.*/
				Controller c = new Controller(true);
				c.read(paperAddress);
				paperCount++;
				
				//As a check, print out the valid emails listed in the email_real field of that paper.
				System.out.print(paperCount + ": ");
				modelList.add(c.model);
				for(String email: c.model.emails){
					System.out.print(email+" ");
				}
				System.out.println();
				
			}else if (listOfFiles[i].isFile()) {
				System.out.println("Warning: File " + listOfFiles[i].getName() + " should not be in a conference directory.");
			} 
		}
		
		System.out.println("\n" + paperCount + " papers loaded.");
	}
	
}

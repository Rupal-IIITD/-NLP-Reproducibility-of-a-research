import java.io.File;
import java.util.ArrayList;
import java.util.regex.Pattern;

public class FirstEmailManager implements EmailManager {
	public static final String identifier = "batch_3";

	public boolean ShouldRecieve(Model m) {
		return (m.email_status.equals("needed"));
	}

	public String makeMessage(Model m) {
		String message="";
		String first_email = m.emails.get(0);
		String cc = "";
		for (int ii = 1; ii < m.emails.size(); ii++) {
			cc = cc + "," + m.emails.get(ii);
		}
		String cc_emails = cc;
		cc = (cc.length() > 1) ? "-cc '"+cc.substring(1)+"'" : "";
		// m.title
		String title = m.title;
		int next_space = m.title.indexOf(' ', 50);
		if (next_space>49){
			StringBuilder tmp = new StringBuilder(m.title);
			//tmp.setCharAt(next_space, '\n');
			tmp.replace(next_space, next_space+1, "\n   ");
			title = tmp.toString();

		}else{
			title = m.title;
		}
		//System.out.println("break title:\n"+title);
		String[] first_author = m.authors.get(0).split("_");
		String first_author_last = first_author[first_author.length - 1];
		//m.jrn_conf
		
		//For sample
		//m.dir = "<<<Directory of data.txt>>>";
		//first_author_last = "<<<First Author Last Name>>>";
		//m.jrn_conf= "<<<Journal or Conference>>>";
		//m.title= "<<<Paper Title>>>";
		//cc= "<<<-cc 'other emails' or nothing>>>";
		//first_email= "<<<First Author Email>>>";
		
		//Check for problem characters
		Pattern bash_confusor = Pattern.compile("[\"'$]");
		if(bash_confusor.matcher(m.dir).find()){
			System.out.println("BAD_SYMBOL_AT: "+m.dir);
		}
		if(bash_confusor.matcher(first_author_last).find()){
			System.out.println("BAD_SYMBOL_AT: "+first_author_last);
		}
		if(bash_confusor.matcher(cc_emails).find()){
			System.out.println("BAD_SYMBOL_AT: "+cc_emails);
		}
		if(bash_confusor.matcher(first_email).find()){
			System.out.println("BAD_SYMBOL_AT: "+first_email);
		}
		
		if (!m.christain_knows.contains(first_email)) {
			// Christian doesn't know the authors
			message = "########################################################\n#Script_in "+m.dir+"\nverified=false\nsent=false\n\nif [[ \"$verified\" != \"true\" ]]; then\n  echo \"Email not sent because was not verified\"\n  exit 1\nfi\nif [[ \"$sent\" != \"false\" ]]; then\n  echo \"Email not sent because \\\"already sent\\\" parameter is not set to false\"\n  exit 1\nfi\n\n"
						+"MESSAGE=\"$(cat <<\\ENDHEREDOC\nDear Dr. "+first_author_last+",\n\nIQUOTEve been looking at your "+m.jrn_conf.replaceAll("'", "QUOTE")+" paper\n   "+title.replaceAll("'", "QUOTE")+"\nand would like to try out the implementation. However,\nI havenQUOTEt been able to find it online. Would you please\nlet me know how I can obtain the source code so that I\ncan try to build and run it?\n\nThank you very much for your help!\n\nChristian Collberg\nccollberg@gmail.com\nDepartment of Computer Science\nUniversity of Arizona\n"
						+"ENDHEREDOC\n)\"\n\nMESSAGE=\"`echo \"$MESSAGE\" | sed s/QUOTE/\\'/g`\"\n\necho \"$MESSAGE\" | \\\n$1 -V -tls -smtp-auth login -smtp-server smtp.gmail.com \\\n-smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \\\n$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name \"Christian Collberg\" \\\n"
						+"-subject \"Your "+m.jrn_conf+" paper\" "+cc+" \\\n'"+first_email+"'\necho \"EXIT_CODE $?\"\n########################################################";
		} else {
			// Christian knows one or more of the authors
			message = "########################################################\n#Script_in "+m.dir+"\nverified=false\nsent=false\n\nif [[ \"$verified\" != \"true\" ]]; then\n  echo \"Email not sent because was not verified\"\n  exit 1\nfi\nif [[ \"$sent\" != \"false\" ]]; then\n  echo \"Email not sent because \\\"already sent\\\" parameter is not set to false\"\n  exit 1\nfi\n\n"
						+"MESSAGE=\"$(cat <<\\ENDHEREDOC\nHi!\nIQUOTEve was looking at your "+m.jrn_conf.replaceAll("'", "QUOTE")+" paper\n   "+title.replaceAll("'", "QUOTE")+"\nand IQUOTEm interested in trying out the implementation. I looked\naround on your website but wasnQUOTEt able to find it. Could you\nlet me know where I can find the source code so that I can\ntry to build and run it?\n\nThanks!\n\nChristian\n"
						+"ENDHEREDOC\n)\"\n\nMESSAGE=\"`echo \"$MESSAGE\" | sed s/QUOTE/\\'/g`\"\n\necho \"$MESSAGE\" | \\\n$1 -V -tls -smtp-auth login -smtp-server smtp.gmail.com \\\n-smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \\\n$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name \"Christian Collberg\" \\\n"
						+"-subject \"Your "+m.jrn_conf+" paper\" "+cc+" \\\n'"+first_email+"'\necho \"EXIT_CODE $?\"\n########################################################";
												
		}
		
		
		return message;
	}

	public String getIdentifier() {
		return identifier;
	}
}

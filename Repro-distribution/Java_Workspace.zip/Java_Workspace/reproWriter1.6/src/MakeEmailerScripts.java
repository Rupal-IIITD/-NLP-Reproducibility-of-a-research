import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Random;
import java.util.Scanner;

// Author: Alex Warren
// Description: program that goes through all the conferences and generates an email list
//              that excludes duplicate emails to the same person. Finally it makes small
//              scripts for each email message to be sent.
public class MakeEmailerScripts {
	public final static long RANDOM_SEED = 54684;

	public static void main(String[] args) {
		// Check proper usage
		if (args.length < 2) {
			printUsage();
			System.exit(1);
		}

		// Initialize variables
		ArrayList<String> conferences = new ArrayList<String>();
		String reproDirectory = "";
		ArrayList<Model> modelList = new ArrayList<Model>();
		int paperCount = 0;
		EmailManager emailManager = new FirstEmailManager();
		// ******************************************************************
		// Parse the arguments
		// ******************************************************************
		for (String arg : args) {
			if (reproDirectory.equals("")) {
				reproDirectory = arg; // the first argument should be the
										// directory
				continue;
			}
			if (arg.charAt(0) == '-') {

			} else {
				if (arg.equals("all")) {
					conferences.add("asplos12");
					conferences.add("ccs12");
					conferences.add("oopsla12");
					conferences.add("osdi12");
					conferences.add("pldi12");
					conferences.add("sigmod12");
					conferences.add("sosp11");
					conferences.add("taco9");
					conferences.add("tissec15");
					conferences.add("tocs30");
					conferences.add("tods37");
					conferences.add("toplas34");
					conferences.add("vldb12");
					conferences.add("vldb12_new");
				} else if (arg.equals("batch1")) {
					conferences.add("oopsla12");
					conferences.add("osdi12");
					conferences.add("pldi12");
					conferences.add("sosp11");
					conferences.add("tissec15");
					conferences.add("tocs30");
					conferences.add("vldb12");
				} else if (arg.equals("batch2")) {
					conferences.add("asplos12");
					conferences.add("ccs12");
					conferences.add("sigmod12");
					conferences.add("taco9");
					conferences.add("tods37");
					conferences.add("toplas34");
					conferences.add("vldb12_new");
				} else {
					conferences.add(arg);
				}
			}
		}

		// Generate the list of Authors that Christain knows
		HashSet<String> christian_knows = loadChristianKnows(reproDirectory);
		HashSet<String> recipient_list = loadPreviousBatch(reproDirectory);
		//HashSet<String> ignore_list = loadIgnoreList(reproDirectory);
		HashSet<String> ignore_list = new HashSet<String>();

		// ******************************************************************
		// Load the paper models
		// ******************************************************************
		// Concatenates a file separator if one is not given in the user input
		if (reproDirectory.substring(reproDirectory.length() - 1) != File.separator) {
			reproDirectory = reproDirectory.concat(File.separator);
		}

		/*
		 * Start Controller to create a model for that data.txt from its
		 * address. The true turns on quiet mode to Suppress warnings and
		 * errors.
		 */
		Controller c = new Controller(true);
		// loop through each conference and retrieve models
		for (Iterator<String> confIter = conferences.iterator(); confIter
				.hasNext();) {
			String currConf = confIter.next();
			// Creates full conference address from the repro address and the
			// conference name
			String currConfAddress = reproDirectory.concat(currConf);
			System.out.println("Loading papers in: " + currConfAddress);
			File folder = new File(currConfAddress);
			File[] listOfFiles = folder.listFiles();
			for (int i = 0; i < listOfFiles.length; i++) {
				if (listOfFiles[i].isDirectory()) {
					// System.out.println("Directory "
					// +listOfFiles[i].getName());
					File paperFolder = listOfFiles[i].getAbsoluteFile();

					// It is possible to add check if
					// "data.txt exists in the paper folder here. But it is assumed to be true."
					String paperAddress = paperFolder.getAbsolutePath()
							.concat(File.separator).concat("data.txt");
					String bibAddress = paperFolder.getAbsolutePath()
							.concat(File.separator).concat("paper.bib");
					// System.out.println(paperAddress);
					c.read(paperAddress);

					c.model.dir = currConf.concat(File.separator).concat(
							listOfFiles[i].getName());
					if (!emailManager.ShouldRecieve(c.model)) {
						// The paper should not recieve an email, no use adding
						// it
						// System.out.println(String.format("%-30s", c.model.dir
						// + ": ") + "EMAIL:STATUS isn't needed");
						continue; // Don't add to modelList
					}
					paperCount++;

					// As a check, print out the valid emails listed in the
					// email_real field of that paper.
					// System.out.print(String.format("%-30s", c.model.dir
					// +": "));
					// String author_s =
					c.model.title = BibtexParser.parseBibtex(
							BibtexParser.ARTICLE, "title",
							BibtexParser.loadBibtex(bibAddress));
					// c.model.authors = new
					// ArrayList<String>(Arrays.asList(author_s.split(" ")));

					// taco9 has seperate years so need to get year
					if (currConf.equals("taco9")) {
						c.model.year = BibtexParser.parseBibtex(
								BibtexParser.ARTICLE, "year",
								BibtexParser.loadBibtex(bibAddress));
					}

					setJrnConf(c.model);

					modelList.add(c.model);
					for (String email : c.model.emails) {
						// System.out.print(email + " ");
					}
					// System.out.println();

				} else if (listOfFiles[i].isFile()) {
					System.out.println("Warning: File "
							+ listOfFiles[i].getName()
							+ " should not be in a conference directory.");
				}
			} // Done looping through the conference
		} // Done looping through all the conferences

		// Place to Print List for Christian
		//printChristianCheckList(modelList);
		//System.exit(0);

		// Generate an exclusive list
		modelList = generateExclusiveList(modelList, recipient_list, ignore_list);
		System.out.println("Papers_needing_emails: " + paperCount);

		// Go through all the papers and make emails for them
		StringBuffer sender_script = new StringBuffer("#Sender script for "
				+ emailManager.getIdentifier() + "\n");
		// sender_script.append("");
		for (Iterator<Model> modelIter = modelList.iterator(); modelIter
				.hasNext();) {
			Model m = modelIter.next();
			// System.out.println(reproDirectory + m.dir + File.separator +
			// "es_" + emailManager.getIdentifier() + ".bash");

			m.christain_knows = new ArrayList<String>();
			//wasn't used for second batch
			
			Iterator<String> emailIter = m.emails.iterator();
			while (emailIter.hasNext()) {
				String email = emailIter.next();
				if (christian_knows.contains(email)) {
					m.christain_knows.add(email);
				}
			}
			//printChristianCheckList(modelList);
			//System.exit(0);
			writeScript(reproDirectory+m.dir+File.separator+"es_"+emailManager.getIdentifier()+".bash",emailManager.makeMessage(m));
			System.out.println("###########################################################");
			System.out.println(emailManager.makeMessage(m));
			System.out.println("###########################################################");
			// emailManager.makeMessage(m);
			sender_script.append("bash .." + File.separator + m.dir
					+ File.separator + "es_" + emailManager.getIdentifier()
					+ ".bash $1\nsleep 5\n");

		}
		System.out.println(sender_script.toString());
		// Write sender script
		writeScript(reproDirectory+"scripts"+File.separator+"send_email_"+emailManager.getIdentifier()+".bash",sender_script.toString());
	}

	private static HashSet<String> loadIgnoreList(String root_dir) {
		HashSet<String> ignore_list = new HashSet<String>();
		BufferedReader reader;
		String line;
		root_dir = root_dir + File.separator + "scripts" + File.separator
				+ "email" + File.separator + "ignore_list.txt";
		try {
			reader = new BufferedReader(new FileReader(root_dir));
			while ((line = reader.readLine()) != null) {
				ignore_list.add(line.toLowerCase());
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Error loading: " + root_dir);
			e.getStackTrace();
		}
		return ignore_list;
	}

	private static void setJrnConf(Model model) {
		String str = model.dir.split(File.separator)[0];
		if (str.equals("asplos12")) model.jrn_conf = "ASPLOS'12";
		else if (str.equals("ccs12")) model.jrn_conf = "CCS'12";
		else if (str.equals("oopsla12")) model.jrn_conf = "OOPSLA'12";
		else if (str.equals("osdi12")) model.jrn_conf = "OSDI'12";
		else if (str.equals("pldi12")) model.jrn_conf = "PLDI'12";
		else if (str.equals("sigmod12")) model.jrn_conf = "SIGMOD'12";
		else if (str.equals("sosp11")) model.jrn_conf = "SOSP'11";
		else if (str.equals("taco9")) model.jrn_conf = "TACO'" + model.year.substring(2);
		else if (str.equals("tissec15")) model.jrn_conf = "TISSEC'12";
		else if (str.equals("tocs30")) model.jrn_conf = "TOCS'12";
		else if (str.equals("tods37")) model.jrn_conf = "TODS'12";
		else if (str.equals("toplas34")) model.jrn_conf = "TOPLAS'12";
		else if (str.equals("vldb12")) model.jrn_conf = "VLDB'11";
		else if (str.equals("vldb12_new")) model.jrn_conf = "VLDB'11";
		else
			System.out.println("UNKNOWN DIR CONF/JOURN: " + str);

	}

	private static HashSet<String> loadChristianKnows(String root_dir) {
		HashSet<String> christian_knows = new HashSet<String>();
		BufferedReader reader;
		String line;
		root_dir = root_dir + File.separator + "scripts" + File.separator
				+ "email" + File.separator + "christian_knows_final.txt";
		try {
			reader = new BufferedReader(new FileReader(root_dir));
			while ((line = reader.readLine()) != null) {
				christian_knows.add(line.toLowerCase());
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Error loading: " + root_dir);
			e.getStackTrace();
		}
		return christian_knows;
	}
	
	private static HashSet<String> loadPreviousBatch(String root_dir) {
		HashSet<String> recipient_list = new HashSet<String>();
		BufferedReader reader;
		String line;
		String path = root_dir + File.separator + "scripts" + File.separator
				+ "email" + File.separator + "batch1_recipient_list.txt";
		try {
			reader = new BufferedReader(new FileReader(path));
			while ((line = reader.readLine()) != null) {
				recipient_list.add(line.toLowerCase());
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Error Loading: " + path);
			e.getStackTrace();
		}
		path = root_dir + File.separator + "scripts" + File.separator
				+ "email" + File.separator + "batch2_recipient_list.txt";
		try {
			reader = new BufferedReader(new FileReader(path));
			while ((line = reader.readLine()) != null) {
				recipient_list.add(line.toLowerCase());
			}
			reader.close();
		} catch (Exception e) {
			System.out.println("Error loading: " + path);
			e.getStackTrace();
		}
		return recipient_list;
	}

	@SuppressWarnings("unused")
	private static void printChristianCheckList(ArrayList<Model> modelList) {
		HashMap<String, String> emailMap = new HashMap<String, String>();
		for (Iterator<Model> modelIter = modelList.iterator(); modelIter
				.hasNext();) {
			Model m = modelIter.next();
			// System.out.println("FIRST_AUTHOR: "+m.authors.get(0)+" EMAIL_LIST "+m.emails.toString());
			for (String email : m.emails) {
				String email_list = emailMap.get(email);
				if (email_list == null) {
					emailMap.put(email, email + " " + m.authors.toString()
							+ " " + m.dir);
				} else {
					emailMap.put(email, email_list + "\n" + email + " "
							+ m.authors.toString() + " " + m.dir);
				}
			}
		}
		Iterator<String> allEmails = emailMap.keySet().iterator();
		int ii = 0;
		while (allEmails.hasNext()) {
			ii++;
			String key = allEmails.next();
			System.out.println(emailMap.get(key));
		}
		System.out.println("total emails listed: " + ii);
	}

	public static ArrayList<Model> generateExclusiveList(
			ArrayList<Model> modelList, HashSet<String> recipient_list, HashSet<String> ignore_list) {
		ArrayList<Model> finalList = new ArrayList<Model>();
		HashSet<String> emailSet = new HashSet<String>();
		int numDuplicates = 0;
		int numDuplicateEmail = 0;
		int numEmails = 0;
		boolean exclusive, ignore;
		Collections.shuffle(modelList, new Random(RANDOM_SEED)); // Make Random
		System.out.println("Generating an exclusive list");
		for (Iterator<Model> modelIter = modelList.iterator(); modelIter
				.hasNext();) {
			Model m = modelIter.next();
			exclusive = true;
			ignore = false;
			for (String email : m.emails) {
				email = email.toLowerCase();
				numEmails++;
				if (ignore_list.contains(email)){
					ignore = true;
					break;
				}
				if (emailSet.contains(email) || recipient_list.contains(email)) {
					// This email has already been used
					exclusive = false;
					numDuplicateEmail++;
				}
			}
			if (ignore){
				System.out.println("Ignore: " + m.dir);
			}else if (exclusive) {
				// its exclusive so put them in the map
				for (String email : m.emails) {
					email = email.toLowerCase();
					emailSet.add(email);
					System.out.println("New_Email: " + email);
				}
				finalList.add(m);
				System.out.println("EXCLUSIVE_PAPER: " + m.dir);
			} else {
				System.out.println("Duplicate_email_at: " + m.dir);
				numDuplicates++;
			}

		}
		//These stats are no longer accurate, with ignored emails - approximate
		System.out.println("Number_of_Duplicate_Emails: " + numDuplicateEmail);
		System.out.println("Number_of_Emails: " + numEmails);
		System.out
				.println("Number_of_Papers_With_Duplicates: " + numDuplicates);
		return finalList;

	}

	public static void writeScript(String path, String script) {
		PrintWriter writer;
		try {
			writer = new PrintWriter(path, "UTF-8");
		} catch (FileNotFoundException e) {
			System.out
					.println("ERROR: File not found esception when creating script at "
							+ path);
			e.printStackTrace();
			return;
		} catch (UnsupportedEncodingException e) {
			System.out.println("ERROR: Encoding not supported");
			e.printStackTrace();
			return;
		}
		writer.print(script);
		writer.close();

	}

	public static void printUsage() {
		System.out
				.print("Incorrect arguement count. Usage: java -jar Loader REPRO_DIRECTORY CONF_NAME ");
	}
}

import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;

public class JButtonGroup extends JPanel{

	public ButtonGroup bg = new ButtonGroup();
	public ArrayList<JRadioButton> buttonArray = new ArrayList<JRadioButton>();
	public JPanel radioPanel = new JPanel();
	public JLabel radioLabel = new JLabel();
	public JPanel labelPanel = new JPanel();
	private JRadioButton invisible_b;
	private JRadioButton previous_choice = null;

    public JButtonGroup(){
    	this(0, 1);
    }
    
	public JButtonGroup(int rows, int cols){
		super();
		//invisible_b = new JRadioButton("INVISIBLE");
		//buttonArray.add(invisible_b);
		
		//this.setBorder(BorderFactory.createEtchedBorder());
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		radioPanel.setAlignmentX(CENTER_ALIGNMENT);
		radioPanel.setLayout(new GridLayout(rows, cols));
    }
	
	public void add(JRadioButton jc){
		this.add(radioPanel);
		radioPanel.add(jc);
		buttonArray.add(jc);
		bg.add(jc);
		jc.setAlignmentX(CENTER_ALIGNMENT);
		jc.setMargin(null);
		//jc.setBorder(BorderFactory.createEtchedBorder());
	}
	
	public void add_label(JLabel jc){
		//add(jc);
		radioLabel = jc;
		this.add(labelPanel);
		labelPanel.setAlignmentX(CENTER_ALIGNMENT);
		labelPanel.add(jc);
		
	}
	
	public JRadioButton getSelection(){
		for(JRadioButton jrb:buttonArray){
			if(jrb.isSelected()){return jrb;}
		}
		return null;
	}
	
	public void setSelection(String name){
		for(JRadioButton jrb:buttonArray){
			if(jrb.getText().equals(name)){jrb.setSelected(true);return;}
		}
		return;
	}
	
	public ArrayList<JRadioButton> getButtons(){
		return buttonArray;
	}
	
	public void clearSelection(){
		for(JRadioButton jrb: buttonArray){
			jrb.setSelected(false);
		}
		bg.clearSelection();
		//invisible_b.setSelected(true);
	}
	
	public void setPreviousSelected(JRadioButton c){
		previous_choice = c;
	}
	
	public JRadioButton getPreviousSelected(){
		return previous_choice;
	}
}

/*
 * Author: Zuoming Shi
 * Last updated: 5/17/2013
 * Purpose: Reproducibility Data Writer: a Swing project used to edit
 * the contents of Data.txt files used to store reproducibility data
 * of various papers submitted to recent conferences.
 */

import java.awt.Color;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.BoxLayout;
import javax.swing.GroupLayout;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.border.LineBorder;
import javax.swing.text.DefaultCaret;
import javax.swing.UIManager.*;

public class View extends JFrame {

	private ArrayList<JButton> buttons;
	private static JTextField textField = new JTextField(10);  
	private JLabel article_l = new JLabel("Article");
	private JTextField article_f = new JTextField(10);
	private JLabel article_analyzer_name_l = new JLabel("Analysis by");
	private JTextField article_analyzer_name_f = new JTextField(10);
	private JLabel build_analyzer_name_l = new JLabel("Analysis by");
	private JTextField build_analyzer_name_f = new JTextField(10);
	private JLabel article_time_l = new JLabel("Analysis time");
	private JTextField article_time_f= new JTextField(2);
	private JLabel build_time_l = new JLabel("Analysis time");
	private JTextField build_time_f = new JTextField(2);
	private JLabel email_l = new JLabel("Email_Real ");
	private JTextField email_f = new JTextField(14);
	private JTextArea email_area = new JTextArea(6, 6);  
	private JScrollPane email_area_pane = new JScrollPane(email_area);
	private JTextArea log_area = new JTextArea(11, 20); 
	private JScrollPane log_area_pane = new JScrollPane(log_area);
	private JLabel grant_l = new JLabel("Grant");
	private JTextField grant_f = new JTextField(13);
	private JLabel article_link_l = new JLabel("Link");
	private JTextField article_link_f = new JTextField(10);
	private JLabel bibtex_label_l = new JLabel("Label");
	private JTextField bibtex_label_f = new JTextField(10);
	private JLabel bibtex_link_l = new JLabel("Link");
	private JTextField bibtex_link_f = new JTextField(10);
	private JLabel tool_article_link_l = new JLabel("Article Link");
	private JTextField tool_article_link_f = new JTextField(10);
	private JLabel tool_google_link_l = new JLabel("Google Link");
	private JTextField tool_google_link_f = new JTextField(10);
	private JLabel tool_email_link_l = new JLabel("Email Link");
	private JTextField tool_email_link_f = new JTextField(10);
	private JLabel tool_data_link_l = new JLabel("Data Link");
	private JTextField tool_data_link_f = new JTextField(10);
	//
	private JLabel article_NSF_l = new JLabel("NSF Grant");
	private JTextField article_NSF_f = new JTextField(10);
	private JLabel name_l = new JLabel("Author_Name");
	private JTextField name_f = new JTextField(14);
	private JTextArea name_area = new JTextArea(6, 6);  
	private JScrollPane name_area_pane = new JScrollPane(name_area);
	//
	private JLabel tool_name_l = new JLabel("Name");
	private JTextField tool_name_f = new JTextField(10);
	private JLabel article_comment_l = new JLabel("Comment");
	private JTextField article_comment_f = new JTextField(10);
	private JLabel build_comment_l = new JLabel("Comment");
	private JTextField build_comment_f = new JTextField(10);
	private JLabel verify_analyzer_name_l = new JLabel("Verified by");
	private JTextField verify_analyzer_name_f = new JTextField(10);
	private JLabel verify_comment_l = new JLabel("Comment");
	private JTextField verify_comment_f = new JTextField(10);
	

	private JLabel verify_build_analyzer_name_l = new JLabel("Verified by");
	private JTextField verify_build_analyzer_name_f = new JTextField(10);
	private JLabel verify_build_comment_l = new JLabel("Comment");
	private JTextField verify_build_comment_f = new JTextField(10);
	  
	private JButtonGroup grant_g = new JButtonGroup();
	private JRadioButton grant_yes_r = new JRadioButton("yes");
	private JRadioButton grant_no_r = new JRadioButton("no");

	private JButtonGroup commercial_g = new JButtonGroup(0, 1);
	private JRadioButton commercial_none_r = new JRadioButton("none");
	private JRadioButton commercial_part_r = new JRadioButton("part");
	private JRadioButton commercial_full_r = new JRadioButton("full");

	private JButtonGroup implementation_g = new JButtonGroup(0, 1);
	private JRadioButton implementation_unknown_r = new JRadioButton("unknown");
	private JRadioButton implementation_hardware_r = new JRadioButton("hardware");
	private JRadioButton implementation_yes_r = new JRadioButton("yes");
	private JRadioButton implementation_no_r = new JRadioButton("no"); 

	private JButtonGroup progress_g = new JButtonGroup(1, 2);
	private JRadioButton progress_not_finished_r = new JRadioButton("not_finished");
	private JRadioButton progress_finished_r = new JRadioButton("finished");

	private JButtonGroup result_g = new JButtonGroup();
	private JRadioButton result_found_link_r = new JRadioButton("found_link");
	private JRadioButton result_no_link_r = new JRadioButton("no_link");
	private JRadioButton result_broken_link_r = new JRadioButton("broken_link");
	
	private JButtonGroup email_radio_g = new JButtonGroup(0, 1);
	private JRadioButton email_unknown_r = new JRadioButton("unknown");
	private JRadioButton email_not_needed_r = new JRadioButton("not_needed");
	private JRadioButton email_not_found_r = new JRadioButton("not_found");
	private JRadioButton email_needed_r = new JRadioButton("needed");

	private JBoxGroup email_box_g = new JBoxGroup(0, 1);
	private JCheckBox email_request_1_x = new JCheckBox("request_1");
	private JCheckBox email_response_1_x = new JCheckBox("response_1");
	private JCheckBox email_sent_thank_you_x = new JCheckBox("sent_thank_you");

	private JButtonGroup build_radio_g = new JButtonGroup(2,3);
	private JRadioButton build_unknown_r = new JRadioButton("unknown");
	private JRadioButton build_not_needed_r = new JRadioButton("not_needed");
	private JRadioButton build_needed_r = new JRadioButton("needed");
	private JRadioButton build_started_r = new JRadioButton("started");
	private JRadioButton build_finished_r = new JRadioButton("finished");

	private JBoxGroup build_box_g = new JBoxGroup(1,3);
	private JCheckBox build_downloaded_x = new JCheckBox("downloaded");
	private JCheckBox build_compiles_x = new JCheckBox("compiles");
	private JCheckBox build_runs_x = new JCheckBox("runs");

	private JButtonGroup verify_radio_g = new JButtonGroup(0, 3);
	private JRadioButton verify_unknown_r = new JRadioButton("unknown");
	private JRadioButton verify_not_needed_r = new JRadioButton("not_needed");
	private JRadioButton verify_needed_r = new JRadioButton("needed");
	private JRadioButton verify_started_r = new JRadioButton("started");
	private JRadioButton verify_finished_r = new JRadioButton("finished");

	private JButtonGroup verify_build_radio_g = new JButtonGroup(0, 3);
	private JRadioButton verify_build_unknown_r = new JRadioButton("unknown");
	private JRadioButton verify_build_not_needed_r = new JRadioButton("not_needed");
	private JRadioButton verify_build_needed_r = new JRadioButton("needed");
	private JRadioButton verify_build_started_r = new JRadioButton("started");
	private JRadioButton verify_build_finished_r = new JRadioButton("finished");

	private JButtonGroup article_link_radio_g = new JButtonGroup(1, 0);
	private JRadioButton article_link_unknown_r = new JRadioButton("unknown");
	private JRadioButton article_link_none_r = new JRadioButton("none");
	private JRadioButton article_link_broken_r = new JRadioButton("broken");
	
	private JButtonGroup google_link_radio_g = new JButtonGroup(1, 0);
	private JRadioButton google_link_unknown_r = new JRadioButton("unknown");
	private JRadioButton google_link_none_r = new JRadioButton("none");
	private JRadioButton google_link_broken_r = new JRadioButton("broken");

	private JButtonGroup email_link_radio_g = new JButtonGroup(1, 0);
	private JRadioButton email_link_unknown_r = new JRadioButton("unknown");
	private JRadioButton email_link_none_r = new JRadioButton("sent_no_url");
	private JRadioButton email_link_broken_r = new JRadioButton("broken");
	private JRadioButton email_link_given_r = new JRadioButton("none");

	private JButtonGroup data_link_radio_g = new JButtonGroup(1, 0);
	private JRadioButton data_link_unknown_r = new JRadioButton("unknown");
	private JRadioButton data_link_none_r = new JRadioButton("none");
	private JRadioButton data_link_broken_r = new JRadioButton("broken");
	
	private Controller controller = new Controller();
	private JPanel articlePanel = new JPanel();
	private JPanel left = new JPanel();
	private JPanel middle = new JPanel();
	private JPanel right = new JPanel();
	
	private JPanel article_box = new JPanel();
	private JPanel analysis_time_box = new JPanel();
	private JPanel name_panel = new JPanel();
	private JPanel build_time_box = new JPanel();
	private JPanel email_field_panel = new JPanel();
	private JPanel name_field_panel = new JPanel();
	private JPanel email_status_panel = new JPanel();
	private JPanel email_panel = new JPanel();
	private JPanel build_field_panel = new JPanel();
	private JPanel build_status_panel = new JPanel();
	private JPanel build_panel = new JPanel();
	private JPanel bibtex_panel = new JPanel();
	private JPanel verify_panel = new JPanel();
	private JPanel verify_field_panel = new JPanel();
	private JPanel log_panel = new JPanel();
	private JPanel grant_box = new JPanel();
	private JPanel button_panel = new JPanel();
	private JPanel tool_panel = new JPanel();
	private JPanel tool_field_panel = new JPanel();
	  
	private JButton browse_b = new JButton("BROWSE");
	private JButton analysis_auto_b = new JButton("AUTO 1");
	private JButton build_auto_b = new JButton("AUTO 2");
	private JButton add_b = new JButton("+");
	private JButton clear_b = new JButton("C");
	private JButton add2_b = new JButton("+");
	private JButton clear2_b = new JButton("C");
	private JButton shuffle_b = new JButton("S");
	private JButton shuffle2_b = new JButton("S");
	private JButton browse2_b = new JButton("BROWSE");
	private JButton save_b = new JButton("SAVE");
	private JButton clear_all_b = new JButton("CLEAR ALL");
	private JButton exit_b = new JButton("EXIT");
	private JButton left_expand_b = new JButton("<");
	private JButton right_expand_b = new JButton(">");
	
	private ArrayList<JRadioButton> radios = new ArrayList<JRadioButton>();
	private ArrayList<JButtonGroup> radio_groups = new ArrayList<JButtonGroup>();
	private String dataDirectory = "";
	
	private Timer timer = new Timer();
	private int minutes=0;
	public ArrayList<String> names = new ArrayList<String>();
	public ArrayList<String> emails = new ArrayList<String>();
	private PdfFilter pdfFilter = new PdfFilter();  //Filters for JFilerChooser to only make PDF files visible.
	final JFileChooser fc = new JFileChooser(); 	//File chooser for navigating system and choosing PDF files.
	private Pattern emailPattern;						//Regex pattern matcher for email-checking
	private Matcher emailMatcher;
	private Pattern namePattern;						//Regex pattern matcher for name-checking
	private Matcher nameMatcher;
	
	//used to check the previous stage of the result_no_link_r button in case the user does not want autofill.
	private boolean no_link_previously_selected = false;
	
	//used to check the previous stage of the implementation_no_r button in case the user does not want autofill.
	private boolean no_implementation_previously_selected = false;
	
	//Regex pattern to match emails.
	private final String EMAIL_PATTERN =  "[_A-Za-z0-9-+]+(\\.[_A-Za-z0-9-+]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,4})";
	//Regex pattern to match names.
	private final String NAME_PATTERN =  "[-A-Za-z]+_[-A-Za-z.]+(_[-A-Za-z]+)?+(_[-A-Za-z]+)?";
	//private final String NAME_PATTERN =  "[A-Za-z]+_[A-Za-z.]+(_[A-Za-z]+)?";
	
	//Program entrance for Repro Editor
	public static void main(String[] args) {
		boolean nimbus = true;
		if(nimbus){
			try {
			    for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
			        if ("Nimbus".equals(info.getName())) {
			            UIManager.setLookAndFeel(info.getClassName());
			            break;
			        }
			    }
			} catch (Exception e) {
			    // If Nimbus is not available, you can set the GUI to another look and feel.
			}
		}
		JFrame window = new View(new Controller());
		window.setVisible(true);
	}
	  
	public void initRadioButtons(){
		grant_g.add(grant_yes_r);
		grant_g.add(grant_no_r);
		//make grant_g as small as possible
		grant_g.setMaximumSize(grant_g.getMinimumSize());
		
		commercial_g.add_label(new JLabel("Commentcial"));
		commercial_g.add(commercial_none_r);
		commercial_g.add(commercial_part_r);
		commercial_g.add(commercial_full_r);

		implementation_g.add_label(new JLabel("Implementation"));
		implementation_g.add(implementation_unknown_r);
		implementation_g.add(implementation_hardware_r);
		implementation_g.add(implementation_yes_r);
		implementation_g.add(implementation_no_r);

		progress_g.add_label(new JLabel("Article:Status"));
		progress_g.add(progress_not_finished_r);
		progress_g.add(progress_finished_r);

		result_g.add_label(new JLabel("Article:Status"));
		result_g.add(result_found_link_r);
		result_g.add(result_no_link_r);
		result_g.add(result_broken_link_r);

		email_radio_g.add_label(new JLabel("Email:Status"));
		email_radio_g.add(email_needed_r);
		email_radio_g.add(email_not_found_r);
		email_radio_g.add(email_not_needed_r);
		email_radio_g.add(email_unknown_r);
		
		email_box_g.add(email_request_1_x);
		email_box_g.add(email_response_1_x);
		email_box_g.add(email_sent_thank_you_x);

		build_radio_g.add_label(new JLabel("Build:Status"));
		build_radio_g.add(build_needed_r);
		build_radio_g.add(build_not_needed_r);
		build_radio_g.add(build_unknown_r);
		build_radio_g.add(build_started_r);
		build_radio_g.add(build_finished_r);
		
		build_box_g.add(build_downloaded_x);
		build_box_g.add(build_compiles_x);
		build_box_g.add(build_runs_x);

		verify_radio_g.add_label(new JLabel("Verify:Status"));
		verify_radio_g.add(verify_needed_r);
		verify_radio_g.add(verify_started_r);
		verify_radio_g.add(verify_unknown_r);
		verify_radio_g.add(verify_not_needed_r);
		verify_radio_g.add(verify_finished_r);
		
		verify_build_radio_g.add_label(new JLabel("Verify Build:Status"));
		verify_build_radio_g.add(verify_build_needed_r);
		verify_build_radio_g.add(verify_build_started_r);
		verify_build_radio_g.add(verify_build_unknown_r);
		verify_build_radio_g.add(verify_build_not_needed_r);
		verify_build_radio_g.add(verify_build_finished_r);

		article_link_radio_g.add(article_link_unknown_r);
		article_link_radio_g.add(article_link_none_r);
		article_link_radio_g.add(article_link_broken_r);
		
		google_link_radio_g.add(google_link_unknown_r);
		google_link_radio_g.add(google_link_none_r);
		google_link_radio_g.add(google_link_broken_r);

		email_link_radio_g.add(email_link_unknown_r);
		email_link_radio_g.add(email_link_none_r);
		email_link_radio_g.add(email_link_broken_r);
		email_link_radio_g.add(email_link_given_r);

		data_link_radio_g.add(data_link_unknown_r);
		data_link_radio_g.add(data_link_none_r);
		data_link_radio_g.add(data_link_broken_r);
		
		//adds all radio buttons to the ArraList of radio buttons that this program tracks

		radio_groups.add(grant_g);
		radio_groups.add(commercial_g);
		radio_groups.add(implementation_g);
		radio_groups.add(progress_g);
		radio_groups.add(result_g);
		radio_groups.add(email_radio_g);
		radio_groups.add(build_radio_g);
		radio_groups.add(verify_radio_g);
		radio_groups.add(article_link_radio_g);
		radio_groups.add(google_link_radio_g);
		radio_groups.add(email_link_radio_g);
		radio_groups.add(data_link_radio_g);
		radio_groups.add(verify_build_radio_g);
		
		for(JButtonGroup jbg: radio_groups){
			radios.addAll(jbg.getButtons());
		}
	}
	 
	//Starts a new timer that times the amount of minutes elapsed.
	public void startTimer(){
		minutes = 0;
		timer.cancel();
		timer = new Timer();
		timer.schedule( new TimerTask() {
		    public void run() {
		       minutes++;
		    }
		 }, 60000, 60000);
	}

	//Gets the amount of minutes elapsed since the start of the timers.
	public int getTimerMinutes(){
		return minutes;
	}
	
	public void initButtons(){
		buttons = new ArrayList<JButton>();
		buttons.add(browse_b);
		buttons.add(analysis_auto_b);
		buttons.add(build_auto_b);
		buttons.add(add_b);
		buttons.add(clear_b);
		buttons.add(add2_b);
		buttons.add(clear2_b);
		buttons.add(browse2_b);
		buttons.add(shuffle_b);
		buttons.add(shuffle2_b);
		buttons.add(save_b);
		buttons.add(clear_all_b);
		buttons.add(exit_b);
		buttons.add(left_expand_b);
		buttons.add(right_expand_b);
		for(JButton b: buttons){
			//Sets a mazimum size for all the buttons. The default size is too tall.
			b.setPreferredSize(new Dimension(b.getPreferredSize().width, textField.getPreferredSize().height-1));
			b.setMaximumSize(new Dimension(b.getPreferredSize().width, textField.getPreferredSize().height-1));
		}
	}
	
	/* Given a JPanel and a header String h, returns a JPanel concatenated with 
	 * the header String centerred on top. Also ass a grey border around the 
	 * overall panel. */
	public JPanel headerPanel(JPanel jp, String h){
		JPanel panel = new JPanel();
		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		if(h!=null){
			JLabel header = new JLabel(h);
			header.setForeground(Color.GRAY);
			header.setAlignmentX(CENTER_ALIGNMENT);
			panel.add(header);
		}
		panel.add(jp);
		jp.setAlignmentX(CENTER_ALIGNMENT);
		panel.setBorder(LineBorder.createGrayLineBorder());
		return panel;
	}
	
	public View(Controller c) {
		controller = c;
		this.setTitle("Reproducibility Data Editor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocation(100, 100);
		setLayout(new BoxLayout(getContentPane(), BoxLayout.LINE_AXIS));
		fc.setFileFilter(pdfFilter);
		initRadioButtons();
		initButtons();
	    registerListeners();
	    
	    //Declare pattern matcher.
		setFileChooserToHomePath(fc);
		
		//Set layout of components
		addLeft();
		addMiddle();
		addRight();
		//right.setVisible(false);
		
		pack();
		left.setMaximumSize(left.getSize());
		right.setMaximumSize(middle.getSize());
		
		emailPattern = Pattern.compile(EMAIL_PATTERN);
		namePattern = Pattern.compile(NAME_PATTERN);
	}
	
	public void setFileChooserToHomePath(final JFileChooser fc){
		URL path = CopyOfView.class.getProtectionDomain().getCodeSource().getLocation();
		try {
			final String decodedPath=new File(path.toURI()).getAbsolutePath();
			SwingUtilities.invokeAndWait(
			new Runnable(){
				public void run(){
					if(decodedPath!=null){
						fc.setCurrentDirectory(new File(new File(decodedPath).getParent()));
					}
				}
			});
		}catch(Exception e1){
			e1.printStackTrace();
			return;
		}
	}

	private void registerListeners() {
		ActionListener listenerToRectangularButtons = new RectangularButtonListener();
		for (int i = 0; i < buttons.size(); i++) {
			buttons.get(i).addActionListener(listenerToRectangularButtons);
		}
		ActionListener listenerToRadios = new RadioListener();
		for (int i = 0; i < radios.size(); i++) {
			radios.get(i).addActionListener(listenerToRadios);
		}
	}

	private class RadioListener implements ActionListener {
	    public void actionPerformed(ActionEvent theEvent) {
	    	
	    	JRadioButton jrb = (JRadioButton)theEvent.getSource();
		    for(JButtonGroup jbg: radio_groups){
			   	if(jbg.getPreviousSelected()==jrb && jrb.isSelected()){
			   		jbg.clearSelection();
			   	}
			   	for(JRadioButton jrb2 : jbg.getButtons()){
			   		if(jrb2==jrb){
			   			jbg.setPreviousSelected(jrb.isSelected()? jrb : null);
			   		}
			   	}
		    }
	    	revalidateButtons();
	    } 
	}
	
	//Takes care of the error detecting mechanisms of the editor.
	private void revalidateButtons(){
		if(implementation_no_r.isSelected()){
			if(!no_implementation_previously_selected){
				email_radio_g.setSelection("not_needed");
				build_radio_g.setSelection("not_needed");
				no_implementation_previously_selected = true;
			}
			no_implementation_previously_selected = true;
		}else{
			no_implementation_previously_selected = false;
		}
		
		if(result_no_link_r.isSelected()){
			if(!no_link_previously_selected){
				email_radio_g.setSelection("unknown");
				build_radio_g.setSelection("unknown");
				no_link_previously_selected = true;
			}
		}else{
			no_link_previously_selected = false;
		}
		
		//These if statements use short-circuit evaluations to avoid null pointer exceptions
		if(grant_g.getSelection()!=null && grant_g.getSelection().getText().equals("yes")){
			grant_f.setEnabled(true);
			article_NSF_f.setEnabled(true);
		}else{
			grant_f.setEnabled(false);
			article_NSF_f.setEnabled(false);
		}
		
		if(email_radio_g.getSelection()!=null){
			if( !email_radio_g.getSelection().getText().equals("needed")){
				email_box_g.disable();
			}else{
				email_box_g.enable();
			}
		}else{
			email_box_g.disable();
		}

		if(build_radio_g.getSelection()!=null && (build_radio_g.getSelection().getText().equals("unknown") || build_radio_g.getSelection().getText().equals("not_needed"))){
			build_analyzer_name_f.setEnabled(false);
			build_time_f.setEnabled(false);
			build_box_g.disable();
		}else{
			build_box_g.enable();
			build_analyzer_name_f.setEnabled(true);
			build_time_f.setEnabled(true);
		}
		
		if(verify_radio_g.getSelection()!=null && (verify_radio_g.getSelection().getText().equals("unknown") || verify_radio_g.getSelection().getText().equals("not_needed"))){
				verify_analyzer_name_f.setEnabled(false);
		}else{
			verify_analyzer_name_f.setEnabled(true);
		}
		
		if(verify_build_radio_g.getSelection()!=null && (verify_build_radio_g.getSelection().getText().equals("unknown") || verify_build_radio_g.getSelection().getText().equals("not_needed"))){
				verify_build_analyzer_name_f.setEnabled(false);
		}else{
			verify_build_analyzer_name_f.setEnabled(true);
		}

		if(article_link_radio_g.getSelection()!=null && (article_link_radio_g.getSelection().getText().equals("unknown") || article_link_radio_g.getSelection().getText().equals("none"))){
				tool_article_link_f.setEnabled(false);
		}else{
			tool_article_link_f.setEnabled(true);
		}
		
		if(google_link_radio_g.getSelection()!=null && (google_link_radio_g.getSelection().getText().equals("unknown") || google_link_radio_g.getSelection().getText().equals("none"))){
			tool_google_link_f.setEnabled(false);
		}else{
			tool_google_link_f.setEnabled(true);
		}
		
		if(email_link_radio_g.getSelection()!=null && (email_link_radio_g.getSelection().getText().equals("unknown") 
														|| email_link_radio_g.getSelection().getText().equals("none")
														|| email_link_radio_g.getSelection().getText().equals("sent_no_url"))){
			tool_email_link_f.setEnabled(false);
		}else{
			tool_email_link_f.setEnabled(true);
		}
		
		if(data_link_radio_g.getSelection()!=null && (data_link_radio_g.getSelection().getText().equals("unknown") || data_link_radio_g.getSelection().getText().equals("none"))){
			tool_data_link_f.setEnabled(false);
		}else{
			tool_data_link_f.setEnabled(true);
		}
	}
	
	//Appends the current list of email addresses to the email textArea.
	private void setEmails(){
		email_area.setText("");
    	for(String email: emails){
    		email_area.append(email+"\n");
    	}
	}
	
	//Appends the current list of names to the names textArea.
	private void setNames(){
		name_area.setText("");
    	for(String name: names){
    		name_area.append(name+"\n");
    	}
	}
	
	private class RectangularButtonListener implements ActionListener {
	    public void actionPerformed(ActionEvent theEvent) {
	    	JButton theButton = (JButton) theEvent.getSource();
	    	if (theButton.getText().equals("BROWSE")){
				log_area.append("---Selecting file---\n");
				log_area.setCaretPosition(log_area.getDocument().getLength());
    	        int returnVal = fc.showOpenDialog(View.this);
    	        if (returnVal == JFileChooser.APPROVE_OPTION) {
    	            File file = fc.getSelectedFile();
    	            try {
						Desktop.getDesktop().open(file);
						log_area.append("Opening "+file+"...\n");
						log_area.setCaretPosition(log_area.getDocument().getLength());
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						log_area.append("Opening failed. Check whether bibtex and data.txt exists.\n");
						log_area.setCaretPosition(log_area.getDocument().getLength());
					}
    	            
    	            dataDirectory = file.getParent().concat(System.getProperty("file.separator")+"data.txt");
    	            if(controller.read(dataDirectory)){
    	            	//Saves the previous analyzer's name in case it is needed for auto-fill later.
    	            	String article_name = article_analyzer_name_f.getText();
    	            	String build_name = build_analyzer_name_f.getText();
    	            	String verify_name = verify_analyzer_name_f.getText();
    	            	String verify_build_name = verify_build_analyzer_name_f.getText();
    	            	clearAll();
    	            	
    	            	log_area.append(controller.error_log);
    					log_area.setCaretPosition(log_area.getDocument().getLength());
    	            	getTimerMinutes();
    	            	startTimer();
    	            	
    	            	article_f.setText(file.getAbsolutePath());
    	            	emails.addAll(controller.model.emails);
    	            	setEmails();

    	            	names.addAll(controller.model.authors);
    	            	setNames();
    	            	
    	            	//Preserve name fields if the new text file does not have one already.   	
    	            	if(controller.model.name.trim().isEmpty()){
    	            		article_analyzer_name_f.setText(article_name);
    	            	}else{article_analyzer_name_f.setText(controller.model.name);}
    	            	
    	            	if(controller.model.time>0){article_time_f.setText(""+controller.model.time);}
    	            	article_comment_f.setText(controller.model.comment);
    	            	tool_name_f.setText(controller.model.tool_name);
    	            	article_link_f.setText(controller.model.link);
    	            	bibtex_label_f.setText(controller.model.bibtex_label);
    	            	bibtex_link_f.setText(controller.model.bibtex_link);

    	            	if(controller.model.build_time>0){build_time_f.setText(""+controller.model.build_time);}
    	            	
    	            	//Preserve name fields if the new text file does not have one already.
    	            	/*
    	            	if(controller.model.build_name.trim().isEmpty()){
    	            		build_analyzer_name_f.setText(build_name);
    	            	}else{*/
    	            	build_analyzer_name_f.setText(controller.model.build_name);
    	            	build_comment_f.setText(""+controller.model.build_comment);
    	            	tool_name_f.setText(controller.model.tool_name);
    	            	tool_article_link_f.setText(controller.model.tool_article_link);
    	            	
    	            	//Preserve name fields if the new text file does not have one already.  
    	            	if(controller.model.verify_name.trim().isEmpty()){
    	            		verify_analyzer_name_f.setText(verify_name);
    	            	}else{verify_analyzer_name_f.setText(controller.model.verify_name);}
    	            	verify_comment_f.setText(""+controller.model.verify_comment);

    	            	//Preserve name fields if the new text file does not have one already.  
    	            	if(controller.model.verify_build_name.trim().isEmpty()){
    	            		verify_build_analyzer_name_f.setText(verify_build_name);
    	            	}else{verify_build_analyzer_name_f.setText(controller.model.verify_build_name);}
    	            	verify_build_comment_f.setText(""+controller.model.verify_build_comment);

    	            	String gt=controller.model.grant.trim();
    	            	
    	            	if(gt.equals("none")){
    	            		grant_no_r.setSelected(true);
    	            		grant_f.setEnabled(false);
    	            		article_NSF_f.setEnabled(false);
    	            	}else if(gt.equals("")){
    	            	}else{
    	            		grant_yes_r.setSelected(true);
    	            		grant_f.setEnabled(true);
    	            		article_NSF_f.setEnabled(true);
    	            		grant_f.setText(gt);
    	            	}

    	            	String gtNSF=controller.model.grant_NSF.trim();
    	            	
    	            	if(gtNSF.equals("none")){
    	            		article_NSF_f.setText(gtNSF);
    	            	}else{
    	            		article_NSF_f.setText(controller.model.grant_NSF);
    	            	}
    	            	
    	            	commercial_g.setSelection(controller.model.commercial);
    	            	implementation_g.setSelection(controller.model.implementation);
    	            	progress_g.setSelection(controller.model.progress);
    	            	email_radio_g.setSelection(controller.model.email_status);
    	            	email_request_1_x.setSelected(controller.model.email_request_1);
    	            	email_response_1_x.setSelected(controller.model.email_response_1);
    	            	email_sent_thank_you_x.setSelected(controller.model.email_sent_thank_you);
    	            	//AWAIT//
    	            	//tool_radio_g.setSelection(controller.model.link_found);
    	            	verify_radio_g.setSelection(controller.model.verify_status);
    	            	verify_build_radio_g.setSelection(controller.model.verify_build_status);
    	            	build_radio_g.setSelection(controller.model.build_status);
    	            	build_downloaded_x.setSelected(controller.model.build_download);
    	            	build_compiles_x.setSelected(controller.model.build_compiles);
    	            	build_runs_x.setSelected(controller.model.build_runs);
    	            	
    	            	article_link_radio_g.setSelection(controller.model.tool_article_link);
    	            	tool_article_link_f.setText(controller.model.tool_article_link_url);
    	            	google_link_radio_g.setSelection(controller.model.tool_google_link);
    	            	tool_google_link_f.setText(controller.model.tool_google_link_url);
    	            	email_link_radio_g.setSelection(controller.model.tool_email_link);
    	            	tool_email_link_f.setText(controller.model.tool_email_link_url);
    	            	data_link_radio_g.setSelection(controller.model.tool_data_link);
    	            	tool_data_link_f.setText(controller.model.tool_data_link_url);
    	            	revalidateButtons();
    	            }else{
						log_area.append("Opening failed. Check whether data.txt exists in the same directory.\n");
						log_area.setCaretPosition(log_area.getDocument().getLength());
    	            }
    	        } else {
					log_area.append("Opening canelled by user.\n");
					log_area.setCaretPosition(log_area.getDocument().getLength());
    	        }
	    	}else if(theButton.getText().equals("AUTO 1")){
	    			article_time_f.setText(""+getTimerMinutes());
	    	}else if(theButton.getText().equals("AUTO 2")){
    				build_time_f.setText(""+getTimerMinutes());
	    	}else if(theButton.getText().equals("+")){
    				if(theButton.equals(add_b)){
	    				if(addEmail(email_f.getText()))
	    					email_f.setText("");
	    			}
    				if(theButton.equals(add2_b)){
	    				if(addName(name_f.getText()))
	    					name_f.setText("");
    				}
	    	}else if(theButton.getText().equals("C")){
	    			if(theButton.equals(clear_b)){
		    			if(emails.size()>=1)
		    				emails.remove(emails.size()-1);
		            	setEmails();
		            	email_f.setText("");
	            	}
	    			if(theButton.equals(clear2_b)){
		    			if(names.size()>=1)
		    				names.remove(names.size()-1);
		            	setNames();
		            	name_f.setText("");
	            	}
	    	}else if(theButton.getText().equals("S")){
    			if(theButton.equals(shuffle_b)){
	    			if(emails.size()>=1)
	    				emails.add(0, emails.remove(emails.size()-1));
	            	setEmails();
            	}
    			if(theButton.equals(shuffle2_b)){
	    			if(names.size()>=1)
	    				names.add(0, names.remove(names.size()-1));
	            	setNames();
            	}
    	}else if(theButton.getText().equals("SAVE")){
	    			//Create a new model to store information inputed to GUI.
	    			Model m = new Model();

	    			m.name=article_analyzer_name_f.getText();

	    			//Sanity check for the time field
	    			boolean parsable = true;
	    			try{
	    				Integer.parseInt(article_time_f.getText());
	    			}catch(NumberFormatException e){
	    				parsable = false;
	    			}
	    			if(parsable){
	        			m.time=Integer.parseInt(article_time_f.getText());
	        			if(m.time<1){
	        				log_area.append("WARNING: ARTICLE:ANALYSIS_TIME is not a positive integer, the field will not be written\n");
	        				log_area.setCaretPosition(log_area.getDocument().getLength());}
	        		}else{
	        			m.time=-1;
	        			if(!article_time_f.getText().trim().isEmpty()){
	        				log_area.append("WARNING: ARTICLE:ANALYSIS_TIME is not a positive integer, the field will not be written\n");
	        				log_area.setCaretPosition(log_area.getDocument().getLength());}
        			}
	    			
	    			if(grant_g.getSelection()!=null){
	    				if(grant_g.getSelection().getText().equals("yes")){
	    					m.grant = grant_f.getText();
	    					m.grant_NSF = article_NSF_f.getText();
	    				}else{
	    					m.grant = "none";
	    					m.grant_NSF = "none";
	    				}
	    			}
	    			
	    			m.link=article_link_f.getText();
	    			m.comment=article_comment_f.getText();
	    			if(commercial_g.getSelection()!=null)
	    				m.commercial=(commercial_g.getSelection()).getText();
	    			if(implementation_g.getSelection()!=null){
	    				m.implementation=(implementation_g.getSelection()).getText();
	    			}
	    			if(progress_g.getSelection()!=null){
	    				m.progress=(progress_g.getSelection()).getText();
	    			}
	    			
	    			m.bibtex_label = bibtex_label_f.getText();
	    			m.bibtex_link = bibtex_link_f.getText();
	    			
	    			//Checks to see whether the remaining email in text field should be added
	    			if(!email_f.getText().trim().isEmpty()){
		    			boolean textFieldIsNewEmail = true;
		    			for(String s:emails){
		    				if(s.trim().equals(email_f.getText().trim()))
		    					textFieldIsNewEmail = false;
		    			}
		    			if(textFieldIsNewEmail){
		    				if(addEmail(email_f.getText())){
		    					email_f.setText("");
		    				}
		    			}
	    			}
	    			m.emails=emails;
	    			m.authors=names;
	    			if(email_radio_g.getSelection()!=null){
	    				m.email_status = (email_radio_g.getSelection()).getText();
	    			}
	    			if(email_box_g.isEnabled()){
	    				m.email_request_1 = email_request_1_x.isSelected();
	    				m.email_response_1 = email_response_1_x.isSelected();
	    				m.email_sent_thank_you = email_sent_thank_you_x.isSelected();
	    			}
	    			m.tool_name = tool_name_f.getText();
	    			m.tool_article_link_url = tool_article_link_f.getText();
	    			if(!tool_article_link_f.isEnabled() && !tool_article_link_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: TOOL:ARTICLE_LINK is set to none or unknown, but non-empty link is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			if(article_link_radio_g.getSelection()!=null){
	    				m.tool_article_link = (article_link_radio_g.getSelection()).getText();
	    			}
	    		
	    			m.tool_google_link_url = tool_google_link_f.getText();
	    			if(!tool_google_link_f.isEnabled() && !tool_google_link_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: TOOL:ARTICLE_LINK is set to none or unknown, but non-empty link is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			if(google_link_radio_g.getSelection()!=null){
	    				m.tool_google_link = (google_link_radio_g.getSelection()).getText();
	    			}

	    			m.tool_email_link_url = tool_email_link_f.getText();
	    			if(!tool_email_link_f.isEnabled() && !tool_email_link_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: TOOL:EMAIL_LINK is set to none, unknown, or sent_no_link, but non-empty link is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			if(email_link_radio_g.getSelection()!=null){
	    				m.tool_email_link = (email_link_radio_g.getSelection()).getText();
	    			}
	    			
	    			m.tool_data_link_url = tool_data_link_f.getText();
	    			if(!tool_data_link_f.isEnabled() && !tool_data_link_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: TOOL:DATA_LINK is set to none or unknown, but non-empty link is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			if(data_link_radio_g.getSelection()!=null){
	    				m.tool_data_link = (data_link_radio_g.getSelection()).getText();
	    			}
	    			
	    			m.verify_name = verify_analyzer_name_f.getText();
	    			if(!verify_analyzer_name_f.isEnabled() && !verify_analyzer_name_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: VERIFY:STATUS is set to unknown or not_needed, but non-empty VERIFY:ANALYSIS BY field is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			m.verify_comment = verify_comment_f.getText();
	    			if(verify_radio_g.getSelection()!=null){
	    				m.verify_status = (verify_radio_g.getSelection()).getText();
	    			}
	    			
	    			m.verify_build_name = verify_build_analyzer_name_f.getText();
	    			if(!verify_build_analyzer_name_f.isEnabled() && !verify_build_analyzer_name_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: VERIFY_BUILD:STATUS is set to unknown or not_needed, but non-empty VERIFY_BUILD:ANALYSIS BY field is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			m.verify_build_comment = verify_build_comment_f.getText();
	    			if(verify_build_radio_g.getSelection()!=null){
	    				m.verify_build_status = (verify_build_radio_g.getSelection()).getText();
	    			}
	    			
	    			m.build_name = build_analyzer_name_f.getText();
	    			if(!build_analyzer_name_f.isEnabled() && !build_analyzer_name_f.getText().trim().isEmpty()){
	    				log_area.append("WARNING: BUILD:STATUS is set to unknown or not_needed, but non-empty BUILD:ANALYSIS BY field is written.\n");
	    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			parsable = true;
	    			try{
	    				//Santy check for build_time value.
	    				Integer.parseInt(build_time_f.getText());
	    			}catch(NumberFormatException e){
	    				parsable = false;
	    			}
	    			if(parsable){
	        			m.build_time=Integer.parseInt(build_time_f.getText());
	        			if(m.build_time<1){
	        				log_area.append("WARNING: BUILD:ANALYSIS_TIME is not a positive integer, the field will not be written\n");
	        				log_area.setCaretPosition(log_area.getDocument().getLength());}
	        			else if(!build_time_f.isEnabled() && !build_time_f.getText().trim().isEmpty()){
		    				log_area.append("WARNING: BUILD:STATUS is set to unknown or not_needed, but non-empty BUILD:ANALYSIS_TIME BY field is written.\n");
		    				log_area.setCaretPosition(log_area.getDocument().getLength());}
	        		}else{
	        			m.build_time=-1;
	        			if(!build_time_f.getText().trim().isEmpty()){
	        				log_area.append("WARNING: BUILD:ANALYSIS_TIME is not a positive integer, the field will not be written\n");
	        				log_area.setCaretPosition(log_area.getDocument().getLength());
	        			}
	        		}
	    			m.build_comment = build_comment_f.getText();
	    			if(build_radio_g.getSelection()!=null){
	    				m.build_status = (build_radio_g.getSelection()).getText();
	    			}
	    			m.build_download = build_downloaded_x.isSelected();
	    			m.build_compiles = build_compiles_x.isSelected();
	    			m.build_runs = build_runs_x.isSelected();
	    			m.comment_CC = controller.model.comment_CC;
	    			m.comment_TP = controller.model.comment_TP;
	    			m.email_code = controller.model.email_code;
	    			m.email_remark = controller.model.email_remark;
	    			
	    			//Call controller to save the new .txt file along with backup.
	    			boolean a = controller.save(dataDirectory, m);
	    			if(!a){log_area.append("ERROR: save path does not exist.\n");
						log_area.setCaretPosition(log_area.getDocument().getLength());}
	    			else{log_area.append("Save complete.\n");
						log_area.setCaretPosition(log_area.getDocument().getLength());}
	    	}else if(theButton.getText().equals("CLEAR ALL")){
	    			clearAll();
	        }else if(theButton.getText().equals("EXIT")){
	    			System.exit(0);
	    	}else if(theButton.getText().equals("<")){
    			left.setVisible(!left.isVisible());
    			pack();
	    	}else if(theButton.getText().equals(">")){
    			right.setVisible(!right.isVisible());
    			pack();
	    	}
	    }	
	}

	//Clears all fields currently set in the GUI.
	private void clearAll() {
		article_f.setText("");
		article_analyzer_name_f.setText("");
		article_time_f.setText("");
		grant_f.setText("");
		grant_g.clearSelection();
		article_link_f.setText("");
		article_comment_f.setText("");
		commercial_g.clearSelection();
		implementation_g.clearSelection();
		progress_g.clearSelection();
		result_g.clearSelection();
    	bibtex_label_f.setText("");
    	bibtex_link_f.setText("");
		email_f.setText("");
    	emails.clear();
    	email_area.setText("");
    	email_radio_g.clearSelection();
    	email_box_g.clearSelection();
		tool_name_f.setText("");
    	tool_article_link_f.setText("");
    	tool_google_link_f.setText("");
    	tool_email_link_f.setText("");
    	tool_data_link_f.setText("");
    	article_link_radio_g.clearSelection();
    	google_link_radio_g.clearSelection();
    	data_link_radio_g.clearSelection();
    	email_link_radio_g.clearSelection();
    	verify_analyzer_name_f.setText("");
    	verify_comment_f.setText("");
    	verify_radio_g.clearSelection();
    	verify_build_analyzer_name_f.setText("");
    	verify_build_comment_f.setText("");
    	verify_build_radio_g.clearSelection();
		build_analyzer_name_f.setText("");
		build_time_f.setText("");
    	build_comment_f.setText("");
    	build_radio_g.clearSelection();
    	build_box_g.clearSelection();
    	name_f.setText("");
    	names.clear();
    	name_area.setText("");
    	article_NSF_f.setText("");
    	
    	for(JButtonGroup jbg: radio_groups){
    		jbg.setPreviousSelected(null);
    	}
    	revalidateButtons();
	}
	
	//Adds an email to the list of current emails in the email text area.
	private boolean addEmail(String e){
		emailMatcher = emailPattern.matcher(e);
		if(!emailMatcher.matches()){
			log_area.append("Invalid email address: "+email_f.getText()+"\n");
			log_area.setCaretPosition(log_area.getDocument().getLength());
			return false;
		}else{emails.add(e);setEmails();return true;}
	}

	//Adds an email to the list of current emails in the email text area.
	private boolean addName(String n){
		String n_sub = n.trim().replace(' ', '_');
		nameMatcher = namePattern.matcher(n_sub);
		if(!nameMatcher.matches()){
			log_area.append("Invalid author name: "+name_f.getText()+"\n");
			log_area.setCaretPosition(log_area.getDocument().getLength());
			return false;
		}else{names.add(n_sub);setNames();return true;}
	}
	
	//Adds the left side of the UI.
	private void addLeft() {
		left.setLayout(new BoxLayout(left, BoxLayout.PAGE_AXIS));
		add(left);
		//left.add(articlePanel);
		left.add(headerPanel(articlePanel, "ARTICLE"));
		article_box.setLayout(new BoxLayout(article_box, BoxLayout.LINE_AXIS));
		article_f.setMaximumSize(article_f.getPreferredSize());
		article_box.add(article_f);
		article_box.add(browse_b);

		analysis_time_box.setLayout(new BoxLayout(analysis_time_box, BoxLayout.LINE_AXIS));
		article_time_f.setMaximumSize(article_f.getPreferredSize());
		analysis_time_box.add(article_time_f);
		analysis_time_box.add(analysis_auto_b);
		
		grant_box.setLayout(new BoxLayout(grant_box, BoxLayout.LINE_AXIS));
		grant_box.add(grant_l);
		grant_box.add(grant_g);
		grant_f.addMouseListener(new MouseListener(){
		    public void mouseClicked(MouseEvent e) {}
			public void mouseEntered(MouseEvent arg0) {}
			public void mouseExited(MouseEvent arg0) {}
			public void mousePressed(MouseEvent arg0) {
				grant_yes_r.setSelected(true);
				revalidateButtons();}
			public void mouseReleased(MouseEvent arg0) {}
		});
		
		GroupLayout layout = new GroupLayout(articlePanel);
		articlePanel.setLayout(layout);
		
		layout.setAutoCreateGaps(true);
		layout.setAutoCreateContainerGaps(true);
		
		layout.setVerticalGroup(
				   layout.createSequentialGroup()
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(article_l)
				              .addComponent(article_box))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(article_analyzer_name_l)
				              .addComponent(article_analyzer_name_f))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(article_time_l)
				              .addComponent(analysis_time_box))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(grant_box)
				              .addComponent(grant_f))
					 .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
						      .addComponent(article_NSF_l)
						      .addComponent(article_NSF_f))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(article_link_l)
				              .addComponent(article_link_f))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(article_comment_l)
				              .addComponent(article_comment_f))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER)
				              .addComponent(commercial_g.radioLabel)
				              .addComponent(commercial_g.radioPanel)
				              .addComponent(implementation_g.radioLabel)
				              .addComponent(implementation_g.radioPanel))
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.CENTER)
				              .addComponent(progress_g.radioLabel)
				              .addComponent(progress_g.radioPanel))
				);
			layout.setHorizontalGroup(
				layout.createParallelGroup().addGroup(
				   layout.createSequentialGroup()
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				           .addComponent(article_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_analyzer_name_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_time_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_NSF_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(grant_box, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_link_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_comment_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				    		  )
				      .addGroup(layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				           .addComponent(article_box, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_analyzer_name_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(analysis_time_box, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(grant_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_link_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(article_comment_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						   .addComponent(article_NSF_f,GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				    		  )
				    	).addGroup(layout.createSequentialGroup()
						           .addComponent(commercial_g.radioLabel)
						           .addComponent(commercial_g.radioPanel)
						           .addComponent(implementation_g.radioLabel)
						           .addComponent(implementation_g.radioPanel)
			    	).addGroup(layout.createSequentialGroup()
					           .addComponent(progress_g.radioLabel)
					           .addComponent(progress_g.radioPanel)
			    	)
			);

		//radios_top_panel
			/*
		radios_panel.setLayout(new BoxLayout(radios_panel, BoxLayout.PAGE_AXIS));
		GroupLayout radio_layout = new GroupLayout(radios_top_panel);
		radios_panel.add(radios_top_panel);
		radios_top_panel.setLayout(radio_layout);
		radio_layout.setAutoCreateGaps(true);
		radio_layout.setAutoCreateContainerGaps(true);
		radio_layout.setHorizontalGroup(
				radio_layout.createSequentialGroup()
		      .addGroup(radio_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
			           .addComponent(commercial_g, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
			           //.addComponent(progress_g, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
		      .addGroup(radio_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
		    		  .addComponent(implementation_g, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
				);
		
		radio_layout.setVerticalGroup(
				radio_layout.createSequentialGroup()
		      .addGroup(radio_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
			           .addComponent(commercial_g, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
			           .addComponent(implementation_g, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
			  //.addComponent(progress_g, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				);
		left.add(radios_panel);
		//radios_panel.add(progress_g);
		radios_panel.setAlignmentX(CENTER_ALIGNMENT);
		*/
		
		left.add(headerPanel(build_panel, "BUILD"));

		build_time_box.setLayout(new BoxLayout(build_time_box, BoxLayout.LINE_AXIS));
		build_time_f.setMaximumSize(article_f.getPreferredSize());
		build_time_box.add(build_time_f);
		build_time_box.add(build_auto_b);
		
		build_panel.setLayout(new BoxLayout(build_panel, BoxLayout.PAGE_AXIS));
		build_panel.add(build_field_panel);
		GroupLayout build_field_layout = new GroupLayout(build_field_panel);
		build_field_panel.setLayout(build_field_layout);
		build_field_layout.setAutoCreateGaps(true);
		build_field_layout.setAutoCreateContainerGaps(true);
		build_field_layout.setHorizontalGroup(
				build_field_layout.createParallelGroup().addGroup(
					build_field_layout.createSequentialGroup()
					      .addGroup(build_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					           .addComponent(build_analyzer_name_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(build_time_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(build_comment_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					    		  )
					      .addGroup(build_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					           .addComponent(build_analyzer_name_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(build_time_box, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(build_comment_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					    		  )
				    ).addComponent(build_status_panel)
				);
		
		build_field_layout.setVerticalGroup(
				build_field_layout.createSequentialGroup()
				      .addGroup(build_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(build_analyzer_name_l)
				              .addComponent(build_analyzer_name_f))
				      .addGroup(build_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(build_time_l)
				              .addComponent(build_time_box))
				      .addGroup(build_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(build_comment_l)
				              .addComponent(build_comment_f))
				      .addComponent(build_status_panel)
				              );
		
		//build_panel.add(build_status_panel);
		build_status_panel.setLayout(new BoxLayout(build_status_panel, BoxLayout.PAGE_AXIS));
		build_radio_g.setAlignmentX(CENTER_ALIGNMENT);
		build_status_panel.add(build_radio_g);
		build_box_g.setAlignmentX(CENTER_ALIGNMENT);
		build_status_panel.add(build_box_g);
	}
	
	//Adds the middle side of the UI
	private void addMiddle() {
		add(middle);
		middle.setLayout(new BoxLayout(middle, BoxLayout.PAGE_AXIS));
		
		middle.add(headerPanel(bibtex_panel, "BIBTEX"));
		GroupLayout bibtex_layout = new GroupLayout(bibtex_panel);
		bibtex_panel.setLayout(bibtex_layout);
		bibtex_layout.setAutoCreateGaps(true);
		bibtex_layout.setAutoCreateContainerGaps(true);
		bibtex_layout.setHorizontalGroup(
				bibtex_layout.createSequentialGroup()
				      .addGroup(bibtex_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				           .addComponent(bibtex_label_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(bibtex_link_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				    		  )
				      .addGroup(bibtex_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				           .addComponent(bibtex_label_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				           .addComponent(bibtex_link_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
				    		  )
				);
		
		bibtex_layout.setVerticalGroup(
				bibtex_layout.createSequentialGroup()
				      .addGroup(bibtex_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(bibtex_label_l)
				              .addComponent(bibtex_label_f))
				      .addGroup(bibtex_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(bibtex_link_l)
				              .addComponent(bibtex_link_f))
				              );

		middle.add(headerPanel(tool_panel, "TOOL"));
		tool_panel.setLayout(new BoxLayout(tool_panel, BoxLayout.PAGE_AXIS));
		tool_panel.add(tool_field_panel);
		
		GroupLayout tool_field_layout = new GroupLayout(tool_field_panel);
		tool_field_panel.setAlignmentX(CENTER_ALIGNMENT);
		tool_field_panel.setLayout(tool_field_layout);
		tool_field_layout.setAutoCreateGaps(true);
		tool_field_layout.setAutoCreateContainerGaps(true);
		tool_field_layout.setHorizontalGroup(
				tool_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addGroup(tool_field_layout.createSequentialGroup()
						      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						           .addComponent(tool_name_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_article_link_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_google_link_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_email_link_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_data_link_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						       //    .addComponent(tool_radio_g)
						    		  )
						      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						           .addComponent(tool_name_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_article_link_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_google_link_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_email_link_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						           .addComponent(tool_data_link_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
						    		  )
						    	)
				    	.addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						      .addComponent(article_link_radio_g)
						      .addComponent(google_link_radio_g)
						      .addComponent(email_link_radio_g)
						      .addComponent(data_link_radio_g)
				)
		);
		
		tool_field_layout.setVerticalGroup(
				tool_field_layout.createSequentialGroup()
				      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(tool_name_l)
				              .addComponent(tool_name_f))
				      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(tool_article_link_l)
				              .addComponent(tool_article_link_f))
				      .addComponent(article_link_radio_g)
				      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(tool_google_link_l)
				              .addComponent(tool_google_link_f))
					  .addComponent(google_link_radio_g)
				      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(tool_email_link_l)
				              .addComponent(tool_email_link_f))
					  .addComponent(email_link_radio_g)
				      .addGroup(tool_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(tool_data_link_l)
				              .addComponent(tool_data_link_f))
					  .addComponent(data_link_radio_g)
				      //.addComponent(tool_radio_g)
				              );
		
		
		middle.add(headerPanel(log_panel, "LOG"));
		log_panel.setLayout(new BoxLayout(log_panel, BoxLayout.PAGE_AXIS));
		log_panel.add(log_area_pane);
		log_area.setEditable(false);
		DefaultCaret caret = (DefaultCaret)log_area.getCaret();
		caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);
		log_area.setAlignmentX(CENTER_ALIGNMENT);
		
		middle.add(headerPanel(button_panel, null));
		button_panel.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.fill = GridBagConstraints.HORIZONTAL;

		gbc.weightx = 0.5;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 0;
		gbc.gridy = 0;
		button_panel.add(left_expand_b, gbc);

		gbc.weightx = 0.5;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 1;
		gbc.gridy = 0;
		button_panel.add(save_b, gbc);

		gbc.weightx = 0.5;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 2;
		gbc.gridy = 0;
		button_panel.add(browse2_b, gbc);

		gbc.weightx = 0.5;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 3;
		gbc.gridy = 0;
		button_panel.add(clear_all_b, gbc);


		gbc.weightx = 0.5;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.gridx = 4;
		gbc.gridy = 0;
		button_panel.add(right_expand_b, gbc);

		button_panel.setMaximumSize(button_panel.getPreferredSize());
	}
	
	//Adds the right side of the UI
	private void addRight() {
		add(right);
		
		
		right.add(headerPanel(name_panel, "AUTHOR NAME"));
		//name_panel.setLayout(new BoxLayout(name_panel, BoxLayout.PAGE_AXIS));
		GroupLayout name_layout = new GroupLayout(name_panel);
		name_panel.setLayout(name_layout);
		name_layout.setAutoCreateGaps(true);
		name_layout.setAutoCreateContainerGaps(true);
		name_layout.setHorizontalGroup(
				name_layout.createParallelGroup()
				      .addComponent(name_field_panel)
				      .addComponent(name_area_pane)
				);
		
		name_layout.setVerticalGroup(
				name_layout.createSequentialGroup()
				              .addComponent(name_field_panel)
				              .addComponent(name_area_pane)
				            	);
		
		name_area.setEditable(false);
		//name_panel.add(name_field_panel);
		//name_panel.add(name_area_pane);
		name_f.addActionListener(new ActionListener(){
	        public void actionPerformed(ActionEvent e){
				if(addName(name_f.getText())){
					((JTextField)e.getSource()).setText("");
	        	}
	        }
		});
		name_field_panel.setLayout(new BoxLayout(name_field_panel, BoxLayout.LINE_AXIS));
		name_field_panel.add(name_l);
		name_field_panel.add(name_f);
		name_f.setMaximumSize(article_analyzer_name_f.getPreferredSize());
		name_field_panel.add(add2_b);
		name_field_panel.add(clear2_b);
		name_field_panel.add(shuffle2_b);
		
		
		right.setLayout(new BoxLayout(right, BoxLayout.PAGE_AXIS));
		
		right.add(headerPanel(email_panel, "EMAIL"));

		GroupLayout email_layout = new GroupLayout(email_panel);
		email_panel.setLayout(email_layout);
		email_layout.setAutoCreateGaps(true);
		email_layout.setAutoCreateContainerGaps(true);
		email_layout.setHorizontalGroup(
			email_layout.createParallelGroup(GroupLayout.Alignment.CENTER)
			.addComponent(email_field_panel)
			.addComponent(email_area_pane)
			.addComponent(email_radio_g.labelPanel)
			.addGroup(email_layout.createSequentialGroup()
					.addComponent(email_radio_g.radioPanel)
					.addComponent(email_box_g.boxPanel)
			)
		);
		email_layout.setVerticalGroup(
			email_layout.createSequentialGroup()
			.addComponent(email_field_panel)
			.addComponent(email_area_pane)
			.addComponent(email_radio_g.labelPanel)
			.addGroup(email_layout.createParallelGroup()
				.addComponent(email_radio_g.radioPanel)
				.addComponent(email_box_g.boxPanel)
			)
		);
		/*email_panel.setLayout(new BoxLayout(email_panel, BoxLayout.PAGE_AXIS));
		email_panel.add(email_field_panel);
		email_panel.add(email_area_pane);
		email_panel.add(email_status_panel);*/
		email_area.setEditable(false);
		
		email_field_panel.setLayout(new BoxLayout(email_field_panel, BoxLayout.LINE_AXIS));
		email_field_panel.add(email_l);
		email_field_panel.add(email_f);
		email_f.setMaximumSize(article_analyzer_name_f.getPreferredSize());
		email_field_panel.add(add_b);
		email_field_panel.add(clear_b);
		email_field_panel.add(shuffle_b);
		//Listener for KEYBORAD ENTER event to enter email addresses into the system.
		email_f.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
    			if(addEmail(email_f.getText())){
    				((JTextField)e.getSource()).setText("");
            	}
            }
		});

		email_status_panel.setLayout(new BoxLayout(email_status_panel, BoxLayout.PAGE_AXIS));
		email_status_panel.add(email_radio_g);
		email_status_panel.add(email_box_g);
		
		
		
		right.add(headerPanel(verify_panel, "VERIFY"));
		verify_panel.setLayout(new BoxLayout(verify_panel, BoxLayout.PAGE_AXIS));
		verify_panel.add(verify_field_panel);
		//verify_comment_f.setMaximumSize(textField.getPreferredSize());
		//verify_analyzer_name_f.setMaximumSize(textField.getPreferredSize());
		GroupLayout verify_field_layout = new GroupLayout(verify_field_panel);
		verify_field_panel.setLayout(verify_field_layout);
		verify_field_layout.setAutoCreateGaps(true);
		verify_field_layout.setAutoCreateContainerGaps(true);
		verify_field_layout.setHorizontalGroup(
				verify_field_layout.createParallelGroup().addGroup(
					verify_field_layout.createSequentialGroup()
					      .addGroup(verify_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					           .addComponent(verify_analyzer_name_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(verify_comment_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           //.addComponent(verify_radio_g.radioLabel)
					    		  )
					      .addGroup(verify_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					           .addComponent(verify_analyzer_name_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(verify_comment_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           //.addComponent(verify_radio_g.radioPanel)
					    		  )
				    ).addComponent(verify_radio_g)
				);
		
		verify_field_layout.setVerticalGroup(
				verify_field_layout.createSequentialGroup()
				      .addGroup(verify_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(verify_analyzer_name_l)
				              .addComponent(verify_analyzer_name_f))
				      .addGroup(verify_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(verify_comment_l)
				              .addComponent(verify_comment_f))
				      .addComponent(verify_radio_g)
				      /*.addGroup(verify_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(verify_radio_g.radioLabel)
				              .addComponent(verify_radio_g.radioPanel))*/
				              );
		verify_radio_g.setAlignmentX(CENTER_ALIGNMENT);
		//verify_panel.add(verify_radio_g);
		verify_radio_g.setAlignmentX(CENTER_ALIGNMENT);
		
		/*
		right.add(headerPanel(verify_build_panel, "VERIFY BUILD"));
		verify_build_panel.setLayout(new BoxLayout(verify_build_panel, BoxLayout.PAGE_AXIS));
		verify_build_panel.add(verify_build_field_panel);
		//verify_comment_f.setMaximumSize(textField.getPreferredSize());
		//verify_analyzer_name_f.setMaximumSize(textField.getPreferredSize());
		GroupLayout verify_build_field_layout = new GroupLayout(verify_build_field_panel);
		verify_build_field_panel.setLayout(verify_build_field_layout);
		verify_build_field_layout.setAutoCreateGaps(true);
		verify_build_field_layout.setAutoCreateContainerGaps(true);
		verify_build_field_layout.setHorizontalGroup(
				verify_build_field_layout.createParallelGroup().addGroup(
					verify_build_field_layout.createSequentialGroup()
					      .addGroup(verify_build_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					           .addComponent(verify_build_analyzer_name_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(verify_build_comment_l, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           //.addComponent(verify_radio_g.radioLabel)
					    		  )
					      .addGroup(verify_build_field_layout.createParallelGroup(GroupLayout.Alignment.LEADING)
					           .addComponent(verify_build_analyzer_name_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           .addComponent(verify_build_comment_f, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					           //.addComponent(verify_radio_g.radioPanel)
					    		  )
				    ).addComponent(verify_build_radio_g)
				);
		
		verify_build_field_layout.setVerticalGroup(
				verify_build_field_layout.createSequentialGroup()
				      .addGroup(verify_build_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(verify_build_analyzer_name_l)
				              .addComponent(verify_build_analyzer_name_f))
				      .addGroup(verify_build_field_layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
				              .addComponent(verify_build_comment_l)
				              .addComponent(verify_build_comment_f))
				      .addComponent(verify_build_radio_g)
				              );
		
		verify_build_radio_g.setAlignmentX(CENTER_ALIGNMENT);
		//verify_build_panel.add(verify_build_radio_g);
		verify_build_radio_g.setAlignmentX(CENTER_ALIGNMENT);
		 */
	}
}
/*
 * Author: Zuoming Shi
 * Last updated: 5/17/2013
 * Purpose: Reproducibility Data Writer: a Swing project used to edit
 * the contents of Data.txt files used to store reproducibility data
 * of various papers submitted to recent conferences.
 */

import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class CopyOfView extends JFrame {

	private ArrayList<JButton> buttons;
	private JLabel article_l = new JLabel("Article");
	private JTextField article_f = new JTextField(15);  
	private JLabel tool_name_l = new JLabel("Tool Name");
	private JTextField tool_name_f = new JTextField(15);
	private JLabel name_l = new JLabel("Analysis by");
	private JTextField name_f = new JTextField(8);
	private JLabel time_l = new JLabel("Analysis time");
	private JTextField time_f = new JTextField(2);
	private JLabel email_l = new JLabel("Email(s)");
	private JTextField email_f = new JTextField(15);
	private JLabel last_email_l = new JLabel("Last email: none");
	private JLabel grant_l = new JLabel("Grant");
	private JTextField grant_f = new JTextField(15);
	private JLabel commercial_l = new JLabel("Commercial support");
	private JLabel implementation_l = new JLabel("Implementation exists");
	private JLabel progress_l = new JLabel("Progress");
	private JLabel result_l = new JLabel("Result");
	private JLabel link_l = new JLabel("Article link");
	private JTextField link_f = new JTextField(20);
	//private JLabel tool_l = new JLabel("Tool name");
	//private JTextField tool_f = new JTextField(20);
	private JLabel comment_l = new JLabel("Comment  ");
	private JTextField comment_f = new JTextField(20);
	private JLabel status_l = new JLabel("");
	  
	private JButtonGroup grant_g = new JButtonGroup();
	private JRadioButton grant_yes_r = new JRadioButton("yes");
	private JRadioButton grant_no_r = new JRadioButton("no");

	private JButtonGroup commercial_g = new JButtonGroup();
	private JRadioButton commercial_none_r = new JRadioButton("none");
	private JRadioButton commercial_part_r = new JRadioButton("part");
	private JRadioButton commercial_full_r = new JRadioButton("full");

	private JButtonGroup implementation_g = new JButtonGroup();
	private JRadioButton implementation_unknown_r = new JRadioButton("unknown");
	private JRadioButton implementation_yes_r = new JRadioButton("yes");
	private JRadioButton implementation_no_r = new JRadioButton("no"); 

	private JButtonGroup progress_g = new JButtonGroup();
	private JRadioButton progress_not_started_r = new JRadioButton("not_started");
	private JRadioButton progress_started_r = new JRadioButton("started");
	private JRadioButton progress_finished_r = new JRadioButton("finished");

	private JButtonGroup result_g = new JButtonGroup();
	private JRadioButton result_found_link_r = new JRadioButton("found_link");
	private JRadioButton result_no_link_r = new JRadioButton("no_link");
	private JRadioButton result_broken_link_r = new JRadioButton("broken_link");

	private Controller controller = new Controller();
	private JPanel top = new JPanel();
	private JPanel article = new JPanel();
	private JPanel tool_name = new JPanel();
	private JPanel name = new JPanel();
	private JPanel time = new JPanel();
	private JPanel last_email = new JPanel();
	private JPanel email = new JPanel();
	private JPanel grant = new JPanel();
	private JPanel link = new JPanel();
	private JPanel comment = new JPanel();
	private JPanel radiosPanel = new JPanel();
	private JPanel bottom = new JPanel();
	private JPanel last_buttons = new JPanel();
	  
	private JButton browse_b = new JButton("BROWSE");
	private JButton auto_b = new JButton("AUTO");
	private JButton add_b = new JButton("+");
	private JButton clear_b = new JButton("C");
	private JButton browse2_b = new JButton("BROWSE");
	private JButton save_b = new JButton("SAVE");
	private JButton all_clear_b = new JButton("ALL CLEAR");
	private JButton exit_b = new JButton("EXIT");
	
	private ArrayList<JRadioButton> grantRadios = new ArrayList<JRadioButton>();
	private String dataDirectory = "";
	
	private Timer timer = new Timer();
	private int minutes=0;
	public ArrayList<String> emails = new ArrayList<String>();
	private PdfFilter pdfFilter = new PdfFilter(); //Filters for JFilerChooser to only make PDF files visible.
	final JFileChooser fc = new JFileChooser(); //File chooser for navigating system and choosing PDF files.

	public static void main(String[] args) {
		JFrame window = new CopyOfView(new Controller());
		window.setVisible(true);
	}
	  
	public void initRadioButtons(){
		grant_g.add(grant_no_r);
		grant_g.add(grant_yes_r);
		commercial_g.add_label(commercial_l);
		commercial_g.add(commercial_none_r);
		commercial_g.add(commercial_part_r);
		commercial_g.add(commercial_full_r);
		commercial_g.setPreferredSize(new Dimension(150, commercial_g.getPreferredSize().height));
		implementation_g.add_label(implementation_l);
		implementation_g.add(implementation_unknown_r);
		implementation_g.add(implementation_yes_r);
		implementation_g.add(implementation_no_r);
		implementation_g.setPreferredSize(new Dimension(150, implementation_g.getPreferredSize().height));
		progress_g.add_label(progress_l);
		progress_g.add(progress_not_started_r);
		progress_g.add(progress_started_r);
		progress_g.add(progress_finished_r);
		progress_g.setPreferredSize(new Dimension(127, progress_g.getPreferredSize().height));
		result_g.add_label(result_l);
		result_g.add(result_found_link_r);
		result_g.add(result_no_link_r);
		result_g.add(result_broken_link_r);
		result_g.setPreferredSize(new Dimension(160, result_g.getPreferredSize().height));
		grantRadios.add(grant_no_r);
		grantRadios.add(grant_yes_r);
	}
	 
	public void startTimer(){
		timer = new Timer();
		timer.schedule( new TimerTask() {
		    public void run() {
		       minutes++;
		    }
		 }, 60000, 1000*60);
	}
	
	public int stopTimer(){
		timer.cancel();
		int temp = minutes;
		minutes = 0;
		return temp;
	}
	
	public void setPath(JFileChooser fc){
		URL path = CopyOfView.class.getProtectionDomain().getCodeSource().getLocation();
		String decodedPath = "";
		try {
			decodedPath=new File(path.toURI()).getAbsolutePath();
		} catch (URISyntaxException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		fc.setCurrentDirectory(new File(new File(decodedPath).getParent()));
	}
	
	//Register actionListeners to buttons.
	public void registerButtons(){
		buttons = new ArrayList<JButton>();
		buttons.add(browse_b);
		buttons.add(auto_b);
		buttons.add(add_b);
		buttons.add(clear_b);
		buttons.add(browse2_b);
		buttons.add(save_b);
		buttons.add(all_clear_b);
		buttons.add(exit_b);
		for(JButton b: buttons){
			b.setPreferredSize(new Dimension(b.getPreferredSize().width, 20));
		}
	}
	
	public CopyOfView(Controller c) {
		controller = c;
		this.setTitle("Reproducibility Data Editor");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(330, 572);
		setLocation(100, 100);
		initRadioButtons();
		registerButtons();
	    registerListeners();
		setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		fc.setFileFilter(pdfFilter);
		setPath(fc);
		
		//Set layout of components
		grant_g.radioPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		top.setLayout(new FlowLayout(FlowLayout.LEFT, 0, -1));
		bottom.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		last_buttons.setLayout(new FlowLayout(FlowLayout.LEFT, 2, 0));
		radiosPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 0, 0));
		this.setResizable(false);
		
		top.setPreferredSize(new Dimension(340, 200));
		radiosPanel.setPreferredSize(new Dimension(340, 220));
		bottom.setPreferredSize(new Dimension(340, 70));
		last_buttons.setPreferredSize(new Dimension(340, 30));
		
		add(top);
		add(radiosPanel);
		add(bottom);
		add(last_buttons);
		
		article.add(article_l);
		article.add(article_f);
		article.add(browse_b);
		top.add(article);
		
		tool_name.add(tool_name_l);
		tool_name.add(tool_name_f);
		top.add(tool_name);
		
		name.add(name_l);
		name.add(name_f);
		top.add(name);
		
		time.add(time_l);
		time.add(time_f);
		time.add(auto_b);
		top.add(time);
		
		email.add(email_l);
		email.add(email_f);
		email.add(add_b);
		email.add(clear_b);
		email_f.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
    			emails.add(email_f.getText());
    			last_email_l.setText("Last email: "+email_f.getText());
            	((JTextField)e.getSource()).setText("");
            }
		});
		top.add(email);

		last_email.add(last_email_l);
		top.add(last_email);
		
		grant.add(grant_l);
		grant.add(grant_g);
		grant.add(grant_f);
		top.add(grant);
		
		radiosPanel.add(commercial_g);
		radiosPanel.add(implementation_g);
		radiosPanel.add(progress_g);
		radiosPanel.add(result_g);

		link.add(link_l);
		link.add(link_f);
		bottom.add(link);
		
		comment.add(comment_l);
		comment.add(comment_f);
		bottom.add(comment);
		
		last_buttons.add(save_b);
		last_buttons.add(browse2_b);
		last_buttons.add(all_clear_b);
		last_buttons.add(exit_b);

		add(status_l);
	}
	

	private void registerListeners() {
		ActionListener listenerToAllButtons = new AllButtonListener();
		for (int i = 0; i < buttons.size(); i++) {
			buttons.get(i).addActionListener(listenerToAllButtons);
		}
		ActionListener listenerToGrantRadios = new GrantRadioListener();
		for (int i = 0; i < grantRadios.size(); i++) {
			grantRadios.get(i).addActionListener(listenerToGrantRadios);
		}
	}

	private class GrantRadioListener implements ActionListener {
	    public void actionPerformed(ActionEvent theEvent) {
	    	JRadioButton theButton = (JRadioButton) theEvent.getSource();
	    	if(theButton.getText().equals("yes")){
				grant_f.setEnabled(true);
	    	}else if(theButton.getText().equals("no")){
				grant_f.setText("");
				grant_f.setEnabled(false);
	        }
	    } 
	}

	private class AllButtonListener implements ActionListener {
	    public void actionPerformed(ActionEvent theEvent) {
	    	JButton theButton = (JButton) theEvent.getSource();
	    	if (theButton.getText().equals("BROWSE")){
    	        int returnVal = fc.showOpenDialog(CopyOfView.this);
    	        if (returnVal == JFileChooser.APPROVE_OPTION) {
    	            File file = fc.getSelectedFile();
    	            try {
						Desktop.getDesktop().open(file);
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
						System.out.print("error: file cannot be opened.");
					}
    	            //System.out.println("Opening: " + file.getAbsolutePath());
    	            //System.out.println("Opening: " + file.getParent());
    	            
    	            dataDirectory = file.getParent().concat(System.getProperty("file.separator")+"data.txt");
    	            System.out.println(dataDirectory);
    	            if(controller.read(dataDirectory)){
    	            	stopTimer();
    	            	startTimer();
    	            	
    	            	//Fill out directory using information read to controller's model.
    	            	article_f.setText(file.getAbsolutePath());
    	            	status_l.setText("");
    	            	
    	            	emails.clear();
    	            	emails.addAll(controller.model.emails);
    	            	if(emails.size()>=1){
    	            		last_email_l.setText("last email:"+emails.get(emails.size()-1));
    	            	}
    	            	else{last_email_l.setText("last email:none");}
    	            	
    	            	if(!controller.model.name.isEmpty()){name_f.setText(controller.model.name);}
    	            	time_f.setText(""+controller.model.time);
    	            	comment_f.setText(controller.model.comment);
    	            	tool_name_f.setText(controller.model.tool_name);
    	            	link_f.setText(""+controller.model.link);
    	            	String gt=controller.model.grant.trim();
    	            	
    	            	if(gt.equals("none")){
    	            		grant_no_r.setSelected(true);
    	            		grant_f.setText("");
    	            		grant_f.setEnabled(false);
    	            	}else if(gt.equals("")){
    	            		grant_f.setText("");
    	            	}else{
    	            		grant_yes_r.setSelected(true);
    	            		grant_f.setEnabled(true);
    	            		grant_f.setText(gt);
    	            	}

    	            	commercial_g.bg.clearSelection();
    	            	progress_g.bg.clearSelection();
    	            	implementation_g.bg.clearSelection();
    	            	result_g.bg.clearSelection();
    	            	
    	            	String cms=controller.model.commercial;
    	            	if(cms.equals("none")){
    	            		commercial_none_r.setSelected(true);
    	            	}else if(cms.equals("part")){
    	            		commercial_part_r.setSelected(true);
    	            	}else if(cms.equals("full")){
    	            		commercial_full_r.setSelected(true);
    	            	}else if(!cms.isEmpty()){status_l.setText("Error: unrecognizable commercial field in data.txt");}

    	            	String imp=controller.model.implementation;
    	            	if(imp.equals("unknown")){
    	            		implementation_unknown_r.setSelected(true);
    	            	}else if(imp.equals("yes")){
    	            		implementation_yes_r.setSelected(true);
    	            	}else if(imp.equals("no")){
    	            		implementation_no_r.setSelected(true);
    	            	}else if(!imp.isEmpty()){status_l.setText("Error: unrecognizable implementation field in data.txt");}
    	            	
    	            	String pgs=controller.model.progress;
    	            	if(pgs.equals("not_started")){
    	            		progress_not_started_r.setSelected(true);
    	            	}else if(pgs.equals("started")){
    	            		progress_started_r.setSelected(true);
    	            	}else if(pgs.equals("finished")){
    	            		progress_finished_r.setSelected(true);
    	            	}else if(!pgs.isEmpty()){status_l.setText("Error: unrecognizable progress field in data.txt");}

    	            	//OBSOLETE IN NEW VERSION//
    	            	/*String rst=controller.model.result;
    	            	if(rst.equals("found_link")){
    	            		result_found_link_r.setSelected(true);
    	            	}else if(rst.equals("no_link")){
    	            		result_no_link_r.setSelected(true);
    	            	}else if(rst.equals("broken_link")){
    	            		result_broken_link_r.setSelected(true);
    	            	}else if(!rst.isEmpty()){status_l.setText("Error: unrecognizable result field in data.txt");}*/
    	            }else{
    	            	status_l.setText("ERROR: no data.txt in the same directory.");
    	            }
    	        } 
	    	}else if(theButton.getText().equals("AUTO")){
	    			time_f.setText(""+stopTimer());
	    			//System.out.println("AAAA");
	    	}else if(theButton.getText().equals("+")){
	    			emails.add(email_f.getText());
	    			last_email_l.setText("Last email: "+email_f.getText());
	    			email_f.setText("");
	    	}else if(theButton.getText().equals("C")){
	    			emails.clear();
	    			last_email_l.setText("Last email: none");
	    	}else if(theButton.getText().equals("SAVE")){
	    			//Create a new model to store information inputted to GUI.
	    			Model m = new Model();
	    			
	    			m.comment=comment_f.getText();
	    			m.tool_name=tool_name_f.getText();
	    			m.link=link_f.getText();
	    			m.name=name_f.getText();
	    			m.verify_comment = controller.model.verify_comment;
	    			m.verify_status = controller.model.verify_status;
	    			m.verify_name = controller.model.verify_name;
	    			m.bibtex_link = controller.model.bibtex_link;
	    			m.bibtex_label = controller.model.bibtex_label;
	    			
	    			if(commercial_g.getSelection()!=null)
	    				m.commercial=(commercial_g.getSelection()).getText();
	    			
	    			//Checks to see whether the email in text field should be added
	    			if(!email_f.getText().trim().isEmpty()){
		    			boolean textFieldIsNewEmail = true;
		    			for(String s:emails){
		    				if(s.trim().equals(email_f.getText().trim()))
		    					textFieldIsNewEmail = false;
		    			}
		    			if(textFieldIsNewEmail){
		    				emails.add(email_f.getText());
		    				last_email_l.setText("Last email: "+email_f.getText());
		    				email_f.setText("");
		    			}
	    			}
	    			m.emails=emails;
	    			
	    			if(grant_g.getSelection()!=null){
	    				if(grant_f.isEnabled()){
	    					m.grant = grant_f.getText();
	    				}else{
	    					m.grant = "none";
	    				}
	    			}
	    			if(implementation_g.getSelection()!=null){
	    				m.implementation=(implementation_g.getSelection()).getText();
	    			}
	    			if(progress_g.getSelection()!=null){
	    				m.progress=(progress_g.getSelection()).getText();
	    			}
	    			if(result_g.getSelection()!=null){
	    				System.out.println("result has selected");
    	            	//OBSOLETE IN NEW VERSION//
	    				//m.result=(result_g.getSelection()).getText();
	    			}else{
	    				System.out.println("result has not selected");
	    			}
	    			
	    			//Sanity check for the time field
	    			boolean parsable = true;
	    			try{
	    				Integer.parseInt(time_f.getText());
	    			}catch(NumberFormatException e){
	    				parsable = false;
	    			}
	    			if(parsable){
	        			m.time=Integer.parseInt(time_f.getText());
	        		}else{m.time=-1;}
	    			
	    			if(implementation_no_r.isSelected()){
	    				m.email_status="not_needed";
	    				m.build_status="not_needed";
	    			}else if(result_no_link_r.isSelected()){
	    				m.email_status="unknown";
	    				m.build_status="unknown";
	    			}
	    			
	    			//Call controller to save the new .txt file along with backup.
	    			boolean a = controller.save(dataDirectory, m);
	    			if(!a){
	    				status_l.setText("ERROR: save path does not exist.");
	    			}else{status_l.setText("save complete.");}
	    			
	    	}else if(theButton.getText().equals("ALL CLEAR")){
	    			name_f.setText("");
	    			tool_name_f.setText("");
	    			article_f.setText("");
	    			link_f.setText("");
	    			time_f.setText("");
	    			grant_f.setText("");
	    			comment_f.setText("");
	    			email_f.setText("");
	            	emails.clear();
	        }else if(theButton.getText().equals("EXIT")){
	    			System.exit(0);
	    	}
	    }	
	}
}
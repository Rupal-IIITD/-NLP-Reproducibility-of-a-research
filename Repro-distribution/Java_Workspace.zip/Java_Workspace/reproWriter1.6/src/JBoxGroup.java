import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.border.LineBorder;

public class JBoxGroup extends JPanel{

	public ArrayList<JCheckBox> buttonArray = new ArrayList<JCheckBox>();
    //public JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
	public JPanel boxPanel = new JPanel();
	public JPanel labelPanel = new JPanel();

    public JBoxGroup(){
    	this(0, 1);
    }
    
    public JBoxGroup(int rows, int cols){
		super();
		this.setAlignmentX(CENTER_ALIGNMENT);
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		boxPanel.setAlignmentX(LEFT_ALIGNMENT);
		boxPanel.setLayout(new GridLayout(rows, cols));
		//radioPanel.setBorder(new LineBorder(Color.red, 1, true));
    }
	
	public void add(JCheckBox jc){
		this.add(boxPanel);
		boxPanel.add(jc);
		buttonArray.add(jc);
		jc.setAlignmentX(0.0f);
		jc.setMargin(null);
	}
	
	public void add_label(JLabel jc){
		add(jc);

		/*
		labelPanel.setAlignmentX(LEFT_ALIGNMENT);
		labelPanel.add(jc);
		add(labelPanel);
		*/
	}
	
	public boolean checkSelection(String item){
		for(JCheckBox jcb:buttonArray){
			//System.out.print("test"+jrb.getText());
			if(jcb.isSelected() && jcb.getText().equals(item)){return true;}
		}
		return false;
	}
	
	public void disable(){
		clearSelection();
		for(JCheckBox jcb:buttonArray){
			jcb.setEnabled(false);
		}
	}
	
	public void clearSelection(){
		for(JCheckBox jcb:buttonArray){
			jcb.setSelected(false);
		}
	}
	
	public void enable(){
		for(JCheckBox jcb:buttonArray){
			jcb.setEnabled(true);
		}
	}
}
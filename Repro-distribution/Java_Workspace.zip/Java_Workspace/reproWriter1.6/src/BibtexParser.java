import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

public class BibtexParser {

	private static int NOT_ENOUGH_ARGS = 0;
	private static int INVALID_PATH = 1;
	private static int UNKNOWN_ARG = 2;
	private static int READ_ERROR = 2;

	public static int ARTICLE = 0;
	public static int PROCEEDING = 1;

	public static void main(String[] args) {
		// Check proper usage
		if (args.length < 2) {
			printUsage(NOT_ENOUGH_ARGS);
		}

		// Initialize variables
		String bib_path = "";
		String content;

		for (String arg : args) {
			if (bib_path.equals("")) {
				bib_path = arg; // the first argument should be the directory
				continue;
			}

			content = loadBibtex(bib_path);

			if (arg.equals("-author")) {
				System.out.println(parseBibtex(ARTICLE, "author", content));
			} else if (arg.equals("-title")) {
				System.out.println(parseBibtex(ARTICLE, "title", content));
			} else {
				System.out.println(parseBibtex(ARTICLE, arg.substring(1, arg.length()-1), content));
			}
		}

	}

	public static String parseBibtex(int location, String field, String bibtex) {
		String field_content;
		int start_paren = 0;
		int end_paren = 0;
		int depth = 0;
		int begin = 0;
		if (location == ARTICLE) {
			begin = bibtex.indexOf("@inproceedings");
			if (begin == -1)
				begin = bibtex.indexOf("@article");
		} else if (location == PROCEEDING) {
			begin = bibtex.indexOf("@proceedings");
		} else {
			System.out.println("Unknown argument for location");
			return "ERROR";
		}
		field_content = bibtex.substring(begin);
		// Assuming first line is for the section
		field_content = field_content.substring(field_content.indexOf("\n") + 1);

		while (true) {
			start_paren = field_content.indexOf("{");
			end_paren = start_paren + 1;
			depth = 1;
			while (depth > 0 && end_paren < field_content.length()) {
				if (field_content.charAt(end_paren) == '{')
					depth++;
				if (field_content.charAt(end_paren) == '}')
					depth--;
				if (field_content.charAt(end_paren) == '\\')
					end_paren++;
				end_paren++;
			}
			if (field_content.indexOf(field) < start_paren) {
				field_content = field_content.substring(start_paren + 1, end_paren - 1);
				break;
			} else {
				field_content = field_content.substring(end_paren);
			}

		}
		field_content = field_content.replaceAll("[\\n\\t]", "");

		// Special format for authors
		if (field.equals("author")) {
			Scanner author_scan = new Scanner(field_content);
			String sub;
			String name = "";
			ArrayList<String> authors = new ArrayList<String>();
			while (author_scan.hasNext()) {
				sub = author_scan.next();
				if (sub.equals("and")) {
					authors.add(formatBibtexAuthor(name));
					name = "";
				} else {
					name = (name.equals("")) ? sub : name + " " + sub;
					if (!author_scan.hasNext()) {
						authors.add(formatBibtexAuthor(name));
					}
				}
			}
			field_content = authors.toString().replaceAll("[\\[\\],]", "");
		} else {
			field_content = removeBibtexSpecial(field_content);
			field_content = field_content.replaceAll(" +", " ");
		}

		//System.out.println(field_content);
		return field_content;
	}

	public static String loadBibtex(String bib_path) {
		String result = "";
		try {
			result = new Scanner(new File(bib_path)).useDelimiter("\\Z").next();
			//System.out.println(result);
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			System.out.println("Cannot read bibtex at: " + bib_path);
			printUsage(READ_ERROR);
			System.exit(1);
		}
		return result;
	}

	private static void printUsage(int error_code) {
		if (error_code == NOT_ENOUGH_ARGS) {
			System.out.println("Incorrect arguement count. Usage: java -jar bibtexParser PATH_TO_BIB [option]");
		} else if (error_code == INVALID_PATH) {
			System.out.println("Invalid path. Usage: java -jar bibtexParser PATH_TO_BIB [option]");
		} else if (error_code == UNKNOWN_ARG) {
			System.out.println("Unknown argument. Usage: java -jar bibtexParser PATH_TO_BIB [option]");
		} else if (error_code == READ_ERROR) {
			System.out.println("Read error. Usage: java -jar bibtexParser PATH_TO_BIB [option]");
		}
		System.out.println("-author  to return author list. Ex: Bob_Jones Sammy_Smith");
		System.out.println("-title   to return paper title.");
		System.out.println("If both options, results on seperate lines based on order of input");
		System.out.println("Example: java -jar bibtexParser pldi12/GazzilloG12/paper.bib -author");
		System.exit(1);
	}

	public static String formatBibtexAuthor(String str) {
		str = removeBibtexSpecial(str);
		// If they put a comma, names need to switch around it
		int pivot = str.indexOf(",");
		if (pivot != -1)
			str = str.substring(pivot + 1, str.length()) + " " + str.substring(0, pivot);
		str = str.replace(' ', '_');
		return str;
	}

	public static String removeBibtexSpecial(String str) {
		str = str.replace("{\\'e}", "e");
		str = str.replace("{\\c{c}}", "c");
		str = str.replace("{\\\"u}", "u");
		str = str.replace("{\\'U}", "U");
		str = str.replace("{\\\"a}", "a");
		
		str = str.replace("\\c{c}", "c");
		str = str.replace("{\\'o}", "o");
		str = str.replace("{\\'u}", "u");
		str = str.replace("{\\'A}", "A");
		str = str.replace("{\\'a}", "a");
		str = str.replace("{\\'E}", "E");
		str = str.replace("\\'{\\i}", "i");
		str = str.replace("{\\'a}", "a");
		str = str.replace("{\\~n}", "n");
		str = str.replace("{\\'A}", "A");
		str = str.replace("{\\ss}", "ss");
		str = str.replace("{\\\"O}", "O");
		str = str.replace("{\\\"e}", "e");
		str = str.replace("{\\\"o}", "o");
		str = str.replace("{\\o}", "o");
		str = str.replace("\\`{\\i}", "i");
		str = str.replace("{\\\"O}", "O");
		str = str.replace("{\\`e}", "e");
		str = str.replace("\\^{\\i}", "i");
		//str = str.replace("{\\'e}", "e");
		return str;
	}
}

import java.io.*;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Controller {
	public Model model;
	public String name;
	public BufferedReader reader;
	public String line;
	public String log;
	public static final int err_timeNotValid = 1;
	public static final int err_extraText = 2;
	public static final int err_unrecognizableTag = 3;
	public static final int err_missingTag = 4;
	public static final int err_notEmail = 5;
	public static final int err_unrecognizableField = 6;
	public static final int err_duplicateField = 7;
	public static final int err_missingField = 8;
	public static final int err_notUrl = 9;
	
	private int line_counter = 0;
	public String err_helper = "";
	public String error_log = "";
	private Pattern emailPattern;
	private Pattern namePattern;
	private Matcher emailMatcher;
	private Matcher nameMatcher;
	public boolean data_is_empty = true;
	public boolean quiet = false;
 
	//Regex pattern for email-matching
	private final String EMAIL_PATTERN =  "[_A-Za-z0-9-+]+(\\.[_A-Za-z0-9-+]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,4})";
	//Regex pattern for name-matching
	private final String NAME_PATTERN =  "[-A-Za-z]+_[-A-Za-z.]+(_[-A-Za-z]+)?+(_[-A-Za-z]+)?";

	public fieldCount[] fields = new fieldCount[TOTAL_FIELDS];
	
	public static final int ARTICLE_NAME = 0;
	public static final int ARTICLE_TIME = 1;
	public static final int ARTICLE_COMMENT = 2;
	public static final int ARTICLE_COMMERCIAL = 3;
	public static final int ARTICLE_GRANT = 4;
	public static final int ARTICLE_NSF = 5;
	public static final int ARTICLE_IMPLEMENTATION = 6;
	public static final int ARTICLE_LINK = 7;
	public static final int ARTICLE_STATUS = 8;
	public static final int EMAIL_REAL = 9;
	public static final int BIBTEX_LABEL = 10;
	public static final int AUTHOR_NAME = 11;
	public static final int BIBTEX_LINK = 12;
	public static final int BUILD_NAME = 13;
	public static final int BUILD_TIME = 14;
	public static final int BUILD_COMMENT = 15;
	public static final int BUILD_STATUS = 16;
	public static final int EMAIL_STATUS = 17;
	public static final int TOOL_NAME = 18;
	public static final int TOOL_ARTICLE_LINK = 19;
	public static final int TOOL_GOOGLE_LINK = 20;
	public static final int TOOL_EMAIL_LINK = 21;
	public static final int TOOL_DATA_LINK = 22;
	public static final int VERIFY_NAME = 23;
	public static final int VERIFY_STATUS = 24;
	public static final int VERIFY_COMMENT = 25;
	public static final int EMAIL_CODE = 26;
	public static final int EMAIL_REMARK = 27;
	
	public static final int TOTAL_FIELDS = 28;
	
	public Controller(){
		quiet = false;
		//Stores the field, number of occurrences of that field, the specific String used to match that field. 
		fields[ARTICLE_NAME] = new fieldCount("ARTICLE:ANALYSIS_BY[name]", "ARTICLE:ANALYSIS_BY");
		fields[ARTICLE_TIME] = new fieldCount("ARTICLE:ANALYSIS_TIME[minutes]", "ARTICLE:ANALYSIS_TIME");
		fields[ARTICLE_COMMENT] = new fieldCount("ARTICLE:COMMENT[string]", "ARTICLE:COMMENT");
		fields[ARTICLE_COMMERCIAL] = new fieldCount("ARTICLE:COMMERCIAL_EFFORT[none,part,full]", "ARTICLE:COMMERCIAL_EFFORT");
		fields[ARTICLE_GRANT] = new fieldCount("ARTICLE:GRANT_SUPPORT[none", "ARTICLE:GRANT");
		fields[ARTICLE_NSF] = new fieldCount("ARTICLE:NSF-SUPPORT[none", "ARTICLE:NSF_SUPPORT");
		fields[ARTICLE_IMPLEMENTATION] = new fieldCount("ARTICLE:IMPLEMENTATION_EXISTS[unknown,hardware,yes,no]", "ARTICLE:IMPLEMENTATION_EXISTS");
		fields[ARTICLE_LINK] = new fieldCount("ARTICLE:LINK[url]", "ARTICLE:LINK");
		fields[ARTICLE_STATUS] = new fieldCount("ARTICLE:STATUS[not_finished,finished]", "ARTICLE:STATUS");
		fields[EMAIL_REAL] = new fieldCount("AUTHOR:EMAIL_REAL[list", "AUTHOR:EMAIL_REAL");
		fields[BIBTEX_LABEL] = new fieldCount("BIBTEX:LABEL[string]", "AUTHOR:BIBTEX_LABEL");
		fields[AUTHOR_NAME] = new fieldCount("AUTHOR:NAMES[list", "AUTHOR:NAMES");
		fields[BIBTEX_LINK] = new fieldCount("BIBTEX:LINK[url]", "AUTHOR:BIBTEX_LINK");
		fields[BUILD_NAME] = new fieldCount("BUILD:ANALYSIS_BY[name]", "BUILD:ANALYSIS_BY");
		fields[BUILD_TIME] = new fieldCount("BUILD:ANALYSIS_TIME[minutes]", "BUILD:ANALYSIS_TIME");
		fields[BUILD_COMMENT] = new fieldCount("BUILD:COMMENT[string]", "BUILD:COMMENT");
		fields[BUILD_STATUS] = new fieldCount("BUILD:STATUS[one", "BUILD:STATUS");
		fields[EMAIL_STATUS] = new fieldCount("EMAIL:STATUS[unknown,not_needed,not_found", "EMAIL_STATUS");
		fields[TOOL_NAME] = new fieldCount("TOOL:NAME[string]", "TOOL:NAME");
		fields[TOOL_ARTICLE_LINK] = new fieldCount("TOOL:ARTICLE_LINK[unknown,none,url,broken", "TOOL:ARTICLE_LINK");
		fields[TOOL_GOOGLE_LINK] = new fieldCount("TOOL:GOOGLE_LINK[unknown,none,url,broken", "TOOL:GOOGLE_LINK");
		fields[TOOL_EMAIL_LINK] = new fieldCount("TOOL:EMAIL_LINK[unknown,none,sent_no_url,url,broken", "TOOL:EMAIL_LINK");
		fields[TOOL_DATA_LINK] = new fieldCount("TOOL:DATA_LINK[unknown,none,url,broken", "TOOL:DATA_LINK");
		fields[VERIFY_NAME] = new fieldCount("VERIFY:ANALYSIS_BY[name]", "VERIFY:ANALYSIS_BY");
		fields[VERIFY_STATUS] = new fieldCount("VERIFY:STATUS[unknown,needed,not_needed,started,finished]", "VERIFY:STATUS");
		fields[VERIFY_COMMENT] = new fieldCount("VERIFY:COMMENT[string]", "VERIFY:COMMENT");
		fields[EMAIL_CODE] = new fieldCount("EMAIL1:CODE_AVAILABLE[yes,no,no_response]", "EMAIL1:CODE_AVAILABLE");
		fields[EMAIL_REMARK] = new fieldCount("EMAIL1:REMARK[comment]", "EMAIL1:REMARK");
		//fields[VERIFY_BUILD_NAME] = new fieldCount("VERIFY_BUILD:ANALYSIS_BY[name]", "VERIFY_BUILD:ANALYSIS_BY");
		//fields[VERIFY_BUILD_STATUS] = new fieldCount("VERIFY_BUILD:STATUS[unknown,needed,not_needed,started,finished]", "VERIFY_BUILD:STATUS");
		//fields[VERIFY_BUILD_COMMENT] = new fieldCount("VERIFY_BUILD:COMMENT[string]", "VERIFY_BUILD:COMMENT");
		emailPattern = Pattern.compile(EMAIL_PATTERN);
		namePattern = Pattern.compile(NAME_PATTERN);
	}

	public Controller(boolean q){
		this();
		quiet = q;
	}
	
	public static void main(String[] args){
		if(args.length == 0){System.out.print("Too few arguements. Usage: java -jar Debug [filename]");System.exit(1);}
		if(args.length == 1){Controller c = new Controller(false); c.read(args[0]);}
		if(args.length == 2){
			Controller c;
			if(args[0].charAt(0)=='-')
			{
				if(args[0].equals("-q")){
					c = new Controller(true);c.read(args[1]);
				}else{System.out.print("Too many arguements. Usage: java -jar Debug [-q] [filename]");System.exit(1);}
			}else{c = new Controller(false);c.read(args[1]);}
		}
		if(args.length >2){System.out.print("Too many arguements. Usage: java -jar Debug [-q] [filename]");System.exit(1);}
	}
	
	public boolean isUrl(String str){
		if(str.length()>5){
			String sub = str.substring(0, 3).toLowerCase();
			if(sub.equals("htt") || sub.equals("ftp") || sub.equals("www")){return true;}
			else{return false;}
		}else return false;
	}
	
	public boolean read(String dir){
        for(int i=0;i<TOTAL_FIELDS;i++){fields[i].occ=0;}
		error_log = new String();
		line_counter = 0;
		data_is_empty = true;
		model = new Model();
        File inFile  = new File(dir);
        try {
			reader = new BufferedReader(new FileReader(inFile));
	        while((line=reader.readLine()) != null){
	        	line_counter++;
	            Scanner s2 = new Scanner(line);
		        while (s2.hasNext()) {
		            String s = s2.next();
            		if(s.equals(fields[ARTICLE_NAME].id)){
            			fields[ARTICLE_NAME].occ++;
            			if(fields[ARTICLE_NAME].occ>1){
            				error(err_duplicateField, "ARTICLE:ANALYSIS_BY", line);
            			}
	            		if(s2.hasNext()){
	            			data_is_empty = false;
	            			model.name = s2.next();
	            			if(s2.hasNext())
	            				error(err_extraText, "ARTICLE:ANALYSIS_BY", line);}
	            	}else if(s.equals(fields[ARTICLE_TIME].id)){
            			fields[ARTICLE_TIME].occ++;
            			if(fields[ARTICLE_TIME].occ>1){
            				error(err_duplicateField, "ARTICLE:ANALYSIS_TIME", line);
            			}
	            		if(s2.hasNext()){
	            			if(s2.hasNextInt()){
	            				model.time = s2.nextInt();
	            				if(model.time<=0){error(err_timeNotValid, "ARTICLE:ANALYSIS_TIME", line);}
	            			}else
	            				error(err_timeNotValid, "ARTICLE:ANALYSIS_TIME", line);
	            			if(s2.hasNext())
	            				error(err_extraText, "ARTICLE:ANALYSIS_TIME", line);
	            		}else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:ANALYSIS_TIME", line);
	            			}
	            		}
	            	}else if(s.equals(fields[ARTICLE_COMMENT].id)){
            			fields[ARTICLE_COMMENT].occ++;
            			if(fields[ARTICLE_COMMENT].occ>1){
            				error(err_duplicateField, "ARTICLE:COMMENT", line);
            			}
	            		while(s2.hasNext()){
	            			String a = s2.next();
	            			model.comment = model.comment.concat(a+" ");}
		           	}else if(s.equals(fields[ARTICLE_COMMERCIAL].id)){
            			fields[ARTICLE_COMMERCIAL].occ++;
            			if(fields[ARTICLE_COMMERCIAL].occ>1){
            				error(err_duplicateField, "ARTICLE:COMMERCIAL_EFFORT", line);
            			}
            			if(s2.hasNext()){
	            			model.commercial = s2.next();
	            			if(!model.commercial.equals("none") && !model.commercial.equals("part") && !model.commercial.equals("full")){
	            				err_helper="Acceptable tags include 'none', 'part', and 'full'.";
	            				error(err_unrecognizableTag, "ARTICLE:COMMERCIAL_EFFORT", line);}
	            			if(s2.hasNext())
	            				error(err_extraText, "ARTICLE:COMMERCIAL_EFFORT", line);
	            		}else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:COMMERCIAL_EFFORT", line);
	            			}
	            		}
	            	}else if(s.equals("ARTICLE:DOI")){
	            		if(s2.hasNext()){
	            			model.link=s2.next();
	            			if(s2.hasNext())
	            				error(err_extraText, "ARTICLE:DOI", line);}
	            	}else if(s.equals(fields[ARTICLE_GRANT].id)){
            			fields[ARTICLE_GRANT].occ++;
            			if(fields[ARTICLE_GRANT].occ>1){
            				error(err_duplicateField, "ARTICLE:GRANT", line);
            			}
	            		for(int i = 0;i<2;i++){
	            			if (s2.hasNext())
	            				s2.next();
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);}
	            		}
	            		if(s2.hasNext()){
		            		while(s2.hasNext()){
		            			String a = s2.next();
		            			model.grant=model.grant.concat(a+" ");
		            		}
	            		}else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:GRANT", line);
	            			}
	            		}
	            	}else if(s.equals(fields[ARTICLE_NSF].id)){
            			fields[ARTICLE_NSF].occ++;
            			if(fields[ARTICLE_NSF].occ>1){
            				error(err_duplicateField, "ARTICLE:NSF-SUPPORT", line);
            			}
	            		for(int i = 0;i<2;i++){
	            			if (s2.hasNext())
	            				s2.next();
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);}
	            		}
	            		if(s2.hasNext()){
		            		while(s2.hasNext()){
		            			String a = s2.next();
		            			model.grant_NSF=model.grant_NSF.concat(a+" ");
		            		}
	            		}else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:NSF-SUPPORT", line);
	            			}
	            		}
	            	}else if(s.equals(fields[ARTICLE_IMPLEMENTATION].id)){
            			fields[ARTICLE_IMPLEMENTATION].occ++;
            			if(fields[ARTICLE_IMPLEMENTATION].occ>1){
            				error(err_duplicateField, "ARTICLE:IMPLEMENTATION_EXISTS", line);
            			}
            			if(s2.hasNext()){
	            			model.implementation = s2.next();
		            		if(!model.implementation.equals("unknown") 
		            			&& !model.implementation.equals("yes") 
		            			&& !model.implementation.equals("no") 
		            			&& !model.implementation.equals("hardware")){
		            			err_helper="Acceptable tags include 'unknown', 'hardware', 'yes', and 'no'";
		            			error(err_unrecognizableTag, "ARTICLE:IMPLEMENTATION_EXISTS", line);}
	            			if(s2.hasNext())
	            				error(err_extraText, "ARTICLE:IMPLEMENTATION_EXISTS", line);
	            		}else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:IMPLEMENTATION_EXISTS", line);
	            			}
	            		}
	            	}else if(s.equals(fields[ARTICLE_LINK].id)){
            			fields[ARTICLE_LINK].occ++;
            			if(fields[ARTICLE_LINK].occ>1){
            				error(err_duplicateField, "ARTICLE:LINK", line);
            			}
            			if(s2.hasNext()){
		            		model.link=s2.next();
			           		if(s2.hasNext())
			           			error(err_extraText, "ARTICLE:LINK", line);}
            			else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:LINK", line);
	            			}
	            		}
	            	}else if(s.equals(fields[ARTICLE_STATUS].id)){
            			fields[ARTICLE_STATUS].occ++;
            			if(fields[ARTICLE_STATUS].occ>1){
            				error(err_duplicateField, "ARTICLE:STATUS", line);
            			}
            			if (s2.hasNext()){
            				model.progress = s2.next();
            				if(!model.progress.equals("not_finished") && 
	            				!model.progress.equals("finished")){
		            			err_helper="Acceptable tags include 'not_finished' and 'finished'.";
            					error(err_unrecognizableTag, "ARTICLE:STATUS", line);
		            			if (s2.hasNext())
			            			error(err_extraText, "ARTICLE:STATUS", line);}
            			}else{
	            			if(!data_is_empty){
	            				error(err_missingTag ,"ARTICLE:STATUS", line);
	            			}
	            		}
	            	}else if(s.equals(fields[EMAIL_REAL].id)){
            			fields[EMAIL_REAL].occ++;
            			if(fields[EMAIL_REAL].occ>1){
            				error(err_duplicateField, "AUTHOR:EMAIL_REAL", line);
            			}
	            		for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
	            		while(s2.hasNext()){
	            			String unchecked_email = s2.next();
	            			if(unchecked_email!=null){
	            				if(!unchecked_email.isEmpty()){
	            					if(unchecked_email.charAt(unchecked_email.length()-1)==','){
	            						unchecked_email = unchecked_email.substring(0, unchecked_email.length()-1);
	            					}
	            				}
	            				emailMatcher = emailPattern.matcher(unchecked_email);
		            			if(!emailMatcher.matches()){
			            			err_helper=unchecked_email;
	            					error(err_notEmail, "AUTHOR:EMAIL_REAL", line);
		            			}
	            			}
	            			model.emails.add(unchecked_email);
	            		}
            		}else if(s.equals(fields[BIBTEX_LABEL].id)){
            			fields[BIBTEX_LABEL].occ++;
            			if(fields[BIBTEX_LABEL].occ>1){
            				error(err_duplicateField, "BIBTEX:LABEL", line);
            			}
	            		if(s2.hasNext()){
	            			model.bibtex_label = s2.next();
	            			if(s2.hasNext())
	            				error(err_extraText, "BIBTEX:LABEL", line);}
					}else if(s.equals(fields[AUTHOR_NAME].id)){
            			fields[AUTHOR_NAME].occ++;
            			if(fields[AUTHOR_NAME].occ>1){
            				error(err_duplicateField, "AUTHOR:NAMES", line);
            			}
	            		for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
	            		while(s2.hasNext()){
	            			String unchecked_name = s2.next();
	            			if(unchecked_name!=null){
	            				if(!unchecked_name.isEmpty()){
	            					if(unchecked_name.charAt(0)=='_'){
	            						unchecked_name = unchecked_name.substring(1, unchecked_name.length());
	            					}
	            				}
	            				nameMatcher = namePattern.matcher(unchecked_name);
		            			if(!nameMatcher.matches()){
			            			err_helper=unchecked_name;
	            					error(err_notEmail, "AUTHOR:NAMES", line);
		            			}
	            			}
	            			model.authors.add(unchecked_name);
	            		}
            		}else if(s.equals(fields[BIBTEX_LINK].id)){
            			fields[BIBTEX_LINK].occ++;
            			if(fields[BIBTEX_LINK].occ>1){
            				error(err_duplicateField, "BIBTEX:LINK", line);
            			}
	            		if(s2.hasNext()){
	            			model.bibtex_link = s2.next();
	            			if(s2.hasNext())
	            				error(err_extraText, "BIBTEX:LINK", line);}
	            	}else if(s.equals(fields[BUILD_NAME].id)){
            			fields[BUILD_NAME].occ++;
            			if(fields[BUILD_NAME].occ>1){
            				error(err_duplicateField, "BUILD:ANALYSIS_BY", line);
            			}
	            		if(s2.hasNext()){
	            			model.build_name = s2.next();
		            		if(s2.hasNext())
		            			error(err_extraText, "BUILD:ANALYSIS_BY", line);}
	            	}else if(s.equals(fields[BUILD_TIME].id)){
            			fields[BUILD_TIME].occ++;
            			if(fields[BUILD_TIME].occ>1){
            				error(err_duplicateField, "BUILD:ANALYSIS_TIME", line);
            			}if(s2.hasNext()){
	            			if(s2.hasNextInt()){
	            				model.build_time = s2.nextInt();
	            				if(model.build_time<=0){error(err_timeNotValid, "ARTICLE:ANALYSIS_TIME", line);}
	            			}else
	            				error(err_timeNotValid, "BUILD:ANALYSIS_TIME", line);
		            		if(s2.hasNext())
		            			error(err_extraText, "BUILD:ANALYSIS_TIME", line);}
	            	}else if(s.equals(fields[BUILD_COMMENT].id)){
            			fields[BUILD_COMMENT].occ++;
            			if(fields[BUILD_COMMENT].occ>1){
            				error(err_duplicateField, "BUILD:COMMENT", line);
            			}
	            		while(s2.hasNext()){
	            			String a = s2.next();
	            			model.build_comment=model.build_comment.concat(a+" ");
	            		}
	            	}else if(s.equals(fields[BUILD_STATUS].id)){
            			fields[BUILD_STATUS].occ++;
            			if(fields[BUILD_STATUS].occ>1){
            				error(err_duplicateField, "BUILD:STATUS", line);
            			}
            			for(int i = 0;i<6;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line); break;}
	            		}
	            		if(s2.hasNext()){
	            			model.build_status = s2.next();
		            		if(!model.build_status.equals("unknown") 
		            			&& !model.build_status.equals("needed") 
		            			&& !model.build_status.equals("not_needed") 
		            			&& !model.build_status.equals("started")
		            			&& !model.build_status.equals("finished")){
		            			err_helper="Acceptable tags include 'unknown', 'needed', 'not_needed', 'started', and 'finished'";
		            			error(err_unrecognizableTag, "BUILD:STATUS", line);}
		            		for(int i = 0;i<3;i++){
		            			if (s2.hasNext()){
		            				String next = s2.next();
				            		if(next.equals("downloaded")) {model.build_download = true;}
				            		else if(next.equals("compiles")) {model.build_compiles = true;}
				            		else if(next.equals("runs")) {model.build_runs = true;}
				            		else {error(err_unrecognizableTag, "BUILD:STATUS", line);break;}
		            			}
		            		}
		            		if(s2.hasNext())
		            			error(err_extraText, "BUILD:STATUS", line);
	            		}
	            	}else if(s.equals(fields[EMAIL_STATUS].id)){
            			fields[EMAIL_STATUS].occ++;
            			if(fields[EMAIL_STATUS].occ>1){
            				error(err_duplicateField, "EMAIL_STATUS", line);
            			}
            			for(int i = 0;i<4;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
	            		//EMAIL:STATUS[unknown,not_needed or list of {needed,request_1,response_1,sent_thank_you}] 
	            		if(s2.hasNext()){
	            			model.email_status = s2.next();
		            		if(!model.email_status.equals("unknown") 
		            			&& !model.email_status.equals("not_needed") 
		            			&& !model.email_status.equals("needed")){
		            			err_helper="Acceptable tags include 'unknown', 'needed', and 'not_needed";
		            			error(err_unrecognizableTag, "EMAIL:STATUS", line);}
		            		if(model.email_status.equals("needed")){
			            		for(int i = 0;i<3;i++){
			            			if (s2.hasNext()){
			            				String next = s2.next();
					            		if(next.equals("request_1")) {model.email_request_1 = true;}
					            		else if(next.equals("response_1")) {model.email_response_1 = true;}
					            		else if(next.equals("sent_thank_you")) {model.email_sent_thank_you = true;}
					            		else {error(err_unrecognizableTag, "EMAIL:STATUS", line);break;}
			            			}
			            		}
			            	}
		            		if(s2.hasNext())
		            			error(err_extraText, "EMAIL:STATUS", line);
	            		}
	            	}else if(s.equals(fields[TOOL_NAME].id)){
            			fields[TOOL_NAME].occ++;
            			if(fields[TOOL_NAME].occ>1){
            				error(err_duplicateField, "TOOL:NAME", line);
            			}
            			while(s2.hasNext()){
	            			String a = s2.next();
	            			model.tool_name=model.tool_name.concat(a+" ");
	            		}
	            	}else if(s.equals(fields[TOOL_ARTICLE_LINK].id)){
            			fields[TOOL_ARTICLE_LINK].occ++;
            			if(fields[TOOL_ARTICLE_LINK].occ>1){
            				error(err_duplicateField, fields[TOOL_ARTICLE_LINK].fieldName, line);
            			}
            			for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
            			if(s2.hasNext()){
            				String field1 = s2.next();
    						model.tool_article_link = field1;
            				String field2 = null;
            				if(s2.hasNext()){field2 = s2.next(); model.tool_article_link_url = field2;}
        					if(field1.equals("broken")){
        						if(field2!=null){
        							if(!isUrl(field2)){
    			            			err_helper=field2;
    	            					error(err_notUrl, fields[TOOL_ARTICLE_LINK].fieldName, line);
    	            				}
        						}else{error(err_missingTag, fields[TOOL_ARTICLE_LINK].fieldName, line);}
        					}else if(field1.equals("unknown") || field1.equals("none")){
    	            			if(field2!=null){error(err_extraText, fields[TOOL_ARTICLE_LINK].fieldName, line);}
        					}else if(isUrl(field1)){
        						model.tool_article_link_url = field1;
    	            			if(field2!=null){error(err_extraText, fields[TOOL_ARTICLE_LINK].fieldName, line);}
		            		}else{
		            			err_helper=field1;
            					error(err_notUrl, "TOOL:ARTICLE_LINK", line);
    	            			if(field2!=null){error(err_extraText, fields[TOOL_ARTICLE_LINK].fieldName, line);}
		            		}
		            	}
	            	}else if(s.equals(fields[TOOL_GOOGLE_LINK].id)){
            			fields[TOOL_GOOGLE_LINK].occ++;
            			if(fields[TOOL_GOOGLE_LINK].occ>1){
            				error(err_duplicateField, fields[TOOL_GOOGLE_LINK].fieldName, line);
            			}
            			for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
            			if(s2.hasNext()){
            				String field1 = s2.next();
    						model.tool_google_link = field1;
            				String field2 = null;
            				if(s2.hasNext()){field2 = s2.next(); model.tool_google_link_url = field2;}
        					if(field1.equals("broken")){
        						if(field2!=null){
        							if(!isUrl(field2)){
    			            			err_helper=field2;
    	            					error(err_notUrl, fields[TOOL_GOOGLE_LINK].fieldName, line);
    	            				}
        						}else{error(err_missingTag, fields[TOOL_GOOGLE_LINK].fieldName, line);}
        					}else if(field1.equals("unknown") || field1.equals("none")){
    	            			if(field2!=null){error(err_extraText, fields[TOOL_GOOGLE_LINK].fieldName, line);}
        					}else if(isUrl(field1)){
        						model.tool_google_link_url = field1;
    	            			if(field2!=null){error(err_extraText, fields[TOOL_GOOGLE_LINK].fieldName, line);}
		            		}else{
		            			err_helper=field1;
            					error(err_notUrl, "TOOL:ARTICLE_LINK", line);
    	            			if(field2!=null){error(err_extraText, fields[TOOL_GOOGLE_LINK].fieldName, line);}
		            		}
		            	}
	            	}else if(s.equals(fields[TOOL_EMAIL_LINK].id)){
            			fields[TOOL_EMAIL_LINK].occ++;
            			if(fields[TOOL_EMAIL_LINK].occ>1){
            				error(err_duplicateField, fields[TOOL_EMAIL_LINK].fieldName, line);
            			}
            			for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
            			if(s2.hasNext()){
            				String field1 = s2.next();
    						model.tool_email_link = field1;
            				String field2 = null;
            				if(s2.hasNext()){field2 = s2.next(); model.tool_email_link_url = field2;}
        					if(field1.equals("broken")){
        						if(field2!=null){
        							if(!isUrl(field2)){
    			            			err_helper=field2;
    	            					error(err_notUrl, fields[TOOL_EMAIL_LINK].fieldName, line);
    	            				}
        						}else{error(err_missingTag, fields[TOOL_EMAIL_LINK].fieldName, line);}
        					}else if(field1.equals("unknown") || field1.equals("none") || field1.equals("sent_no_url")){
    	            			if(field2!=null){error(err_extraText, fields[TOOL_EMAIL_LINK].fieldName, line);}
        					}else if(isUrl(field1)){
        						model.tool_email_link_url = field1;
    	            			if(field2!=null){error(err_extraText, fields[TOOL_EMAIL_LINK].fieldName, line);}
		            		}else{
		            			err_helper=field1;
            					error(err_notUrl, "TOOL:ARTICLE_LINK", line);
    	            			if(field2!=null){error(err_extraText, fields[TOOL_EMAIL_LINK].fieldName, line);}
		            		}
		            	}
	            	}else if(s.equals(fields[TOOL_DATA_LINK].id)){
            			fields[TOOL_DATA_LINK].occ++;
            			if(fields[TOOL_DATA_LINK].occ>1){
            				error(err_duplicateField, fields[TOOL_DATA_LINK].fieldName, line);
            			}
            			for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
            			if(s2.hasNext()){
            				String field1 = s2.next();
    						model.tool_data_link = field1;
            				String field2 = null;
            				if(s2.hasNext()){field2 = s2.next(); model.tool_data_link_url = field2;}
        					if(field1.equals("broken")){
        						if(field2!=null){
        							if(!isUrl(field2)){
    			            			err_helper=field2;
    	            					error(err_notUrl, "TOOL:ARTICLE_LINK", line);
    	            				}
        						}else{error(err_missingTag, "TOOL:ARTICLE_LINK", line);}
        					}else if(field1.equals("unknown") || field1.equals("none")){
    	            			if(field2!=null){error(err_extraText, fields[TOOL_DATA_LINK].fieldName, line);}
        					}else if(isUrl(field1)){
        						model.tool_data_link_url = field1;
    	            			if(field2!=null){error(err_extraText, fields[TOOL_DATA_LINK].fieldName, line);}
		            		}else{
		            			err_helper=field1;
            					error(err_notUrl, fields[TOOL_DATA_LINK].fieldName, line);
    	            			if(field2!=null){error(err_extraText, fields[TOOL_DATA_LINK].fieldName, line);}
		            		}
		            	}
	            	}else if(s.equals(fields[VERIFY_NAME].id)){
            			fields[VERIFY_NAME].occ++;
            			if(fields[VERIFY_NAME].occ>1){
            				error(err_duplicateField, "VERIFY:ANALYSIS_BY", line);
            			}
            			if(s2.hasNext()){
	            			model.verify_name = s2.next();
		            		if(s2.hasNext())
		            			error(err_extraText, "VERIFY:ANALYSIS_BY", line);}
	            	}else if(s.equals(fields[VERIFY_STATUS].id)){
            			fields[VERIFY_STATUS].occ++;
            			if(fields[VERIFY_STATUS].occ>1){
            				error(err_duplicateField, "VERIFY:STATUS", line);
            			}
            			if(s2.hasNext()){
	            			model.verify_status = s2.next();
            				if(!model.verify_status.equals("unknown") && 
            					!model.verify_status.equals("needed") && 
	            				!model.verify_status.equals("not_needed") &&
	            				!model.verify_status.equals("started") &&
		            			!model.verify_status.equals("finished")){
			            			err_helper="Acceptable tags include 'unknown', 'needed', 'not_needed', 'started', and 'finished'.";
	            					error(err_unrecognizableTag, "VERIFY:STATUS", line);}
		            		if(s2.hasNext())
		            			error(err_extraText, "VERIFY:STATUS", line);}
	            	}else if(s.equals(fields[VERIFY_COMMENT].id)){
            			fields[VERIFY_COMMENT].occ++;
            			if(fields[VERIFY_COMMENT].occ>1){
            				error(err_duplicateField, "VERIFY:COMMENT", line);
            			}
            			while(s2.hasNext()){
	            			String a = s2.next();
	            			model.verify_comment = model.verify_comment.concat(a+" ");
	            		}
	            	}else if(s.equals(fields[TOOL_DATA_LINK].id)){
            			fields[TOOL_DATA_LINK].occ++;
            			if(fields[TOOL_DATA_LINK].occ>1){
            				error(err_duplicateField, fields[TOOL_DATA_LINK].fieldName, line);
            			}
            			for(int i = 0;i<2;i++){
	            			if (s2.hasNext()){
	            				s2.next();}
	            			else{error(err_unrecognizableField ,"line "+line_counter, line);break;}
	            		}
            			if(s2.hasNext()){
            				String field1 = s2.next();
            				String field2 = null;
            				if(s2.hasNext()){field2 = s2.next(); model.tool_data_link_url = field2;}
        					if(field1.equals("broken")){
        						if(field2!=null){
        							model.tool_data_link_url = field2;
        							if(!isUrl(field2)){
    			            			err_helper=field2;
    	            					error(err_notUrl, "TOOL:ARTICLE_LINK", line);
    	            				}
        						}else{error(err_missingTag, "TOOL:ARTICLE_LINK", line);}
        					}else if(field1.equals("unknown") || field1.equals("none")){
    	            			if(field2!=null){error(err_extraText, fields[TOOL_DATA_LINK].fieldName, line);}
        					}else if(isUrl(field1)){
    	            			if(field2!=null){error(err_extraText, fields[TOOL_DATA_LINK].fieldName, line);}
		            		}else{
		            			err_helper=field1;
            					error(err_notUrl, fields[TOOL_DATA_LINK].fieldName, line);
    	            			if(field2!=null){error(err_extraText, fields[TOOL_DATA_LINK].fieldName, line);}
		            		}
		            	}
            		//The following four strings are optional, there presence or absence will not generate an error.
            		}else if(s.equals("AUTHOR:EMAIL_ORIG[string]")){
	            	}else if(s.equals("AUTHOR:EMAIL_PARSED[list")){		            		
	        		}else if(s.equals("PI:COMMENT_CC[string]")){
            			while(s2.hasNext()){
	            			String a = s2.next();
	            			model.comment_CC=model.comment_CC.concat(a+" ");
	            		}
        			}else if(s.equals("PI:COMMENT_TP[string]")){
            			while(s2.hasNext()){
	            			String a = s2.next();
	            			model.comment_TP=model.comment_TP.concat(a+" ");
	            		}
    				}else if(s.equals(fields[EMAIL_CODE].id)){
            			fields[EMAIL_CODE].occ++;
            			if(fields[EMAIL_CODE].occ>1){
            				error(err_duplicateField, fields[EMAIL_CODE].fieldName, line);
            			}
	            		if(s2.hasNext()){
	            			model.email_code = s2.next();
		            		if(!model.email_code.equals("yes") 
			            		&& !model.email_code.equals("no") ){
			            		err_helper="Acceptable tags include 'yes' and 'no'";
			            		error(err_unrecognizableTag, fields[EMAIL_CODE].fieldName, line);}
		            		else if(s2.hasNext())
	            				error(err_extraText, fields[EMAIL_CODE].fieldName, line);}
	            	}else if(s.equals(fields[EMAIL_REMARK].id)){
            			fields[EMAIL_REMARK].occ++;
            			if(fields[EMAIL_REMARK].occ>1){
            				error(err_duplicateField, fields[EMAIL_REMARK].fieldName, line);
            			}
	            		if(s2.hasNext()){
	            			model.email_remark = s2.next();
	            			if(s2.hasNext())
	            				error(err_extraText, fields[EMAIL_REMARK].fieldName, line);}
	            	}else{
    					//If the field does not match any mandatory or optional fields, report unrecognizableField error.
	            		error(err_unrecognizableField ,"line "+line_counter+" "+s, line);
	            	}
            		while(s2.hasNext()){s2.next();}
	           	}
		    }
        	reader.close();
	        for(int i=0;i<TOTAL_FIELDS;i++){
	        	//if a mandatory's field's occurrence is less than once, report missingField error.
	        	if(fields[i].occ<1){
	        		error(err_missingField, fields[i].fieldName, null);
	        	}
	        }
	        try{
		        inFile = new File(inFile.getParent().concat(System.getProperty("file.separator")+"paper.bib"));
				reader = new BufferedReader(new FileReader(inFile));
		        if((line=reader.readLine()) != null){
		        	String urlBegin = "http://dblp.uni-trier.de/rec/bibtex/conf";
		        	String preLabel = line.split("/")[line.split("/").length-1];
		        	String preConf = line.split("/")[line.split("/").length-2];
		        	if(model.bibtex_label.trim().isEmpty()){
		        		//Construct automatic Bibtex label and links.
			        	model.bibtex_label = preLabel.substring(0, preLabel.length()-1);
		        	}
		        	if(model.bibtex_link.trim().isEmpty()){
			        	model.bibtex_link = urlBegin+"/"+preConf+"/"+model.bibtex_label;
		        	}
		        	reader.close();
		        }
	        }catch (Exception e) {
	        	error_log = error_log.concat("WARNING: paper.bib seek failed.\n");
	        }
        }catch (Exception e) {
			System.out.println("Cannot read file: no such address exists.");
			System.exit(1);
			//e.printStackTrace();
			return false;
		}
        if(!quiet){
        	System.out.print(error_log);
        }
        return true;
	}
	
	private void error_log_add_original(String line){
		if(!quiet){
			error_log = error_log.concat("  Original: " + line + "\n");
		}
	}
	
	//Given error number and line, utilizes subword and occasionally err_helper to print the correct error messages.
	public void error(int err, String subword, String line){
		String errcode = String.format("%03d", err);
		switch(err){
			case err_timeNotValid:
				error_log = error_log.concat("WARNING "+ errcode+ " at "+subword+"- Time value not valid.\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				error_log_add_original(line);
				break;
			case err_extraText:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+"- Extraneous tag.\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				error_log_add_original(line);
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				break;
			case err_unrecognizableTag:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+"- Unrecognizable tag. "+err_helper+"\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				error_log_add_original(line);
				break;
			case err_missingTag:
				error_log = error_log.concat("WARNING "+ errcode+ " at "+subword+"- Missing tag for started analysis."+"\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				error_log_add_original(line);
				break;
			case err_notEmail:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+"- Invalid email address: "+err_helper+"\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				error_log_add_original(line);
				break;
			case err_unrecognizableField:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+"- Cannot recognize line."+"\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				error_log_add_original(line);
				break;
			case err_duplicateField:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+"- Duplicate field.");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				//error_log_add_original(line);
				break;
			case err_missingField:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+": Missing field." + "\n");
				//error_log = error_log.concat(String.format(" Error code: %03d\n", err)); 
				break;
			case err_notUrl:
				error_log = error_log.concat("ERROR "+ errcode+ " at "+subword+"- Invalid url: "+err_helper+"\n");
				//error_log = error_log.concat(String.format(" Error code: %03d", err)); 
				//error_log = error_log.concat("\n  Original: " + line + "\n");
				error_log_add_original(line);
				break;
		}
	}
	
	public boolean save(String dir, Model m){
        File inFile  = new File(dir);
        int i=1;
        File backup = new File(dir+i);
        
        while(backup.exists()){
        	i++;
        	backup = new File(dir+i);
        }
        
        BufferedReader reader;
        BufferedWriter writer;
		try {
			//Write to backup file
			backup.createNewFile();
			reader = new BufferedReader(new FileReader(inFile));
	        writer = new BufferedWriter(new FileWriter(backup));
	        String line = null;
	        while ((line=reader.readLine()) != null) {
	            writer.write(line);
	            writer.newLine();   // Write system dependent end of line.
	        }

	        reader.close();
	        inFile.delete();
	        inFile  = new File(dir);
	        writer.close();
	        writer = new BufferedWriter(new FileWriter(inFile));
	        writer.write(m.reconstructString());
	        writer.close();  // Close to unlock and flush to disk.
	        
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Cannot save to file: no such address exist.");
			return false;
		}
		return true;
	}

	class fieldCount{
		public int occ;
		public String id;
		public String fieldName;
		public fieldCount(String f, String n){
			id = f;
			occ = 0;
			fieldName = n;
		}
	}

}

import java.util.ArrayList;


public interface EmailManager {

	
	public boolean ShouldRecieve(Model m);
	
	public String makeMessage(Model m);
	
	public String getIdentifier();
}

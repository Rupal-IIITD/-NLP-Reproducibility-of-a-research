import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class nameRegexTester {

	private ArrayList<String> names = new ArrayList<String>();
	private Pattern pattern;						//Regex pattern matcher for email-checking
	private Matcher matcher;
	private final String EMAIL_PATTERN =  "[A-Za-z]+_[A-Za-z.]+(_[A-Za-z]+)?";
	
	public static void main(String[] args){
		new nameRegexTester();
	}
	
	public nameRegexTester(){
		addName("A_A");
		addName("Aa_Az");
		addName("AA");
		addName("_AA");
		addName("AA_");
		addName("A_A._Az");
		addName("A_A_Az");
		addName("A_A_");
		addName("_A_A");
		for(String s: names){
			System.out.println(s);
		}
	}
	
	private boolean addName(String e){
		pattern = Pattern.compile(EMAIL_PATTERN);
		matcher = pattern.matcher(e);
		if(!matcher.matches()){
			return false;
		}else{names.add(e);return true;}
	}
	
}

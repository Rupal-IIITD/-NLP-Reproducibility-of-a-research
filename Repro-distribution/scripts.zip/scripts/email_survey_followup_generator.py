#! /usr/bin/python
"""
email_servey_generator
A script to generate survey emails for every paper that wasn't excluded by having a duplicated author.
"""

import argparse
import hashlib
import textwrap
from collections import Counter
from repro_loader import *
from string import Template
from os import path
from pprint import pprint
from bibtexparser.bparser import BibTexParser

def getBibtex(file_path):
    with open(file_path) as bibtex_file:
        parser = BibTexParser(bibtex_file)
    d = parser.get_entry_dict()
    for val in d.values():
        if 'author' in val:
            return val
    print "BIBTEX failure"

#These counts can be used to test that the numbers add up and
#match the graphs that we have.
NUM_SOURCE = {'article':0, 'google':0, 'email':0, 'none':0}
def sourceOfCode(rcd):
    global NUM_SOURCE
    if rcd.TOOL.ARTICLE_LINK.url and not rcd.TOOL.ARTICLE_LINK.broken:
        NUM_SOURCE['article'] += 1
        return ("article_link", rcd.TOOL.ARTICLE_LINK.url)
    if rcd.TOOL.GOOGLE_LINK.url and not rcd.TOOL.GOOGLE_LINK.broken:
        NUM_SOURCE['google'] += 1
        return ("google_link", rcd.TOOL.GOOGLE_LINK.url)
    if rcd.EMAIL1.CODE_AVAILABLE.yes:
        NUM_SOURCE['email'] += 1
        if rcd.TOOL.EMAIL_LINK.url and not rcd.TOOL.EMAIL_LINK.broken:
            return ("email", rcd.TOOL.EMAIL_LINK.url)
        else:
            return ("email", "")
    else:
        NUM_SOURCE['none'] += 1
        return ("none", "")

#Templates use $ to indicate a variable
# $$ is converted to $
SCRIPT_TEMPLATE = Template(
"""########################################################
#Script_in $script_dir
sent=false

if [[ "$$sent" != "false" ]]; then
  echo "Email not sent because \\"already sent\\" parameter is not set to false"
  exit 1
fi

MESSAGE="$$(cat <<\ENDHEREDOC
$message
ENDHEREDOC
)"

MESSAGE="`echo "$$MESSAGE" | sed s/QUOTE/\\\'/g`"

EMAILS=( $email_address_array )

for ((i=0;i<$${#EMAILS[@]};++i)); do
    echo "Sending $script_dir to $${EMAILS[i]}"
    echo "$$MESSAGE" | \\
    $$1 -V -tls -smtp-auth login -smtp-server smtp.gmail.com \\
    -smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \\
    $$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name "Christian Collberg" \\
    -subject "$subject" \\
    "$${EMAILS[i]}"
    echo "EXIT_CODE $$?"
    sleep $$EMAIL_SLEEP_TIME
done
""")

EMAIL_TEMPLATE = Template(
"""Dear author,

Thank you for filling out our repeatability survey!

The complete data we collected for your paper can be found here:
   http://reproducibility.cs.arizona.edu/v2/index.html#$bibtex
The following document explains the data schema:
   http://reproducibility.cs.arizona.edu/v2/format.html
The new version of the technical report is available here:
   http://reproducibility.cs.arizona.edu/v2/tr14-04.pdf

Please let us know if you have any questions or concerns.

We very much appreciate your help,
Christian Collberg
Todd Proebsting""")


def createEmailMessage(database, rcd):
    d = {}
    bib = rcd.bib
    wrp = textwrap.TextWrapper(subsequent_indent="   ", width=70)
    d['title'] = wrp.fill(bib['title'])
    d['bibtex'] = str(rcd.BIBTEX.LABEL)
    d['venue'] = rcd.bib['conf_title']
    return EMAIL_TEMPLATE.substitute(d).encode('ascii', 'ignore')

CONF_TITLES = {
    "asplos12":"ASPLOS'12",
    "ccs12":"CCS'12",
    "oopsla12":"OOPSLA'12",
    "osdi12":"OSDI'12",
    "pldi12":"PLDI'12",
    "sigmod12":"SIGMOD'12",
    "sosp11":"SOSP'11",
    "taco9":"TACO'",
    "tissec15":"TISSEC'12",
    "tocs30":"TOCS'12",
    "tods37":"TODS'12",
    "toplas34":"TOPLAS'12",
    "vldb12":"VLDB'11",
    "vldb12_new":"VLDB'11"}

def checkLink(link):
    """
    Check that a path is present in the website directory
    """
    link_path = path.join(database.repro_root, 'docs', 'website', link)
    return os.path.isfile(link_path)

#Actually I have to check what paper the email was responding to...

def generateScripts(database, responders):
    sender_script = ["#Sender script for survey emails", "export EMAIL_SLEEP_TIME=5"]
    id_map = []
    all_hashes = []
    for rcd in database.records:
        emails = []
        for email in rcd.AUTHOR.EMAIL_REAL.value:
            if [rcd.BIBTEX.LABEL.value, email] in responders:
                print email
                emails.append(email)
        if not emails:
            continue
        if rcd.EMAIL.STATUS.not_needed or \
               (rcd.EMAIL.STATUS.needed and rcd.EMAIL.STATUS.request_1):
            rcd.bib = getBibtex(path.join(rcd.dir, "paper.bib"))
            conf_title = CONF_TITLES[rcd.conf]
            if conf_title == "TACO'":
                conf_title += rcd.bib['year']
            rcd.bib['conf_title'] = conf_title

            email_message = createEmailMessage(database, rcd)
            script = SCRIPT_TEMPLATE.substitute(
                message=email_message.replace("'","QUOTE"),
                subject="Repeatability Study Results: Your %s Paper" % conf_title,
                script_dir=rcd.dir,
                email_address_array=" ".join('"%s"' % email for email in emails))
            script_file_name = path.join(rcd.dir, "es_post_survey_followup.bash")
            sender_script.append("bash {} $1".format(path.join("..", script_file_name)))
            #sender_script.append("sleep 5")
            with open(path.join(database.repro_root, script_file_name), 'wb') as script_file:
                script_file.write(script)
            # print '#' * 10
            # print script
    with open(path.join(database.repro_root, "scripts", "send_email_survey_followup.bash"), 'wb') as survey_file:
        survey_file.write("\n".join(sender_script))

def main():
    global NUM_SOURCE
    parser = argparse.ArgumentParser(description='create email scripts for distributing the survey')
    parser.add_argument("dir", help="Root directory of the reproducibility database.")

    args = parser.parse_args()
    print("\nLoading database from {}".format(args.dir))
    database = repro_database(args.dir, ["all"])
    with open(path.join(args.dir, "logs", "survey_responded.txt"), 'rb') as survey_responded:
        responders = [line.split() for line in survey_responded]

    generateScripts(database, responders)
    # print("\nCode available:")
    # pprint(NUM_SOURCE)
    
    # for rcd in database.records:
    #     if rcd.EMAIL.STATUS.not_needed or \
    #            (rcd.EMAIL.STATUS.needed and rcd.EMAIL.STATUS.request_1):
    #         print ""
    #         print '-' * 10
    #         #print CLASSIFICATION[str(rcd.ARTICLE.IMPLEMENTATION_EXISTS)]
    #         print rcd.path
    #         print sourceOfCode(rcd)[0]
    #         print rcd.dir
    #         print rcd.BIBTEX.LABEL
    #         print rcd.AUTHOR.EMAIL_REAL.value
    #     break

if __name__ == "__main__":
    main()


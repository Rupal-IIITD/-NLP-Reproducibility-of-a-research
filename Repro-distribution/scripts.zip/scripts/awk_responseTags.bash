#!/bin/bash 

#File:		awk_Refactor.bash
#Author:	Akash Shankaran
#Purpose:	Formats the data.txt -
#		1. Adds a tag for IMPLEMENTATION - "hardware"
#		2. adds the fields EMAIL1:CODE_AVAILABLE[yes,no]
#   				   EMAIL1:REMARK[]
#Usage:		sudo bash ./awk_responseTags.bash convert_list 


#run AWK script
if [ "$1" = "convert_list" ]; then
	arg_list="sigmod12 "
#arg_list="tissec15 oopsla12 pldi12 vldb12 osdi12 tods37 toplas34 asplos12 ccs12 sigmod12 taco9 sosp11 tocs30"
else
    arg_list="$@"
fi

for arg in $arg_list
do
	tput setaf 5
	echo "In $arg"
	tput setaf 7
	directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
	
	for D in $directories; do
		tput setaf 4
		echo "Refactoring $D/data.txt"
		tput setaf 7

		#create a new file
		touch $D/data.txt.new

awk -W source '{
if ( $1 ~ /VERIFY:COMMENT*/ )  
{
print $0;
print "EMAIL1:CODE_AVAILABLE[yes,no]";
print "EMAIL1:REMARK[comment]"; 
next;
}
else if ( $1 ~ /ARTICLE:IMPLEMENTATION_EXISTS*/ )
{
split($1, a, "unknown,");
$1=a[1]"unknown,hardware,"a[2];
}

print $0;	
}' $D/data.txt > $D/data.txt.new

#copy temp file into the original data.txt file
cp $D/data.txt.new $D/data.txt
#remove the temp file
rm -f $D/data.txt.new
done
done

#!/bin/csh -f

# usage: get_bibtex.sh sigmod 2012 conf
# usage: get_bibtex.sh toplas 34 journals

set pub = $1
set year = $2
set kind = $3

/bin/rm $pub$year.html.*

wget -O $pub$year.html http://www.informatik.uni-trier.de/~ley/db/$kind/$pub/$pub$year.html
java GetLinks $pub$year.html | grep bibtex | grep -v '.xml' > /tmp/links

set shortyear = `echo $year | sed 's/20//'`

/bin/rm -rf ../$pub$shortyear
mkdir -p ../$pub$shortyear

foreach link ( `cat /tmp/links` )
   set bib = `echo $link | sed "s+http://dblp.uni-trier.de/rec/bibtex/$kind/$pub++"`
   mkdir -p ../$pub$shortyear/$bib
   set paperbib = ../$pub$shortyear/$bib/paper.bib
   wget -O /tmp/bib.out $link

   gawk -f extract_bibtex.awk /tmp/bib.out > $paperbib

   set PAPER_DOI = `gawk '/^  ee        =/ {sub("  ee        = {","");sub("},",""); print $0;exit}' $paperbib`

   set datatxt = ../$pub$shortyear/$bib/data.txt

   echo "PAPER_URL " > $datatxt
   echo "PAPER_DOI " "$PAPER_DOI" >> $datatxt
   echo "COMMERCIAL "  >> $datatxt
   echo "TOOLNAME "  >> $datatxt
   echo "IMPLEMENTED "  >> $datatxt
   echo "TOOL_URL_IN_PAPER "  >> $datatxt
   echo "TOOL_URL_FROM_GOOGLE "  >> $datatxt
   echo "TOOL_URL_FROM_EMAIL "  >> $datatxt
   echo "AUTHOR_EMAIL "  >> $datatxt
   echo "GRANTS "  >> $datatxt
   echo "SUCCESSFUL_DOWNLOAD "  >> $datatxt
   echo "SUCCESSFUL_BUILD "  >> $datatxt
   echo "SUCCESSFUL_RUN "  >> $datatxt
   echo "STATUS_ANALYIS "  >> $datatxt
   echo "STATUS_EMAIL "  >> $datatxt
   echo "COMMENTS "  >> $datatxt
   echo "COMMENT_CC "  >> $datatxt
   echo "COMMENT_TP "  >> $datatxt
   echo "TIME_SPENT "  >> $datatxt
   echo "PERSON "  >> $datatxt
end

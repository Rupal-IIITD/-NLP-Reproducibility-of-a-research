#! /usr/bin/python
"""
parse_survey
Process the surveymoz csv files.
"""

import argparse
import csv
from os import path
from string import Template

from pprint import pprint

from repro_loader import make_blank_survey, repro_database, make_blank_survey_summary


def loadIdMap(root):
    with open(path.join(root, "logs", "survey_id_map.txt"), 'rb') as map_file:
        id_map = {}
        for line in map_file:
            line = line.strip()
            items = line.split(' ')
            path_split = items[2].split('/')
            result = {}
            result['EMAIL'] = items[1]
            result['dir'] = items[2]
            result['BIBTEX_LABEL'] = path_split[2]
            result['conf'] = path_split[1]
            id_map[items[0]] =  result
        return id_map

COLUMN_TITLES = [
    "UserID",
    "UserNo",
    "Name",
    "EMAIL",
    "IP_ADDRESS",
    "UNIQUE_ID",
    "Started",
    "Ended",
    "CLASSIFICATION",
    "CLASSIFICATION_COMMENT",
    "PUBLISHED_CODE",
    "SAME_VERSION",
    "SAME_VERSION_COMMENT",
    "STUDY_FOUND_CORRECT_CODE",
    "CORRECT_CODE_LOCATION",
    "BUILD_DIFFICULTY",
    "BUILD_DIFFICULTY_COMMENT",
    "BUILD_COMMENT",
    "PUBLIC_COMMENT",
    "ANONYMOUS_COMMENT"
]

IGNORE_ITEMS = ["UserID", "UserNo", "Name", "EMAIL", "IP_ADDRESS", "UNIQUE_ID", 
                "Started", "Ended", "dir", "BIBTEX_LABEL", "conf"]

BUILD_DIFFICULTY_PROBLEMS = "I believe the code you downloaded may have had problems that would prevent it from being easily built"
BUILD_DIFFICULTY_REASONABLE = "I believe the code you downloaded can be built with reasonable effort"

def translateResponses(raw_survey):
    for key, value in raw_survey.items():
        if key in IGNORE_ITEMS:
            continue
        if not ("COMMENT" in key or key == "BUILD_DIFFICULTY" 
                or key == "CORRECT_CODE_LOCATION"):
            raw_survey[key] = value.lower()
        else:
            raw_survey[key] = value.replace("\n", " ")
        if value == "-":
            raw_survey[key] = ""


    if not raw_survey['CLASSIFICATION'] == "practical":
        raw_survey['PUBLISHED_CODE'] = "not_applicable"
        raw_survey['SAME_VERSION'] = "not_applicable"
        raw_survey['SAME_VERSION_COMMENT'] = "none"
        raw_survey['STUDY_FOUND_CORRECT_CODE'] = "not_applicable"
        raw_survey['CORRECT_CODE_LOCATION'] = ""
        raw_survey['BUILD_DIFFICULTY'] = "not_applicable"
        raw_survey['BUILD_DIFFICULTY_COMMENT'] = "none"

    if raw_survey['PUBLISHED_CODE'] == "no":
        raw_survey['SAME_VERSION'] = "not_applicable"
        raw_survey['SAME_VERSION_COMMENT'] = "none"
        raw_survey['STUDY_FOUND_CORRECT_CODE'] = "not_applicable"
        raw_survey['CORRECT_CODE_LOCATION'] = ""
        raw_survey['BUILD_DIFFICULTY'] = "not_applicable"
        raw_survey['BUILD_DIFFICULTY_COMMENT'] = "none"

    if "is possible" in raw_survey['SAME_VERSION']:
        raw_survey['SAME_VERSION'] = "no_but_available"
    elif "is not possible" in raw_survey['SAME_VERSION']:
        raw_survey['SAME_VERSION'] = "no_and_not_available"

    if raw_survey['STUDY_FOUND_CORRECT_CODE'] == 'no':
        raw_survey['BUILD_DIFFICULTY'] = "not_applicable"
        raw_survey['BUILD_DIFFICULTY_COMMENT'] = "none"
    else:
        raw_survey['CORRECT_CODE_LOCATION'] = ""

    if raw_survey['BUILD_DIFFICULTY'] == BUILD_DIFFICULTY_REASONABLE:
        raw_survey['BUILD_DIFFICULTY'] = "reasonable_effort"
    elif raw_survey['BUILD_DIFFICULTY'] == BUILD_DIFFICULTY_PROBLEMS:
        raw_survey['BUILD_DIFFICULTY'] = "code_problematic"



def parseCsv(filename, id_map):
    ips = []
    all_results = {}
    begining = True
    with open(filename, 'rb') as csvfile:
        reader = csv.reader(csvfile,  delimiter=',', quotechar='"')
        for row in reader:
            result = {}
            for entry, column in zip(row, COLUMN_TITLES):
                entry = entry.replace("&nbsp", ' ').replace("&lt;", '<').replace("&gt;", '>').replace("&quot;",'"')
                result[column] = entry
            if result['UserNo'] == "32":
                begining = False
            if begining:
                continue
            ip = result['IP_ADDRESS']
            if ip in ips:
                "Repeat IP"
            ips.append(ip)
            result.update(id_map[result['UNIQUE_ID']])

            #Remove unused fields
            # result.pop("Name",  None)
            # result.pop("Ended", None)
            # result.pop("UserID", None)
            # result.pop("UserNo", None)
            # result.pop("UNIQUE_ID", None)
            # result.pop("IP_ADDRESS", None)
            # result.pop("Started", None)


            bib = result['BIBTEX_LABEL']
            translateResponses(result)
            if bib in all_results:
                all_results[bib].append(result)
            else:
                all_results[bib] = [result, ]
            #print '\n' * 2
            #pprint(result)
            print(result['BIBTEX_LABEL'] + " " + result["EMAIL"])
            #print len(row)
            # print result['BIBTEX_LABEL']
    return all_results

TRANSLATE_IMPLEMENTATION = {
    "yes":"practical",
    "no":"theoretical",
    "hardware":"hardware"
}

def createSummary(rcd):
    rcd.survey_summary = make_blank_survey_summary()
    conflicted = []
    for key in rcd.survey_summary.keys():
        val = str(rcd.surveys[0][key])
        rcd.survey_summary[key].load(val)
        for survey in rcd.surveys[1:]:
            if not str(survey[key]) == val:
                conflicted.append(key)
                break
    return conflicted


def writeSurveys(surveys_by_paper, database):
    for paper in surveys_by_paper.values():
        venue = paper[0]['conf']
        if venue == "vldb12_new":
            venue = "vldb12"
        # print("-"*80)
        # print(paper[0]['dir'])
        # print("")
        rcd = database.conferences[venue][paper[0]['BIBTEX_LABEL']]
        for raw_survey in paper:
            print rcd.dir
            survey = make_blank_survey()
            for field in survey.keys():
                survey[field].load(raw_survey[field])
            rcd.surveys.append(survey)
        conflicts = createSummary(rcd)


        # filename = path.join(database.repro_root, rcd.dir, "survey.txt")
        # if conflicts:
        #     print "{:<50} {}".format(filename, " ".join(conflicts))
        # with open(filename, 'wb') as f:
        #     f.write(database.printSurvey(rcd))

        # expected = TRANSLATE_IMPLEMENTATION[str(rcd.ARTICLE.IMPLEMENTATION_EXISTS)]
        # for survey in rcd.surveys:
        #     if not str(survey.CLASSIFICATION) == expected:
        #         print "{:<34} Survey: {:<15} Us: {}".format(rcd.dir, str(survey.CLASSIFICATION), expected)


CSV_COLUMNS= ["dir",
              "#",
              "CLASSIFICATION",
              "OUR_CLASSIFICATION",
              "CLASSIFICATION_COMMENT",
              "OUR_CODE_LOCATION",
              "PUBLISHED_CODE",
              "SAME_VERSION",
              "SAME_VERSION_COMMENT",
              "STUDY_FOUND_CORRECT_CODE",
              "CORRECT_CODE_LOCATION",
              "OUR_BUILD",
              "BUILD_DIFFICULTY",
              "BUILD_DIFFICULTY_COMMENT",
              "BUILD_COMMENT",
              "PUBLIC_COMMENT",
              "ANONYMOUS_COMMENT"]

def buildStatus(rcd):
    result = []
    if not rcd.BUILD.STATUS.finished:
        result.append("N/A")
    else:
        if rcd.BUILD.VERIFY_STATUS.finished:
            result.append("extra-time")
        if rcd.BUILD.STATUS.online:
            result.append("online")
        elif rcd.BUILD.STATUS.compiles:
            result.append("compiles")
        else:
            result.append("doesn't compile")
        if rcd.BUILD.STATUS.runs:
            result.append("runs")
        else:
            result.append("doesn't run")
    return " ".join(result)

def codeSource(rcd):
    result = []
    if rcd.ARTICLE.IMPLEMENTATION_EXISTS.yes:
        #row[4] Article or web code
        if rcd.TOOL.ARTICLE_LINK.url and not rcd.TOOL.ARTICLE_LINK.broken:
            result.append("Article Link")
            result.append(rcd.TOOL.ARTICLE_LINK.url)
        elif rcd.TOOL.GOOGLE_LINK.url and not rcd.TOOL.GOOGLE_LINK.broken:
            result.append("Google Link")
            result.append(rcd.TOOL.GOOGLE_LINK.url)
        if rcd.EMAIL.STATUS.request_1:
            result.append("Email Sent")
            if rcd.EMAIL1.CODE_AVAILABLE.yes:
                result.append("Positive Response")
            elif rcd.EMAIL1.CODE_AVAILABLE.no:
                result.append("Negative Response")
                if str(rcd.EMAIL1.REMARK):
                    result.append("Remark:")
                    result.append(str(rcd.EMAIL1.REMARK))
            elif rcd.EMAIL1.CODE_AVAILABLE.no_response:
                result.append("No Reply")
    else:
        result.append("N/A")
    return " ".join(result)

def rewriteCSV(papers, filename, database):
    responses = []
    for paper in papers.values():
        responses.extend(paper)
    responses = sorted(responses, key=lambda d: d['dir'])
    print len(papers.values())
    print(len(responses))
    with open(filename, 'wb') as f:
        writer = csv.writer(f, delimiter=',', quotechar='"')
        writer.writerow([title.replace('_',' ') for title in CSV_COLUMNS])
        num = 0
        for response in responses:
            venue = response['conf']
            if venue == "vldb12_new":
                venue = "vldb12"
            rcd = database.conferences[venue][response['BIBTEX_LABEL']]
            response['OUR_CLASSIFICATION'] = TRANSLATE_IMPLEMENTATION[str(rcd.ARTICLE.IMPLEMENTATION_EXISTS)]
            response['OUR_BUILD'] = buildStatus(rcd)
            response['OUR_CODE_LOCATION'] = codeSource(rcd)
            response['#'] = str(num)
            num += 1
            writer.writerow([response[x].replace('_', ' ') for x in CSV_COLUMNS])
            pprint( [response[x].replace('_', ' ') for x in CSV_COLUMNS])

def writeMarkdown(papers, filename):
    result = ["#Survey Results"]
    for bibtex, paper in papers.values():
        result.append("##{}".format(paper))

def main():
    parser = argparse.ArgumentParser(description='create email scripts for distributing the survey')
    parser.add_argument("dir", help="Root directory of the reproducibility database.")
    parser.add_argument("csv", help="Location of the file to parse.")


    args = parser.parse_args()

    print("Opening %s" % args.csv)
    id_map = loadIdMap(args.dir)
    results = parseCsv(args.csv, id_map)


    #database = repro_database(args.dir, ["all"])

    #rewriteCSV(results, path.join(args.dir, "survey", "plain.csv"), database)
    
    #writeSurveys(results, database)


if __name__ == "__main__":
    main()
#Author: Zuoming
#Purpose: set up all the webpages under the webpage folder in root.

#Generate plain txt file containing data to be used for graphs. -c creates 
#the data files, -q facilitates quick generation.
#bash make_status.bash -c -q all
python repro_status.py .. all -c
#re-generate all png graph files, using the data files.
cd ../webpage/data
bash gengraphs.bash

#re-generate all webpages in the webpage directory (except main.html)
cd ..
bash genpages.bash
#!/bin/bash
# File: Reverify.bash
# Author: Zuoming Shi 
# Purpose: Takes a folder of conferences and move the verify fields
# above to the article analysis fields.
# Usage: bash Reverify.bash [name of the conference]
# Example: bash Reverify.bash ccs12

# Note: as expected, this script will not work when a 
# conference folder does not contain links in it.
# The script assumes directory to be "scripts" and will not
# work when moved to other directories.

a=$(find ./../$1 -name 'data.txt' -print0 | xargs -n 1 -0r java -jar Reverifier)
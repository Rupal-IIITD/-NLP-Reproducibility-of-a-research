#!/bin/bash
# File: urlextractor.bash
# Author: Zuoming Shi 
# Purpose: Takes a folder and extracts all occurances of 
# links from the domain http://doi.acm.org/ in it and its        
# subdirectories and saves it to the paper_urls folder.
# Usage: bash urlextractor.bash [name of the conference]
# Example: bash urlextractor.bash ccs12

# Note: as expected, this script will not work when a 
# conference folder does not contain links in it.
# The script assumes directory to be "scripts" and will not
# work when moved to other directories.

STRING='http://doi.acm.org/'
a=$(find ./../$1 -name 'data.txt' -print0 | xargs -0r grep -H $STRING)
$(echo "$a">paper_urls/$1urls.txt)
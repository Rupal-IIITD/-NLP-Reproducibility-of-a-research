#!/bin/bash
# File: urlextractor.bash
# Author: Zuoming Shi 
# Purpose: Takes a extracts all occurances of data.txt in 
# folders designated to this scrip that has no article and 
# google link and have its analysis verified. Prints 5 random
# sample of those read.txt, the samples are not garunteed to 
# be unique.

# Note: only the most elementary functionalities are complete.
# in wait of updates.

#List of conferences that are already worked on, vldb does not currently work for some reason...
arg_list="oopsla12 osdi12 pldi12 sosp11 tissec15 tocs30 vldb12"
STRING='VERIFY:STATUS\[unknown,needed,not_needed,started,finished\] finished'
STRING2='TOOL:ARTICLE_LINK\[unknown,none,url,broken and url\] none'
STRING3='TOOL:GOOGLE_LINK\[unknown,none,url,broken and url\] none'
result=""
for var in $arg_list; do
	a=$(find ./../$var -name 'data.txt' -print0 | xargs -0r grep -l -e "$STRING") #| xargs -0r grep -l -e "$STRING2")
	b=$(grep -l -r -H "$STRING2" $a)
	c=$(grep -l -r -H "$STRING3" $b)
	result=$(echo "$result")$(echo "
$c")
done

echo "$result"
echo ""

echo "$result" | awk 'BEGIN { srand() } int(rand() * NR) == 0 { x = $0 } END { print x }'
#waits a second so that the seed for awk can reset.
sleep 1
echo "$result" | awk 'BEGIN { srand() } int(rand() * NR) == 0 { x = $0 } END { print x }'
sleep 1
echo "$result" | awk 'BEGIN { srand() } int(rand() * NR) == 0 { x = $0 } END { print x }'
sleep 1
echo "$result" | awk 'BEGIN { srand() } int(rand() * NR) == 0 { x = $0 } END { print x }'
sleep 1
echo "$result" | awk 'BEGIN { srand() } int(rand() * NR) == 0 { x = $0 } END { print x }'
sleep 1

exit
Scripts

addsrcfolder.bash                   - Used to add a folder for source code to repository
awk_addBuildError.bash              - Adds field for build error
awk_modify_email1Tag.bash           - adds no_response tag to email1 field
awk_Refactor.bash                   - various refactoring changes, adds tag for NSF
awk_responseTags.bash               - adds fields for email and tag for hardware
build_webpages.bash                 - used to generate webpage of pie charts
cp_new_data.bash                    - used to replace old blank data.txt with newer version
debug.bash                          - runs original error checker on datavase, deprecated
export_for_web.py                   - Sanitizes data and copies it for ziping and distribution
extract_bibtex.awk                  - used to get bibtex
extract_email.awk                   - attempts to extract email addresses from plain text of paper
get_bibtex.sh                       - original script to generate data.txt
GetLinks.java                       - extract links for html page
insert_space_after_field.bash       - used to put spaces after ] in data.txt
make_status.bash                    - original script for tracking results, deprecated
parseBibtex                         - parses a bibtex, see java project
pdfRename.bash                      - renames all pdfs in directory to paper.pdf
random_script_selector.bash         - Finds a random paper of PI to review
refactor1.bash                      - updates data.txt with new form of link accounting
refactor1_from_spreadsheet.bash     - gets results from spreadsheet into data.txt
refactor_author_names.bash          - uses java executable to get author names from bibtex
repro_loader.py                     - * python script to load data.txt
repro_status.py                     - used with repro_loader.py, various options, analyzes database
Reverifier                          - see java project
reverify.bash                       - see java project
scripts/acm_download.awk            - Used for original download of papers
send_email_batch_2.bash             - Used to send the second batch of emails
send_email_batch_3.bash             - Used to send the third batch of emails
send_email_request_1.bash           - Used to send the first batch of emails
split_spreadsheet.awk               - convert pilot data to data.txt
status_compare.bash                 - interleaved status logs to see change over time
texttable.py                        - third party script to make ascii tables
urlextractor.bash                   - extracts urls from a text file of paper
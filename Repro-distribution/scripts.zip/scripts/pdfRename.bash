#!/bin/bash
# File:pdfRename.bash
# Author: Zuoming Shi
# Purpose: Recursively renames all pdf files within a given directory to be 
# paper.pdf. Uses the mv backup scheme in case multiple pdf exists in the same
# folder. Prints out the total number of pdf files renamed this way.
# Usage: bash pdfRename.bash [name of the conference]
# Example: bash pdfRename.bash ccs12

# WARNING: empty arguement is disabled, however, using " " as an arguement will
# result in all .pdf files in the repro to be renamed "paper.pdf". Use with 
# care!

if [ $# -ge 1 ];then
	PDFS=$(find ./../$1 -name '*'.pdf)
	set -f              # turn off globbing
	IFS='
	'                   # split at newlines only
	counter=0
	for f in $PDFS; 
		do 
		filepath=$(dirname "$f");
		bname=$(basename "$f");
		destination="$filepath/paper.pdf";
		#echo "Changing ${f} to $destination";
		echo "Changing ${bname} to paper.pdf";
		mv -b --backup=t "$f" "$destination";
		if [[ $? == 0 ]];then
			let "counter += 1";
	    fi
	done
	echo "$counter files changed."
else
	echo "Arguement cannot be empty."
fi
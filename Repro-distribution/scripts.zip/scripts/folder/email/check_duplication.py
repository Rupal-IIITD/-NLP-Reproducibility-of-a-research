from os import path

a_path = path.join(".","ignore_list.txt")
b_path = path.join(".","ignore_list.txt")
a_file = open(a_path, 'r')
a_lines = set()
for line in a_file:
	a_lines.add(line.split()[0])
a_file.close()

b_file = open(b_path, 'r')
duplicates = []
num_duplicated = 0
for line in b_file:
	if line.split()[0] in a_lines:
		num_duplicated += 1
		duplicates.append(line)
	else:
		pass
print "Found {} duplicates".format(num_duplicated)
print ''.join(duplicates)
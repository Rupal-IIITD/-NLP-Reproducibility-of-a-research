#!/bin/bash
# File:      email.bash
# Author:    Zuoming Shi
# Purpose:   Sends out an email asking for implementation if the conditions 
# are met. After the email is sent, data.txt's EMAIL:STATUS field will be
# set to "needed request_1" and this script will be renamed email_sent.bash,
# with "sent" set to true and time sent appended to the bottom of the script.
##############################################################################
#HEADER
verified=false #Set this to true to allow sending
sent=false

if [[ "$verified" != "true" ]]; then
  echo "Email not sent because was not verified"
  exit 1
fi
if [[ "$sent" != "false" ]]; then
  echo "Email not sent because \"already sent\" parameter is not set to false"
  exit 1
fi

##############################################################################
#VERIFICATION, make changes here if necessary.
MAIN_EMAIL='[FIRSTAUTHOREMAIL@DOMAIN.EXT]' #Check whether this alligns with the greeting
CC='[AUTHOR2@DOMAIN.EXT,AUTHOR3@DOMAIN.EXT,AUTHOR4@DOMAIN.EXT]'
SUBJECT="Your [CONFNAME] paper"

MESSAGE="Dear Dr. [FIRST-AUTHOR-LAST-NAME],

My name is Christian Collberg and I am on the faculty at the 
University of Arizona. I've been looking at your [CONFNAME] paper
	[CONF_PAPER]
and I'm interested in trying out the implementation mentioned in it. 
However, I haven't been able to find it on your website. Would you 
please let me know how I can obtain the source code so that I can try 
to build and run it?

Thank you very much for your help!

Christian Collberg
ccollberg@gmail.com"
##############################################################################
#WORKING AREA, do not change.
echo "Sending to Dr. [FIRST_AUTHOR_LAST_NAME]"
echo "$MESSAGE" | \
/usr/local/bin/email  -tls -smtp-auth login -smtp-server smtp.gmail.com \
-smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \
$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name "Christian Collberg" \
-subject "$SUBJECT" \
-cc $CC \
$MAIN_EMAIL

if(( "$?" == "0" ));
	then 
		#Modify this script to update the "sent" parameters on top and the sent date.
		DIR=$( cd "$( dirname "$0" )" && pwd )
		DATE=`date +%s`
		DATE_READABLE=`date +%F`
		#Create email sent.bash
		cp ${DIR}/email.bash ${DIR}/email_sent.bash
		sed -i.bak -e "s/\(^sent=\).*/\1true/" \
		-e "s/\(^TIME_SENT=\).*/\1${DATE}/" \
		-e "s/\(^TIME_SENT_READABLE=\).*/\1${DATE_READABLE}/" ${DIR}/email_sent.bash
		rm ${DIR}/email.bash

		#Change EMAIL:STATUS to request_1
		sed -i.bak 's/\(^EMAIL:STATUS.*\] \).*/\1needed request_1/' ${DIR}/data.txt 

		#Sed on files (change data.txt, add a line of dates to txt)
		#Also, need to test failed email scripts.
		echo "Send complete. Script renamed to email-sent.bash"
		exit 0
	else
		echo "email program gave bad exit code, changes not made."
		exit 1
fi

###############################################################################
#BOOKKEEPING AREA, do not change.
EMAIL_GROUP=[first or second]
EMAIL_NUMBER=[first or second]
CHRISTIAN_KNOWS_THEM=[true or false]
#IN SECONDS SINCE EPOCH
TIME_SENT=
#IN HUMAN READABLE FORM
TIME_SENT_READABLE=
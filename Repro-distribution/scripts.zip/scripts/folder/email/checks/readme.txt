About Checks


deleted_person_email_sent_to.txt - there is a paper where an email was sent and later we removed it from the original_papers_sent_to.txt      - created from the script that ran the individual email scripts
recorded_papers_sent_to.txt      - list of papers that have the tag request_1
../batch1_recipient_list.txt     - list of emails from all those papers that have request_1 set and the deleted from above

to_get_email_batch_2.txt         - list of emails that are to get an email in the new batch - this is now outdated
instead see:
../batch2_paper_list.txt



I don't like how this works, but if you scan it, should work

grep New_Email:.* email_generator_console.txt > ../scripts/email/checks/to_get_email_batch_2.txt
cat checks/to_get_email_batch_2.txt batch1_recipient_list.txt | sort filename | uniq -c | sort -nr

I also made a python script ../check_duplication.py but one needs to hard code the file paths
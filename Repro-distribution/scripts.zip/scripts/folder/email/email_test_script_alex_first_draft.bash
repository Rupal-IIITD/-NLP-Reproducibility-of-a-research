#!/bin/bash
# File:      .bash
# Author:    Make Emailer Script
# Purpose:   sends an email

#Set this to true to allow sending
verified="false"
sent="false"

if [[ "$verified" != "true" ]]; then
  echo "Email not sent because was not verified"
  exit 0
fi
if [[ "$sent" == "true" ]]; then
  echo "Email not sent because already sent"
  exit 0
fi


echo "Executing script for TK"

# Uses the email program from
# http://www.cleancode.org/projects/email
/usr/local/bin/email  -tls -smtp-auth login -smtp-server
smtp.gmail.com -smtp-port 587 -c ~/bin/email.conf -smtp-user collberg
-smtp-pass $EMAILPASSWORD -from-addr collberg@gmail.com -from-name
"Christian Collberg" -subject "3rd ACM/DAPA International Summer
School on Information Security and Protection" collberg@cs.arizona.edu
<<END
MESSAGE for the email


signed
END

# File:      email.bash
# Author:    Zuoming Shi
# Purpose:   Sends out an email asking for implementation if the conditions 
# are met (verified and sent are both set to true).
verified=true #Set this to true to allow sending
sent=false

if [[ "$verified" != "true" ]]; then
  echo "Email not sent because was not verified"
  exit 1
fi
if [[ "$sent" != "false" ]]; then
  echo "Email not sent because \"already sent\" parameter is not set to false"
  exit 1
fi

#Only make changes between the END_HEREDOC 
MESSAGE=$(cat <<'END_HEREDOC'
Dear Dr. Shi,

My name is Christian Collberg and I am on the faculty at the 
University of Arizona. I've been looking at your [CONFNAME] paper
	[CONF_PAPER]
and I'm interested in trying out the implementation mentioned in it. 
However, I haven't been able to find it on your website. Would you 
please let me know how I can obtain the source code so that I can try 
to build and run it?

Thank you very much for your help!

Christian Collberg
ccollberg@gmail.com
END_HEREDOC
)

echo "$MESSAGE" | \
$1 -tls -smtp-auth login -smtp-server smtp.gmail.com \
-smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \
$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name "Christian Collberg" \
-subject 'Your [CONFNAME] paper' -cc 'zuomingshi@gmail.com,zuomingshi2@gmail.com' \
'accountistaken@gmail.com'
exit $?
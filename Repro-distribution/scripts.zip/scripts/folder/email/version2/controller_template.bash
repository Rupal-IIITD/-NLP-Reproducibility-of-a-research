#!/bin/bash
#usage:bin=/usr/local/bin/email
Script_Path=$1
DIR=$( cd "$( dirname "$0" )" && pwd )
Script_Dir=$(dirname ${DIR}/${Script_Path}.bash)
OUT=${Script_Dir}/email.out
echo "---START ${Script_Path}---" >> $OUT
bin=$2
bash -v ${Script_Path}.bash $bin >> $OUT 2>&1 #Concactentae both stdour and stderr

if(( "$?" == "0" ));
	then 
		#Append timestamp and messages
		echo "Send successful."  >> $OUT
		echo "time `date +%s`" >> $OUT
		echo "time_Readable `date +%F`" >> $OUT
		echo "---END ${Script_Path}---" >> $OUT

		#Change data.txt
		sed -i 's/\(^EMAIL:STATUS.*\] \).*/\1needed request_1/' ${Script_Dir}/data.txt 

		#Change send variable and rename as request1_unknown_sent.bash
		sed -i 's/\(^sent=\).*/\1true/' ${DIR}/${Script_Path}.bash
		if(( "$?" != "0" )); then
			echo "ERROR: mail sent but failed to deactivate script at $(pwd)"
			echo "Check ${Script_Path}_sent.bash to make sure sent is set to true."
		fi
		mv ${DIR}/${Script_Path}.bash ${DIR}/${Script_Path}_sent.bash
		echo "Send complete. Script renamed to ${Script_Path}.bash"
		
		#set permissions
		chmod u=w ${DIR}/${Script_Path}_sent.bash
		echo "permission set to write only."
		exit 0
	else
		#set permissions
		chmod u=w ${DIR}/${Script_Path}.bash

		#Append error messages
		echo "permission set to write only."
		echo "email program gave bad exit code."
		echo "please check email.out for additional messages"
		echo "---END ${Script_Path}---" >> $OUT
		exit 1
fi
sleep 5
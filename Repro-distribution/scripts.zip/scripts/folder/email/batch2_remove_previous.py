from os import path

batch1_file_path = path.join(".","christian_check_list_batch1.txt")
batch2_file_path = path.join(".","christian_check_list_batch2.txt")
batch1_file = open(batch1_file_path, 'r')
batch1_emails = set()
for line in batch1_file:
	batch1_emails.add(line.split()[0])
batch1_file.close()

batch2_file = open(batch2_file_path, 'r')
batch2_final = []
num_duplicated = 0
for line in batch2_file:
	if line.split()[0] in batch1_emails:
		num_duplicated += 1
	else:
		batch2_final.append(line)
print "Removed {} duplicates".format(num_duplicated)
batch2_file.close()
batch2_file = open(batch2_file_path, 'w')
batch2_file.write(''.join(batch2_final))
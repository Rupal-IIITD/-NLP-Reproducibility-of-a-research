verified=false
sent=false

if [[ "$verified" != "true" ]]; then
  echo "Email not sent because was not verified"
  exit 1
fi
if [[ "$sent" != "false" ]]; then
  echo "Email not sent because \"already sent\" parameter is not set to false"
  exit 1
fi

MESSAGE=$(cat <<'END_HEREDOC'
Hi!

Hope you are doing well! I've was looking at your CONFERENCE paper
    PAPER-TITLE
and I'm interested in trying out the implementation that you mention in it.
I looked around on your website but wasn't able to find it. Could you let
me know where I can find the source code so that I can try to build and
run it?

Thanks!

Christian
END_HEREDOC
)

echo "$MESSAGE" | \
$1 -tls -smtp-auth login -smtp-server smtp.gmail.com \
-smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \
$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name "Christian Collberg" \
-subject 'Your [CONFNAME] paper' -cc '[first_recipient_email@email.com]' \
'[cc@email.com,cc2@email.com]'
exit $?
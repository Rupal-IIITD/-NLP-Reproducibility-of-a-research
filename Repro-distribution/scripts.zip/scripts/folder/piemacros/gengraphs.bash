#!/bin/bash
# Author: Zuoming
# Purpose: This script uses the position of resultmacros.tex and 
# generates pie charts for a number of staticstics relevant to the 
# research project into the docs/tr/data directory.

# Assumptions: This script assumes that the user is in the same 
# directory as the  script and the script is placed in a subfolder 
# inside the scripts directory.
# In addition, output are piped into ./../../docs/tr/data/ directory.

# Create temporary directory to store input files for pie-macro.bash
mkdir data

# Command to generate data files to be piped into gnuplot
# filenames=$(bash listNum.bash resultmacros.tex)
filenames=$(bash listNum.bash ./../../docs/tr/data/resultmacros.tex)

# Translates the data files into gnuplot script and pipe to gnuplot.
echo $filenames | xargs -n 1 bash ./pie-macro.bash | gnuplot

# Generates the necessary macros for the data directory.
echo $filenames | xargs -n 1 bash ./pie-macro-gen.bash

# Remove unused data files.
rm -rf ./data
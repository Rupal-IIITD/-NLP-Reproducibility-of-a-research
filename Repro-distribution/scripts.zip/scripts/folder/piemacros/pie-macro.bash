#!/bin/bash

#D is the total
#$NF is the final field in an exploded array
#NF is the number of fields in an exploded array

gawk 	'{
		i++
		if($0!~/#/) {
			if(NF>1 && $NF!=0){
				split($0, a, "\"")
				label[i] = a[2]
				v[i] = $NF
				D+= $NF
			}
			else if(NF==1){
				i--;
				split($0, a, ":")
				if(a[1]="FNAME"){
					fname = "Pie-" a[2]
				}
				#else if(a[1]="FNAME"){
				#	fname = a[2]
				#}
				#print "Conference name saved\n"
			}
			else{
				i--
			}
		}
	}
	END {	
		d = v[1]
		print "set terminal pngcairo size 800,500 "
		#printf "set output \"./pie/%s.png\"\n", fname
		printf "set output \"./../../docs/tr/data/%s.png\"\n", fname
		print "reset"
		printf "set title \"%s\"\n", fname
		print "b=0.20; s=7; B=0.5; B2=0.45; txt=0.4"
		#B=X position, B2=Y position (from bottom)
		print "unset border; unset tics; unset key"
		print "set angles degree; set yrange [0:1]; set style fill solid 1.0 border -1"

		for(j=1;j<=i;j++) {
			v_orig[j] = v[j]
		}

		for(j=1;j<=i;j++) {
			v[j] = v[j]/D
			if(j>1){
				v[j] += v[j - 1]
			}
		}

		for(j=1;j<=i;j++) {
			v[j] = v[j]*360
		}

		tot = 0
		for(j=1;j<=i;j++) {
			d=v[j]
			color = 1
			#"no imp" 0
			#"no/bkn lnk" 0
			#"lnk no run" 0
			#"builds runs" 0
			#"lnk but ukn build" 0

			switch (label[j]) {
			case "no imp":
				color = 9
				break
			case "no code":
				color = 1
				break
			case "has code":
				color = 2
				break	
			case "article code":
				color = 2
				break	
			case "google code":
				color = 3
				break
			case "email code":
				color = 5
				break
			case "not attempted":
				color = 9
				break
			case "downloaded only":
				color = 6
				break
			case "not sent":
				color = 9
				break
			case "no reply":
				color = 1
				break
			case "reply no code":
				color = 6
				break
			case "reply with code":
				color = 2
				break	
			case "no code before email":
				color = 6
				break
			case "no code from email":
				color = 1
				break
			case "does not compile":
				color = 1
				break
			case "does not run":
				color = 6
				break
			case "runs":
				color = 2
				break
			case "runs(online)":
				color = 2
				break
			default:
			  	color = 1
   		  	}

			printf "set obj %d circle arc [%g:%g] fc lt %d \n", j, tot, d, color
			printf "set obj %d circle at screen B,B2 size screen b front \n", j
			tot=d
		}

		print "set font \"arial\""
		#pre=0
		#next=v[1]
		v[0] = 0
		for(j=0;j<i;j++) {
			d = ( v[j] + v[j+1] )/2
			p = (v[j+1] - v[j]) / 3.6
			printf "set label at screen %d \" %s:%02.01f%s/%s \" at s * cos(%f) - 2.49, B2+0.05+0.53*sin(%f) font \", 12\"\n", j + 1, label[j + 1], p, "%", v_orig[j+1], d, d, d, d
		}
		print "plot 2"
	}' ./data/$1
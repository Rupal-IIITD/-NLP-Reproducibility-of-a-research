#!/bin/bash
<<REFERENCE
Total
WithImplementation
WithNoImplementation
WithAvailableCode
WithArticleCode
WithGoogleCode
WithEmailCode
BuildAttempted
BuildDownloads
BuildCompiles
BuildRuns
EmailNeeded
EmailSent
EmailGotReply
EmailGotNoReply
EmailGotReplyYes
EmailGotReplyNo

WithImplementationNoCode (Total-WithNoImplementation-WithAvailableCode)
BuildNotAttempted (WithAvailableCode-BuildAttempted)
BuildDownloadsOnly (BuildAttempted-BuildCompiles)
BuildRunsOnly (BuildAttempted-BuildDownloads)
EmailNotSent (EmailNeeded-EmailSent)
NoCodeFromEmail (EmailGotReplyNo+EmailGotNoReply)
REFERENCE

gawk	'
BEGIN{
	#OFS=","
	fields_str="Total,WithImplementation,WithNoImplementation,WithAvailableCode,WithArticleCode,WithGoogleCode,WithEmailCode,BuildAttempted,BuildDownloads,BuildCompiles,BuildRuns,BuildOnlineRuns,EmailNeeded,EmailSent,EmailGotReply,EmailWithoutReply,EmailGotReplyYes,EmailGotReplyNo"
	categories_str="Tissec,Taco,Tods,Osdi,Sigmod,Asplos,Oopsla,Toplas,Pldi,Sosp,Vldb,Tocs,Ccs,CommercialNone,CommercialPart,CommercialFull,Total"
	n=split(fields_str,parameters,",")
	n_c=split(categories_str,categories,",")

	for(j=1;j<=n;j++) {
		parameter_splitter[j]=parameters[j] "}{"
		#print parameter_splitter[j]
	}
}

{
	for(j=1;j<=n;j++) {
		n2=split($0,line_finder,parameter_splitter[j]) 
		if(n2>1){
			split(line_finder[1],conf_container,"\\")
			category=conf_container[3]
			split(line_finder[2],number_container,"\\")
			number=number_container[1]
			#print category " " parameters[j] " " number
			dataset[category, parameters[j]] = number
			#print dataset[category, parameters[j]]
			#for(x, y in used){
			#	print x y
			#}
		}
	}
}
END{
	parameters[j]="WithImplementationNoCode"
	parameters[j+1]="BuildNotAttempted"
	parameters[j+2]="NoCodeFromEmail"
	parameters[j+3]="EmailNotSent"
	n+=4
	for(j=1;j<=n_c;j++) {
		dataset[categories[j], "WithImplementationNoCode"]=dataset[categories[j], "Total"]-dataset[categories[j], "WithNoImplementation"] - dataset[categories[j], "WithAvailableCode"]
		dataset[categories[j], "BuildNotAttempted"]=dataset[categories[j], "WithAvailableCode"] -dataset[categories[j], "BuildAttempted"]
		dataset[categories[j], "NoCodeFromEmail"]=dataset[categories[j], "EmailGotReplyNo"]+dataset[categories[j], "EmailGotNoReply"]
		dataset[categories[j], "EmailNotSent"]=dataset[categories[j], "EmailNeeded"]-dataset[categories[j], "EmailSent"]
		dataset[categories[j], "WithNoAvailableCode"]=dataset[categories[j], "WithImplementation"]-dataset[categories[j], "WithAvailableCode"]
		dataset[categories[j], "BuildDoesNotCompile"]=dataset[categories[j], "BuildAttempted"]-dataset[categories[j], "BuildCompiles"]
		dataset[categories[j], "BuildDoesNotRun"]=dataset[categories[j], "BuildAttempted"]-dataset[categories[j], "BuildRuns"]
		#print categories[j]
		#for(k=1;k<n;k++) {
		#	print parameters[k] " " dataset[categories[j], parameters[k]]
		#}
		#print ""
		#print "line 2" >out_file
		
		FNAME=categories[j] "-Availibility-Full"
		Content="FNAME:"FNAME "\n"\
			"\"no imp\" " dataset[categories[j], "WithNoImplementation"] "\n"\
			"\"article code\" " dataset[categories[j], "WithArticleCode"] "\n"\
			"\"google code\" " dataset[categories[j], "WithGoogleCode"] "\n"\
			"\"email code\" " dataset[categories[j], "WithEmailCode"] "\n"\
			"\"no code\" " dataset[categories[j], "WithImplementationNoCode"]
		print Content > "./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Availibility-ImplementedOnly"
		Content="FNAME:"FNAME "\n"\
			"\"article code\" " dataset[categories[j], "WithArticleCode"] "\n"\
			"\"google code\" " dataset[categories[j], "WithGoogleCode"] "\n"\
			"\"email code\" " dataset[categories[j], "WithEmailCode"] "\n"\
			"\"no code\" " dataset[categories[j], "WithImplementationNoCode"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Availibility-WithCodeOnly"
		Content="FNAME:"FNAME "\n"\
			"\"article code\" " dataset[categories[j], "WithArticleCode"] "\n"\
			"\"google code\" " dataset[categories[j], "WithGoogleCode"] "\n"\
			"\"email code\" " dataset[categories[j], "WithEmailCode"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Emails-Full"
		Content="FNAME:"FNAME "\n"\
			"\"not sent\" " dataset[categories[j], "EmailNotSent"] "\n"\
			"\"no reply\" " dataset[categories[j], "EmailWithoutReply"] "\n"\
			"\"reply no code\" " dataset[categories[j], "EmailGotReplyNo"] "\n"\
			"\"reply with code\" " dataset[categories[j], "EmailGotReplyYes"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Emails-SentOnly"
		Content="FNAME:"FNAME "\n"\
			"\"not sent\" " dataset[categories[j], "EmailNotSent"] "\n"\
			"\"no reply\" " dataset[categories[j], "EmailWithoutReply"] "\n"\
			"\"reply no code\" " dataset[categories[j], "EmailGotReplyNo"] "\n"\
			"\"reply with code\" " dataset[categories[j], "EmailGotReplyYes"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Overview-Full"
		Content="FNAME:"FNAME "\n"\
			"\"no imp\" " dataset[categories[j], "WithNoImplementation"] "\n"\
			"\"not sent\" " dataset[categories[j], "EmailNotSent"] "\n"\
			"\"no reply\" " dataset[categories[j], "EmailWithoutReply"] "\n"\
			"\"reply no code\" " dataset[categories[j], "EmailGotReplyNo"] "\n"\
			"\"has code\" " dataset[categories[j], "WithAvailableCode"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Overview-HasCode"
		Content="FNAME:"FNAME "\n"\
			"\"no imp\" " dataset[categories[j], "WithNoImplementation"] "\n"\
			"\"not sent\" " dataset[categories[j], "EmailNotSent"] "\n"\
			"\"no reply\" " dataset[categories[j], "EmailWithoutReply"] "\n"\
			"\"reply no code\" " dataset[categories[j], "EmailGotReplyNo"] "\n"\
			"\"has code\" " dataset[categories[j], "WithAvailableCode"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Builds-Full"
		Content="FNAME:"FNAME "\n"\
			"\"no imp\" " dataset[categories[j], "WithNoImplementation"] "\n"\
			"\"no code\" " dataset[categories[j], "WithNoAvailableCode"] "\n"\
			"\"not attempted\" " dataset[categories[j], "BuildNotAttempted"] "\n"\
			"\"does not compile\" " dataset[categories[j], "BuildDoesNotCompile"] "\n"\
			"\"does not run\" " dataset[categories[j], "BuildDoesNotRun"] "\n"\
			"\"runs\" " dataset[categories[j], "BuildRuns"] "\n"\
			"\"runs(online)\" " dataset[categories[j], "BuildOnlineRuns"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Builds-ImplementedOnly"
		Content="FNAME:"FNAME "\n"\
			"\"no code\" " dataset[categories[j], "WithNoAvailableCode"] "\n"\
			"\"not attempted\" " dataset[categories[j], "BuildNotAttempted"] "\n"\
			"\"does not compile\" " dataset[categories[j], "BuildDoesNotCompile"] "\n"\
			"\"does not run\" " dataset[categories[j], "BuildDoesNotRun"] "\n"\
			"\"runs\" " dataset[categories[j], "BuildRuns"] "\n"\
			"\"runs(online)\" " dataset[categories[j], "BuildOnlineRuns"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Builds-WithCodeOnly"
		Content="FNAME:"FNAME "\n"\
			"\"not attempted\" " dataset[categories[j], "BuildNotAttempted"] "\n"\
			"\"does not compile\" " dataset[categories[j], "BuildDoesNotCompile"] "\n"\
			"\"does not run\" " dataset[categories[j], "BuildDoesNotRun"] "\n"\
			"\"runs\" " dataset[categories[j], "BuildRuns"] "\n"\
			"\"runs(online)\" " dataset[categories[j], "BuildOnlineRuns"]
		print Content>"./data/" FNAME
		print FNAME

		FNAME=categories[j] "-Builds-AttemptedOnly"
		Content="FNAME:"FNAME "\n"\
			"\"not attempted\" " dataset[categories[j], "BuildNotAttempted"] "\n"\
			"\"does not compile\" " dataset[categories[j], "BuildDoesNotCompile"] "\n"\
			"\"does not run\" " dataset[categories[j], "BuildDoesNotRun"] "\n"\
			"\"runs\" " dataset[categories[j], "BuildRuns"] "\n"\
			"\"runs(online)\" " dataset[categories[j], "BuildOnlineRuns"]
		print Content>"./data/" FNAME
		print FNAME
	}
}
' $1
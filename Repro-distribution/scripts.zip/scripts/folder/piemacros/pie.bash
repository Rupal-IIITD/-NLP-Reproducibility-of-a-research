#!/bin/bash

# Refer to gengraphs.bash for more specfic instructions
# gengraphs.bash echoes the macros for latex picture display, which
# this script will pipe to the docs/tr/data directory.

# Assumptions: This script assumes that the user is in the same 
# directory as the  script and the script is placed in a subfolder 
# inside the scripts directory.
bash ./gengraphs.bash > ./../../docs/tr/data/piemacros.tex
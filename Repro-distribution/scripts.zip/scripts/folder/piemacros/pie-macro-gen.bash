#!/bin/bash

echo '\newcommand{\Pie-'$1'}[#1]{'
echo '	includegraphics[width=#1]{data/Pie-'$1'.png}'
echo '}'
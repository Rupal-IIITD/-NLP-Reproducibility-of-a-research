#!/bin/bash
# File:     py_verify_compare.bash
# Author:   Alex Warren
# Purpose:  Allows easy comparison of 
#                   repro_status.py -validate . all
#           with original files.
cd ../py_verify
for f in */raw.txt
do
    echo $f
    sort $f -o $f
done
for f in */py_version.txt
do
    sort $f -o $f
done

cat */raw.txt > all_raw.txt
cat */py_version.txt > all_py.txt
kompare all_raw.txt all_py.txt
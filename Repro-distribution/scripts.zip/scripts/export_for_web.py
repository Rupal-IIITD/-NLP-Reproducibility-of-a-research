#! /usr/bin/python
"""
export_for_web copies the database so it can be distributed
over the internet. It removes explicit references to the student
workers and places files where they can be zipped and linked to
directly.
"""
#

import argparse
import glob
from os import path, stat, makedirs
from random import shuffle
import shutil
import re
#from os import makedirs


PARSER = argparse.ArgumentParser(
    description='Copies database into folders for distribution over the web.')
PARSER.add_argument("dir",
    help="Root directory of the reproducibility database.")

ALL_SOURCES = ["asplos12", "ccs12", "oopsla12", "osdi12",
               "pldi12", "sigmod12", "sosp11", "taco9", "tissec15", "tocs30",
               "tods37", "toplas34", "vldb12", "vldb12_new",
               path.join("removed_papers","ccs12"),
               path.join("removed_papers","oopsla12"),
               path.join("removed_papers","sigmod12"),
               path.join("removed_papers","vldb12_new")]

NAMES = ['alex', 'akash', 'chirag', 
         'gina', 'michelle', 'zuoming', 'pruthvi', 'david', 'patrick']
OTHER_ANON = ['pfchan', 'EyeOfTheTiger']
ANONIMIZED = ['student'+str(ii) for ii in range(len(NAMES))]
shuffle(ANONIMIZED)

def main():
    """
    Run if the module is run as a script. Copies database for export.
    """
    args = PARSER.parse_args()
    export_for_web(args.dir)

def export_for_web(repro_root):
    """
    Exports the database from the given root directory to export directories.
    """
    website_destination = path.join(repro_root, "docs", "website", "data")
    archive_destination = path.join(repro_root, "docs", "website", 
                                                     "repro_distribution")
    for source in ALL_SOURCES:
        source_record_files = glob.glob(
            path.join(repro_root, source,"*","data.txt"))
        source_record_files.extend(
            glob.glob(path.join(repro_root, source,"*","build_notes.txt")))
        source_record_files.extend(
            glob.glob(path.join(repro_root, source,"*","survey.txt")))
        source_record_files.extend(
            glob.glob(path.join(repro_root, source,"*","paper.bib")))
        for source_path in source_record_files:
            if 'build' in source_path and stat(source_path).st_size <= 415:
                continue #skip empty build files
            file_pointer = open(source_path, 'rb')
            source_path_split = source_path.split('/')
            archive_path = path.join(archive_destination, source,
                             source_path_split[-2], source_path_split[-1])

            if 'data.txt' in source_path:
                result = sanatize_data_file(file_pointer)
                suffix = 'data.txt'
                #Copy emailers and bibtex into archive
                #These can be generated from other scripts
                # \/ they contain author emails, so not distributed
                # copy_emailers(path.split(source_path)[0],
                #               path.split(archive_path)[0])
            elif 'survey.txt' in source_path:
                result = sanatize_survey_file(file_pointer)
                suffix = 'survey.txt'
            elif 'paper.bib' in source_path:
                suffix = 'bib.html'
                result = file_pointer.read()
            else: #must be build_notes.txt
                assert 'build_notes.txt' in source_path, "expected build_notes.txt, found %s" % source_path
                result = sanatize_build_file(file_pointer)
                suffix = 'build.txt'

            if not 'removed_papers' in source:
                website_path = path.join(website_destination,
                            "{0}_{1}_{2}".format(
                            source, source_path_split[-2], suffix))
                #Write file for individual link on website
                write_file(website_path, result)
            #Write file for archive
            write_file(archive_path, result)


def copy_emailers(source, destination):
    """
    Copies the bibtex and all the emailer scripts from the
    source to the destination.
    """
    if not path.isdir(destination):
        makedirs(destination)
    email_script_paths = glob.glob(path.join(source,"es*.bash"))
    for email_script_path in email_script_paths:
        shutil.copy(email_script_path, destination)



def write_file(file_path, content):
    """
    Simple sub routine to check if a path exists, if not create it
    and write to it.
    """
    parent_dir = path.split(file_path)[0]
    if not path.isdir(parent_dir):
        makedirs(parent_dir)
    file_pointer = open(file_path, 'w')
    file_pointer.write(content)
    file_pointer.close()

def sanatize_text(text):
    """
    Replace student researcher names with random name
    in the form student# where # is a random integer
    determined at run time.
    """
    for name, replacement in zip(NAMES, ANONIMIZED):
        text = re.sub(name, replacement, text, flags=re.I)
    return text

def sanative_text_no_id(text):
    """
    Replace researchers and other anon words with student.
    """
    for name in NAMES + OTHER_ANON:
        text = re.sub(name, "student", text, flags=re.I)
    return text

def sanatize_data_file(text_file):
    """
    Loop through a data.txt and sanatize comment and worker identification
    type fields.
    """
    result = []
    for line in text_file:
        if "AUTHOR:EMAIL" in line:
            continue #don't include emails
        dummy, dummy, remainder = line.partition(':')
        field, dummy, remainder = remainder.partition('[')
        if ('COMMENT' in field or 'ANALYSIS_BY' in field
            or 'VERIFY_BY' in field):
            line = sanatize_text(line)
        result.append(line)
    return ''.join(result)

def sanatize_build_file(text_file):
    """
    Loop through a build_notes.txt and sanatize references to
    student researchers.
    """
    result = []
    for line in text_file:
        if "BUILD_BY" in line:
            result.append(sanatize_text(line))
        else:
            result.append(sanative_text_no_id(line))
    return ''.join(result)

def sanatize_survey_file(text_file):
    """
    Loop through a survey.txt and remove anonomous comments.
    """
    skip = lambda x: "ANONYMOUS_COMMENT" in x or "UNIQUE_ID" in x or "EMAIL" in x
    return ''.join("" if skip(line) else line for line in text_file)

if __name__ == "__main__":
    main()

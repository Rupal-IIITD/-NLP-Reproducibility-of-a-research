#!/usr/bin/python
"""
remove consecutive newlines that were created when
build notes were updated
"""

import argparse
import glob
from os import path

PARSER = argparse.ArgumentParser(
    description='Fixes duplicate new line in build_notes.')
PARSER.add_argument("dir",
    help="Root directory of the reproducibility database.")


ALL_SOURCES = ["asplos12", "ccs12", "oopsla12", "osdi12",
               "pldi12", "sigmod12", "sosp11", "taco9", "tissec15", "tocs30",
               "tods37", "toplas34", "vldb12", "vldb12_new",
               path.join("removed_papers","ccs12"),
               path.join("removed_papers","oopsla12"),
               path.join("removed_papers","sigmod12"),
               path.join("removed_papers","vldb12_new")]

def main():
    """
    For removing all the new lines found in buildnotes.
    """
    args = PARSER.parse_args()
    repro_root = args.dir
    all_build_notes = []
    for source in ALL_SOURCES:
        all_build_notes.extend(glob.glob(
            path.join(repro_root, source,"*","build_notes.txt")))
    for build_notes_path in all_build_notes:
        f_build_notes = open(build_notes_path, 'r')
        original = []
        new_line_count = 0
        in_new_section = False
        for line in f_build_notes:
            if not in_new_section:
                if len(line)==1:
                    new_line_count = (new_line_count + 1)%4
                else:
                    new_line_count = 0
                if new_line_count > 0:
                    continue
            original.append(line)
            if "1:END_NOTES" in line:
                in_new_section = True
        if not in_new_section:
            print "Missing end in " + build_notes_path
        f_build_notes.close()
        new_build_notes = ''.join(original)
        f_build_notes = open(build_notes_path, 'w')
        f_build_notes.write(new_build_notes)
        f_build_notes.close()



if __name__ == "__main__":
    main()

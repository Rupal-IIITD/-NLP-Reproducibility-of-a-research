#!/usr/bin/python
"""
Convert Build notes to new version where
there is fields for reviewers to try another
attempt
"""

import argparse
import glob
from os import path

PARSER = argparse.ArgumentParser(
    description='Migrates build_notes to add reviewer fields.')
PARSER.add_argument("dir",
    help="Root directory of the reproducibility database.")

ALL_SOURCES = ["asplos12", "ccs12", "oopsla12", "osdi12",
               "pldi12", "sigmod12", "sosp11", "taco9", "tissec15", "tocs30",
               "tods37", "toplas34", "vldb12", "vldb12_new",
               path.join("removed_papers","ccs12"),
               path.join("removed_papers","oopsla12"),
               path.join("removed_papers","sigmod12"),
               path.join("removed_papers","vldb12_new")]

NEW_FIELDS = """2:BUILD_BY[name] 
2:BUILD_ENVIRONMENT[operating system 32 vs 64]

2:END_BUILD_ENVIRONMENT
2:DEPENDENCIES[list of dependencies with where to get them]

2:END_DEPENDENCIES
2:NOTES[notes on attempted build]

2:END_NOTES"""

def main():
    """
    Run if the module is run as a script. Migrates
    database to new form.
    """
    args = PARSER.parse_args()
    repro_root = args.dir
    all_build_notes = []
    for source in ALL_SOURCES:
        all_build_notes.extend(glob.glob(
            path.join(repro_root, source,"*","build_notes.txt")))
    for build_notes_path in all_build_notes:
        f_build_notes = open(build_notes_path, 'r')
        original = []
        for line in f_build_notes:
            if "2:BUILD_BY[name]" in line:
                break
            else:
                original.append(line)
        f_build_notes.close()
        original.append(NEW_FIELDS)
        new_build_notes = '\n'.join(original)
        f_build_notes = open(build_notes_path, 'w')
        f_build_notes.write(new_build_notes)
        f_build_notes.close()



if __name__ == "__main__":
    main()

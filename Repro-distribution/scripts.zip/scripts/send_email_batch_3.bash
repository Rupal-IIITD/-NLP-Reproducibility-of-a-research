#Sender script for batch_3
bash ../ccs12/CzeskisDKWB12/es_batch_3.bash $1
sleep 5
bash ../ccs12/DamGL12/es_batch_3.bash $1
sleep 5
#bash ../sigmod12/SidlauskasSJ12/es_batch_3.bash $1
sleep 5
bash ../oopsla12/Zhang0LZMY12/es_batch_3.bash $1
sleep 5
#bash ../ccs12/LuLWLJ12/es_batch_3.bash $1
sleep 5
bash ../tods37/ShengTL12/es_batch_3.bash $1
sleep 5
bash ../asplos12/LeeS12/es_batch_3.bash $1
sleep 5
bash ../vldb12_new/KangLM12/es_batch_3.bash $1
sleep 5
#bash ../toplas34/VerdoolaegeJB12/es_batch_3.bash $1
sleep 5
bash ../asplos12/MartignoniMPSM12/es_batch_3.bash $1
sleep 5
bash ../taco9/BelviranliBG13/es_batch_3.bash $1
sleep 5
bash ../taco9/CoppensSM13/es_batch_3.bash $1
sleep 5
bash ../taco9/DioufHCOP13/es_batch_3.bash $1
sleep 5
bash ../ccs12/MavrogiannopoulosVVP12/es_batch_3.bash $1
sleep 5
#bash ../osdi12/ravindranath2012appinsight/es_batch_3.bash $1
sleep 5

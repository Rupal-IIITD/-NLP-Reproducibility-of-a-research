#!/bin/bash
# File:              refactor.bash
# Author:      Alex Warren
# Purpose:   converts to new data.txt format
# Usage      bash refactor.bash osdi12
# Or for every relevant conference (determined 5/31)
#                      bash refactor.bash convert_list
#based on debug.bash not finished


if [ $1 = "convert_list" ]; then
    arg_list="osdi12 pldi12 sosp11 tissec15 tocs30 "
else
    arg_list="$@"
fi

for arg in $arg_list
do
    tput setaf 5
    echo "In $arg"
    tput setaf 7
    directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
    for D in $directories; do
        tput setaf 4
        echo "Refactoring $D/data.txt"
        tput setaf 7

        #get variables for the scripts
        data=$(<$D/data.txt)
        status=( $(sed -n -e 's/ARTICLE:STATUS.*\] //p' $D/data.txt) )
        found=$(sed -n -e 's/TOOL:LINK_FOUND.*\] //p' $D/data.txt)
        url=$(sed -n -e 's/TOOL:LINK\[url\] //p' $D/data.txt)

        #check if there was a url
        if [[ -z "$url"  ]]; then
            found=no
        fi
       
        #simplify the ARTICLE:STATUS - assuming they are all finished in the conferences this is being run on so just put that
        #store in result
        result=$( echo "$data" | sed 's|ARTICLE:STATUS.*|ARTICLE:STATUS\[not_finished,finished\] finished|g' )

        #this does a multiline match, and replace with nothing
        #note sed allows differnt seperaters, here I used | but usually / is used as below - I think | is more readable
        #tr -s '\n'    removes successive newline characters
        result=$( echo "$result" | sed -e '{;N;s|TOOL:LINK\[url.*\nTOOL.*||g;}' | tr -s '\n')
        
        #these lines do a differnt replacement depending on what type of link it was
        sani_url=$( echo "$url" | sed -e 's/[\/&]/\\&/g' )
        if [ "$found" == "article" ]; then
            result=$( echo "$result" | sed '/^TOOL:NAME/a TOOL:ARTICLE_LINK[unknown,none,url,broken and url] '"$sani_url"'\nTOOL:GOOGLE_LINK[unknown,none,url,broken and url] \nTOOL:EMAIL_LINK[unknown,none,sent_no_url,url,broken and url] \nTOOL:DATA_LINK[unknown,none,url,broken and url] unknown')
        elif [ "$found" == "google" ]; then
            result=$( echo "$result" | sed '/^TOOL:NAME/a TOOL:ARTICLE_LINK[unknown,none,url,broken and url] none\nTOOL:GOOGLE_LINK[unknown,none,url,broken and url]  '"$sani_url"'\nTOOL:EMAIL_LINK[unknown,none,sent_no_url,url,broken and url] \nTOOL:DATA_LINK[unknown,none,url,broken and url] unknown')
        else
            result=$( echo "$result" | sed '/^TOOL:NAME/a TOOL:ARTICLE_LINK[unknown,none,url,broken and url] none\nTOOL:GOOGLE_LINK[unknown,none,url,broken and url] none\nTOOL:EMAIL_LINK[unknown,none,sent_no_url,url,broken and url] unknown\nTOOL:DATA_LINK[unknown,none,url,broken and url] unknown')
        fi

        #this just places this text at the end of result
        result="$result
VERIFY_BUILD:ANALYSIS_BY[name] 
VERIFY_BUILD:STATUS[unknown,needed,not_needed,started,finished] 
VERIFY_BUILD:COMMENT[string] "


        #write result to the data.txt
        #make sure to use git diff to check that the correct things are being changed
        #echo "$result"
        echo "$result" > $D/data.txt

    done
done
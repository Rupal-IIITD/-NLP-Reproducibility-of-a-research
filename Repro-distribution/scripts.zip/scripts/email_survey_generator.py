#! /usr/bin/python
"""
email_servey_generator
A script to generate survey emails for every paper that wasn't excluded by having a duplicated author.
"""

import argparse
import hashlib
import textwrap
from collections import Counter
from repro_loader import *
from string import Template
from os import path
from pprint import pprint
from bibtexparser.bparser import BibTexParser

SALT = "unweb"

def getBibtex(file_path):
    with open(file_path) as bibtex_file:
        parser = BibTexParser(bibtex_file)
    d = parser.get_entry_dict()
    for val in d.values():
        if 'author' in val:
            return val
    print "BIBTEX failure"

#These counts can be used to test that the numbers add up and
#match the graphs that we have.
NUM_SOURCE = {'article':0, 'google':0, 'email':0, 'none':0}
def sourceOfCode(rcd):
    global NUM_SOURCE
    if rcd.TOOL.ARTICLE_LINK.url and not rcd.TOOL.ARTICLE_LINK.broken:
        NUM_SOURCE['article'] += 1
        return ("article_link", rcd.TOOL.ARTICLE_LINK.url)
    if rcd.TOOL.GOOGLE_LINK.url and not rcd.TOOL.GOOGLE_LINK.broken:
        NUM_SOURCE['google'] += 1
        return ("google_link", rcd.TOOL.GOOGLE_LINK.url)
    if rcd.EMAIL1.CODE_AVAILABLE.yes:
        NUM_SOURCE['email'] += 1
        if rcd.TOOL.EMAIL_LINK.url and not rcd.TOOL.EMAIL_LINK.broken:
            return ("email", rcd.TOOL.EMAIL_LINK.url)
        else:
            return ("email", "")
    else:
        NUM_SOURCE['none'] += 1
        return ("none", "")

#Templates use $ to indicate a variable
# $$ is converted to $
SCRIPT_TEMPLATE = Template(
"""########################################################
#Script_in $script_dir
sent=false

if [[ "$$sent" != "false" ]]; then
  echo "Email not sent because \\"already sent\\" parameter is not set to false"
  exit 1
fi

MESSAGE="$$(cat <<\ENDHEREDOC
$message
ENDHEREDOC
)"

MESSAGE="`echo "$$MESSAGE" | sed s/QUOTE/\\\'/g`"

EMAILS=( $email_address_array )
HASHES=( $hash_id_array )

if [[ $${#EMAILS[@]} != $${#HASHES[@]} ]]; then
  echo "Mismatch between emails and hashes."
  exit 1
fi

for ((i=0;i<$${#EMAILS[@]};++i)); do
    echo "Sending $script_dir to $${EMAILS[i]}"
    CURRENT_MESSAGE="`echo "$$MESSAGE" | sed s/SURVEY_ID/$${HASHES[i]}/g`"
    echo "$$CURRENT_MESSAGE" | \\
    $$1 -V -tls -smtp-auth login -smtp-server smtp.gmail.com \\
    -smtp-port 587 -c ~/bin/email.conf -smtp-user ccollberg@gmail.com -smtp-pass \\
    $$EMAILPASSWORD -from-addr ccollberg@gmail.com -from-name "Christian Collberg" \\
    -subject "$subject" \\
    "$${EMAILS[i]}"
    echo "EXIT_CODE $$?"
    sleep $$EMAIL_SLEEP_TIME
done
""")

EMAIL_TEMPLATE = Template(
"""Dear author,

Our apologies for bothering you again. In order to make our
data collection as complete as possible, we would very much
appreciate it if you (or one of your co-authors) would fill out the
survey below. If you have already sent us your comments in an
email, please also copy them into the online survey itself.

Only one person from each team needs to fill out the survey.

We will close this survey September 29, 2014.

Thank you for your help,
Christian and Todd

===============================================
Dear author,

Over the last year we have conducted a study into the extent to which
Computer Systems researchers share their research artifacts, and
whether published code builds. Your $venue paper,
   $title
was part of this study. In fact, you may have received an email
from us asking for the code related to your paper or you might have
come across our website
   http://reproducibility.cs.arizona.edu
or even read our (very preliminary) technical report
   http://reproducibility.cs.arizona.edu/v1/tr.pdf.

In our study we looked for code related to papers published in ACM
conferences and journals, and, if found, tried to build it. For your
paper, we found that
$catagory_message
$source_message$build_message
The complete data we collected for your paper can be found here:
   http://reproducibility.cs.arizona.edu/v2/index.html#$bibtex
$build_notes
The following document explains the data schema:
   http://reproducibility.cs.arizona.edu/v2/format.html

To make sure that our results are as accurate as possible, please
answer a very short online questionnaire related to the data we collected
about your paper:
   https://www.surveymoz.com/s/124740RHYUP?x=SURVEY_ID

Please complete this survey by September 22, 2014.

Note that this is not an anonymous survey. Rather, your response
to the questionnaire can be attributed to you. Also note that if your
paper has multiple authors, each author will get a copy of this email,
with a unique code that ties their response to them. Thus, each author
can provide us with a different response.

We very much appreciate your help,
Christian Collberg
Todd Proebsting""")


def createEmailMessage(database, rcd):
    d = {}
    bib = rcd.bib
    wrp = textwrap.TextWrapper(subsequent_indent="   ", width=70)
    d['title'] = wrp.fill(bib['title'])
    d['bibtex'] = str(rcd.BIBTEX.LABEL)
    d['venue'] = rcd.bib['conf_title']

    d['source_message'] = ""
    d['build_message'] = ""

    if rcd.ARTICLE.IMPLEMENTATION_EXISTS.yes:
        d['catagory_message'] = "The paper is PRACTICAL (i.e. backed by code)"
        source, url = sourceOfCode(rcd)
        if source == "article_link":
            d['source_message'] =  \
                "The code could be found online at \n       " + url
        elif source == "google_link":
            d['source_message'] =  \
                "The code could be found online at \n       " + url
        elif source == "email":
            d['source_message'] = \
                "We received the code in an email from you"
        elif source == "none":
            d['source_message'] = "no code could be located"
        if not rcd.BUILD.STATUS.finished:
            d['build_message'] = ""
        elif rcd.BUILD.STATUS.online and rcd.BUILD.STATUS.runs:
            d['build_message'] = "We checked your online implementation successfully"
        elif rcd.BUILD.STATUS.online and not rcd.BUILD.STATUS.runs:
            d['build_message'] = "We checked your online implementation unsuccessfully"
        elif rcd.BUILD.STATUS.compiles:
            d['build_message'] = "We were able to build the code"
        else:
            d['build_message'] = "We were unable to build the code"
    elif rcd.ARTICLE.IMPLEMENTATION_EXISTS.no:
        d['catagory_message'] = "The paper is THEORETICAL (not backed by code)"
    elif rcd.ARTICLE.IMPLEMENTATION_EXISTS.hardware:
        d['catagory_message'] = "The paper is HARDWARE (requires special hardware to reproduce)"



    d['build_notes'] = ""
    d['catagory_message'] = "   * " + d['catagory_message']
    if d['source_message']:
        d['source_message'] = "   * " + d['source_message'] + "\n"
    if d['build_message']:
        d['build_message'] = "   * " + d['build_message'] + "\n"

    build_note_id =  rcd.dir[2:].replace('/', '_')
    if path.isfile(path.join(database.repro_root, "docs", "website", "v2", "data", build_note_id + "_build.txt")):
        d['build_notes'] = "In particular, the build notes can be found here:\n" + \
                "   http://reproducibility.cs.arizona.edu/v2/data/{}_build.txt".format(build_note_id)

    return EMAIL_TEMPLATE.substitute(d).encode('ascii', 'ignore')

CONF_TITLES = {
    "asplos12":"ASPLOS'12",
    "ccs12":"CCS'12",
    "oopsla12":"OOPSLA'12",
    "osdi12":"OSDI'12",
    "pldi12":"PLDI'12",
    "sigmod12":"SIGMOD'12",
    "sosp11":"SOSP'11",
    "taco9":"TACO'",
    "tissec15":"TISSEC'12",
    "tocs30":"TOCS'12",
    "tods37":"TODS'12",
    "toplas34":"TOPLAS'12",
    "vldb12":"VLDB'11",
    "vldb12_new":"VLDB'11"}

def checkLink(link):
    """
    Check that a path is present in the website directory
    """
    link_path = path.join(database.repro_root, 'docs', 'website', link)
    return os.path.isfile(link_path)

def generateScripts(database, responders):
    sender_script = ["#Sender script for survey emails", "export EMAIL_SLEEP_TIME=5"]
    id_map = []
    all_hashes = []
    for rcd in database.records:
        if str(rcd.BIBTEX.LABEL) in responders:
            continue
        if rcd.EMAIL.STATUS.not_needed or \
               (rcd.EMAIL.STATUS.needed and rcd.EMAIL.STATUS.request_1):
            rcd.bib = getBibtex(path.join(rcd.dir, "paper.bib"))
            conf_title = CONF_TITLES[rcd.conf]
            if conf_title == "TACO'":
                conf_title += rcd.bib['year']
            rcd.bib['conf_title'] = conf_title

            email_message = createEmailMessage(database, rcd)
            emails = [email for email in rcd.AUTHOR.EMAIL_REAL.value]
            hashes = [hashlib.sha224(str(rcd.BIBTEX.LABEL)+email+rcd.bib['conf_title']+SALT).hexdigest()[0:20]
                for email in rcd.AUTHOR.EMAIL_REAL.value]
            script = SCRIPT_TEMPLATE.substitute(
                message=email_message.replace("'","QUOTE"),
                subject="Repeatability Study: Your %s Paper [LAST REMINDER]" % conf_title,
                script_dir=rcd.dir,
                email_address_array=" ".join('"%s"' % email for email in emails),
                hash_id_array=" ".join('"%s"' % hash_id for hash_id in hashes))
            script_file_name = path.join(rcd.dir, "es_survey_reminder.bash")
            sender_script.append("bash {} $1".format(path.join("..", script_file_name)))
            #sender_script.append("sleep 5")
            with open(path.join(database.repro_root, script_file_name), 'wb') as script_file:
                script_file.write(script)
            for email, hash_id in zip(emails, hashes):
                id_map.append("{} {} {}".format(hash_id, email, rcd.dir))
            all_hashes.extend(hashes)
            print '#' * 10
            print script
    with open(path.join(database.repro_root, "scripts", "send_email_survey_reminder.bash"), 'wb') as survey_file:
        survey_file.write("\n".join(sender_script))
    # with open(path.join(database.repro_root, "logs", "survey_id_map.txt"), 'wb') as id_map_file:
    #     id_map_file.write("\n".join(id_map))
    print "Hash Collisions:"
    print [x for x, y in Counter(hashes).items() if y > 1]

def main():
    global NUM_SOURCE
    parser = argparse.ArgumentParser(description='create email scripts for distributing the survey')
    parser.add_argument("dir", help="Root directory of the reproducibility database.")

    args = parser.parse_args()
    print("\nLoading database from {}".format(args.dir))
    database = repro_database(args.dir, ["all"])
    with open(path.join(args.dir, "logs", "survey_responded.txt"), 'rb') as survey_responded:
        responders = [bib.strip() for bib in survey_responded]

    generateScripts(database, responders)
    print("\nCode available:")
    pprint(NUM_SOURCE)
    
    # for rcd in database.records:
    #     if rcd.EMAIL.STATUS.not_needed or \
    #            (rcd.EMAIL.STATUS.needed and rcd.EMAIL.STATUS.request_1):
    #         print ""
    #         print '-' * 10
    #         #print CLASSIFICATION[str(rcd.ARTICLE.IMPLEMENTATION_EXISTS)]
    #         print rcd.path
    #         print sourceOfCode(rcd)[0]
    #         print rcd.dir
    #         print rcd.BIBTEX.LABEL
    #         print rcd.AUTHOR.EMAIL_REAL.value
    #     break

if __name__ == "__main__":
    main()


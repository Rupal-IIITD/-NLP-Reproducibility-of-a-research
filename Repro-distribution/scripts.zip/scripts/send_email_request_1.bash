#Sender script for request_1
#bash ../pldi12/PetrovVSD12/es_request_1.bash $1
#sleep 5
#exit
bash ../tocs30/SaezFKP12/es_request_1.bash $1
sleep 5
bash ../pldi12/DilligDA12/es_request_1.bash $1
sleep 5
bash ../oopsla12/WimmerW12/es_request_1.bash $1
sleep 5
bash ../sosp11/MickensD11/es_request_1.bash $1
sleep 5
bash ../pldi12/LeungGAGJL12/es_request_1.bash $1
sleep 5
bash ../osdi12/kotla2012pasture/es_request_1.bash $1
sleep 5
bash ../vldb12/SunAH12/es_request_1.bash $1
sleep 5
bash ../oopsla12/TsengT12/es_request_1.bash $1
sleep 5
bash ../vldb12/CormodeTY11/es_request_1.bash $1
sleep 5
bash ../tocs30/YuanZPZS12/es_request_1.bash $1
sleep 5
bash ../oopsla12/CousotCLB12/es_request_1.bash $1
sleep 5
bash ../sosp11/AndrusDHLN11/es_request_1.bash $1
sleep 5
bash ../pldi12/NagarakatteBMM12/es_request_1.bash $1
sleep 5
bash ../vldb12/GoasdoueKLM11/es_request_1.bash $1
sleep 5
bash ../pldi12/JinSSSL12/es_request_1.bash $1
sleep 5
bash ../oopsla12/InoueHWN12/es_request_1.bash $1
sleep 5
bash ../sosp11/LloydFKA11/es_request_1.bash $1
sleep 5
bash ../pldi12/OanceaR12/es_request_1.bash $1
sleep 5
bash ../vldb12/KruegerKGSSCPDZ11/es_request_1.bash $1
sleep 5
bash ../vldb12/NguyenMNNF11/es_request_1.bash $1
sleep 5
bash ../pldi12/ChenDA12/es_request_1.bash $1
sleep 5
bash ../oopsla12/HafizO12/es_request_1.bash $1
sleep 5
bash ../sosp11/MaoCZWZK11/es_request_1.bash $1
sleep 5
bash ../oopsla12/MullerC12/es_request_1.bash $1
sleep 5
bash ../oopsla12/LiuSLG12/es_request_1.bash $1
sleep 5
bash ../pldi12/SamadiHMLM12/es_request_1.bash $1
sleep 5
bash ../tissec15/BasinBK12/es_request_1.bash $1
sleep 5
bash ../tocs30/GebhartJTKDLS12/es_request_1.bash $1
sleep 5
bash ../pldi12/HolewinskiRRFPRS12/es_request_1.bash $1
sleep 5
bash ../pldi12/EomD12/es_request_1.bash $1
sleep 5
bash ../pldi12/JohnsonKPZA12/es_request_1.bash $1
sleep 5
bash ../pldi12/AlbarghouthiKNR12/es_request_1.bash $1
sleep 5
bash ../vldb12/ZhangTPH11/es_request_1.bash $1
sleep 5
bash ../pldi12/FengGN12/es_request_1.bash $1
sleep 5
bash ../oopsla12/GordonPPBD12/es_request_1.bash $1
sleep 5
bash ../vldb12/LiuZW11/es_request_1.bash $1
sleep 5
bash ../oopsla12/BocqD12/es_request_1.bash $1
sleep 5
bash ../pldi12/HackettG12/es_request_1.bash $1
sleep 5
bash ../osdi12/li2012making/es_request_1.bash $1
sleep 5
bash ../oopsla12/HuangZ12/es_request_1.bash $1
sleep 5
bash ../oopsla12/Anderson12/es_request_1.bash $1
sleep 5
bash ../osdi12/dunn2012eternal/es_request_1.bash $1
sleep 5
bash ../sosp11/ColpNZACDLW11/es_request_1.bash $1
sleep 5
bash ../oopsla12/HaydenSDHF12/es_request_1.bash $1
sleep 5
bash ../osdi12/nightingale2012flat/es_request_1.bash $1
sleep 5
bash ../vldb12/FangSYB11/es_request_1.bash $1
sleep 5
bash ../oopsla12/LucasER12/es_request_1.bash $1
sleep 5
bash ../oopsla12/Coplien12/es_request_1.bash $1
sleep 5
bash ../oopsla12/SchillerE12/es_request_1.bash $1
sleep 5
bash ../pldi12/ZaparanuksH12/es_request_1.bash $1
sleep 5
bash ../tocs30/BugnionDRSW12/es_request_1.bash $1
sleep 5
bash ../vldb12/RanuS11/es_request_1.bash $1
sleep 5
bash ../oopsla12/AusielloDFF12/es_request_1.bash $1
sleep 5
bash ../oopsla12/KumarFBGT12/es_request_1.bash $1
sleep 5
bash ../tissec15/BhargavanFCZ12/es_request_1.bash $1
sleep 5
bash ../tissec15/RoemerBSS12/es_request_1.bash $1
sleep 5
bash ../vldb12/RohPKSL11/es_request_1.bash $1
sleep 5
bash ../pldi12/WuTHCY12/es_request_1.bash $1
sleep 5
bash ../vldb12/PavloJZ11/es_request_1.bash $1
sleep 5
bash ../oopsla12/PrountzosMP12/es_request_1.bash $1
sleep 5
bash ../tocs30/ErlingssonPPBM12/es_request_1.bash $1
sleep 5
bash ../osdi12/corbett2012spanner/es_request_1.bash $1
sleep 5
bash ../pldi12/CarteyLM12/es_request_1.bash $1
sleep 5
bash ../tocs30/EbrahimiLMP12/es_request_1.bash $1
sleep 5
bash ../sosp11/MesnierCLA11/es_request_1.bash $1
sleep 5
bash ../vldb12/FabbriL11/es_request_1.bash $1
sleep 5
bash ../pldi12/GodefroidT12/es_request_1.bash $1
sleep 5
bash ../sosp11/SovranPAL11/es_request_1.bash $1
sleep 5
bash ../oopsla12/CamposE12/es_request_1.bash $1
sleep 5
bash ../pldi12/ZhangAM12/es_request_1.bash $1
sleep 5
bash ../sosp11/ZhouFNHLS11/es_request_1.bash $1
sleep 5
bash ../vldb12/QumsiyehPN11/es_request_1.bash $1
sleep 5
bash ../vldb12/LinJZXL11/es_request_1.bash $1
sleep 5
bash ../tocs30/VeeraraghavanLWOCFN12/es_request_1.bash $1
sleep 5
bash ../sosp11/ZhangCCZ11/es_request_1.bash $1
sleep 5
bash ../sosp11/CalderWONSMXSWSHUKEBMAAHHBDAMSMR11/es_request_1.bash $1
sleep 5
bash ../osdi12/attariyan2012x/es_request_1.bash $1
sleep 5
bash ../pldi12/KruijfSJ12/es_request_1.bash $1
sleep 5
bash ../oopsla12/SiddiquiK12/es_request_1.bash $1
sleep 5
bash ../oopsla12/KlingMCR12/es_request_1.bash $1
sleep 5
bash ../pldi12/BaconCS12/es_request_1.bash $1
sleep 5
bash ../oopsla12/SreeramP12/es_request_1.bash $1
sleep 5
bash ../oopsla12/Effinger-DeanLCGB12/es_request_1.bash $1
sleep 5
bash ../vldb12/YangRW11/es_request_1.bash $1
sleep 5
bash ../vldb12/MarcusWKMM11/es_request_1.bash $1
sleep 5
bash ../pldi12/MorrisettTTTG12/es_request_1.bash $1
sleep 5
bash ../osdi12/guo2012spotting/es_request_1.bash $1
sleep 5
bash ../oopsla12/Xu12/es_request_1.bash $1
sleep 5
bash ../sosp11/ChenSGK11/es_request_1.bash $1
sleep 5
bash ../osdi12/han2012megapipe/es_request_1.bash $1
sleep 5
bash ../tocs30/GandhiHRK12/es_request_1.bash $1
sleep 5
bash ../sosp11/AdyaCMP11/es_request_1.bash $1
sleep 5
bash ../oopsla12/KulkarniC12/es_request_1.bash $1
sleep 5
bash ../sosp11/GlendenningBKA11/es_request_1.bash $1
sleep 5
bash ../pldi12/OhHLLY12/es_request_1.bash $1
sleep 5
bash ../pldi12/LiuZJDK12/es_request_1.bash $1
sleep 5
bash ../pldi12/Chen12/es_request_1.bash $1
sleep 5

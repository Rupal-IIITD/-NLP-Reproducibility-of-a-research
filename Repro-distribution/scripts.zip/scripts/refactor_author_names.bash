#!/bin/bash
# File:              refactor.bash
# Author:      Alex Warren
# Purpose:   converts to new data.txt format
# Usage      bash refactor.bash osdi12
# Or for every relevant conference (determined 5/31)
#                      bash refactor.bash convert_list
#based on debug.bash not finished

# "oopsla12 osdi12 pldi12 sosp11 tissec15 tocs30 vldb12"
if [ $1 = "all" ]; then
    arg_list="asplos12 ccs12 oopsla12 osdi12 pldi12 sigmod12 sosp11 taco9 tissec15 tocs30 tods37 toplas34 vldb12" 
else
    arg_list="$@"
fi

for arg in $arg_list
do
    tput setaf 5
    #echo "In $arg"
    tput setaf 7
    directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
    for D in $directories; do
        tput setaf 4
        echo "Refactoring $D/data.txt"
        tput setaf 7

        #get variables for the scripts
        result=$(<$D/data.txt)

        authors=$(java -jar parseBibtex $D/paper.bib -author)
        echo $authors >> authors.txt

        result=$( echo "$result" | sed 's|AUTHOR:NAMES.*||g' )
        result=$( echo "$result" | sed 's|AUTHOR:FIRST_AUTHOR_NAME.*||g' )
        result=$( echo "$result" | sed 's|AUTHOR:FIRST_AUTHOR_EMAIL.*|AUTHOR:NAMES[list of first_last] '"$authors"'|g' | tr -s '\n')

        echo "$result" > $D/data.txt
    done
done
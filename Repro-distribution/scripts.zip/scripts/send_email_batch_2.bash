#Sender script for batch_2
echo "SENDING vldb12_new/FanLZCH12"
bash ../vldb12_new/FanLZCH12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/SzeferL12"
bash ../asplos12/SzeferL12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/CamenischLN12"
bash ../ccs12/CamenischLN12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/YangLQQMM12"
bash ../ccs12/YangLQQMM12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/HallBBGN12"
bash ../vldb12_new/HallBBGN12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/GordonKKKM0V12"
bash ../ccs12/GordonKKKM0V12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/MeisnerW12"
bash ../asplos12/MeisnerW12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/NarayananH12"
bash ../asplos12/NarayananH12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/HardtN12"
bash ../ccs12/HardtN12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/RoufMXXMG12"
bash ../ccs12/RoufMXXMG12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/LiPZI12"
bash ../taco9/LiPZI12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/KanagalAPJYP12"
bash ../vldb12_new/KanagalAPJYP12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/ChuangGM12"
bash ../ccs12/ChuangGM12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/GreathouseXLA12"
bash ../asplos12/GreathouseXLA12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/GordonAHBLST12"
bash ../asplos12/GordonAHBLST12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/AbbasiVG12"
bash ../taco9/AbbasiVG12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/YiapanisRBL13"
bash ../taco9/YiapanisRBL13/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/BegleyHC12"
bash ../sigmod12/BegleyHC12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/BenderFJKKMMSSZ12"
bash ../vldb12_new/BenderFJKKMMSSZ12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/BaoDM12"
bash ../vldb12_new/BaoDM12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/SharafeddineJA12"
bash ../taco9/SharafeddineJA12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/VaradarajanKFRS12"
bash ../ccs12/VaradarajanKFRS12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/GeraciS12"
bash ../taco9/GeraciS12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/WilliamsST12"
bash ../ccs12/WilliamsST12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/HalimIKY12"
bash ../vldb12_new/HalimIKY12/es_batch_2.bash $1
sleep 5
echo "SENDING toplas34/JongeKVS12"
bash ../toplas34/JongeKVS12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/SelkeLB12"
bash ../vldb12_new/SelkeLB12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/GraefeKK12"
bash ../tods37/GraefeKK12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/AuK12"
bash ../ccs12/AuK12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/CaoSTC12"
bash ../vldb12_new/CaoSTC12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/LewisTG12"
bash ../taco9/LewisTG12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/KonigDCN11"
bash ../vldb12_new/KonigDCN11/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/AlmeidaBBBKB12"
bash ../ccs12/AlmeidaBBBKB12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/KamaraMR12"
bash ../ccs12/KamaraMR12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/UpadhyayaBS12"
bash ../vldb12_new/UpadhyayaBS12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/JinRXL12"
bash ../sigmod12/JinRXL12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/PattersonENAA12"
bash ../vldb12_new/PattersonENAA12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/AlagiannisBBIA12"
bash ../sigmod12/AlagiannisBBIA12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/CuiWCS13"
bash ../taco9/CuiWCS13/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/MazloomMTAS12"
bash ../taco9/MazloomMTAS12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/ZhangLZCZ12"
bash ../tods37/ZhangLZCZ12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/DasuL12"
bash ../vldb12_new/DasuL12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/SchroederS12"
bash ../ccs12/SchroederS12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/SchnaitterP12"
bash ../vldb12_new/SchnaitterP12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/XekalakisIC12"
bash ../taco9/XekalakisIC12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/KanneE12"
bash ../sigmod12/KanneE12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/CuiXWYFF12"
bash ../taco9/CuiXWYFF12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/CaoCLT12"
bash ../vldb12_new/CaoCLT12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/SinghG12"
bash ../vldb12_new/SinghG12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/HongYX12"
bash ../ccs12/HongYX12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/Shirani-MehrKS12"
bash ../vldb12_new/Shirani-MehrKS12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/FeinerBG12"
bash ../asplos12/FeinerBG12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/MozafariZZ12"
bash ../sigmod12/MozafariZZ12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/ShokriTTHB12"
bash ../ccs12/ShokriTTHB12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/ButtLSG12"
bash ../ccs12/ButtLSG12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/HariANR12"
bash ../asplos12/HariANR12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/LeeKLYP13"
bash ../taco9/LeeKLYP13/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/Akinyele0HP12"
bash ../ccs12/Akinyele0HP12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/MondalD12"
bash ../sigmod12/MondalD12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/SchneiderCVY12"
bash ../tods37/SchneiderCVY12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/AlbericioIVL13"
bash ../taco9/AlbericioIVL13/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/BahmaniKV12"
bash ../vldb12_new/BahmaniKV12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/BakibayevOZ12"
bash ../vldb12_new/BakibayevOZ12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/YangWXW12"
bash ../taco9/YangWXW12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/AbiteboulBV12"
bash ../tods37/AbiteboulBV12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/NanongkaiLSM12"
bash ../sigmod12/NanongkaiLSM12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/DijkJORST12"
bash ../ccs12/DijkJORST12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/JiangBCL12"
bash ../vldb12_new/JiangBCL12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/FahlHMSBF12"
bash ../ccs12/FahlHMSBF12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/YangRW12"
bash ../tods37/YangRW12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/SowellGS12"
bash ../vldb12_new/SowellGS12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/KimGHOHPG12"
bash ../ccs12/KimGHOHPG12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/ChrysosDPD13"
bash ../taco9/ChrysosDPD13/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/ZengJZ12"
bash ../vldb12_new/ZengJZ12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/AgarwalRB12"
bash ../vldb12_new/AgarwalRB12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/SinghNJ12"
bash ../sigmod12/SinghNJ12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/ZhaoRGH12"
bash ../vldb12_new/ZhaoRGH12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/WangHLWZS12"
bash ../vldb12_new/WangHLWZS12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/YanLKW12"
bash ../ccs12/YanLKW12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/WangC12"
bash ../vldb12_new/WangC12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/RamachandraS12"
bash ../sigmod12/RamachandraS12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/RadojkovicCMVPCNV12"
bash ../asplos12/RadojkovicCMVPCNV12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/SunWWSL12"
bash ../vldb12_new/SunWWSL12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/JhaS12"
bash ../vldb12_new/JhaS12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/AntaoS13"
bash ../taco9/AntaoS13/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/BianchiSKV12"
bash ../ccs12/BianchiSKV12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/GuoPG12"
bash ../sigmod12/GuoPG12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/RohouWY13"
bash ../taco9/RohouWY13/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/KasikciZC12"
bash ../asplos12/KasikciZC12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/HuXCY12"
bash ../sigmod12/HuXCY12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/SimhaLC12"
bash ../asplos12/SimhaLC12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/DittrichQRSJS12"
bash ../vldb12_new/DittrichQRSJS12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/LiuC12"
bash ../tods37/LiuC12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/MajumdarCBCG12"
bash ../taco9/MajumdarCBCG12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/ChenS13"
bash ../taco9/ChenS13/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/FanWW12"
bash ../vldb12_new/FanWW12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/FujiwaraNOK12"
bash ../vldb12_new/FujiwaraNOK12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/BenediktBL12"
bash ../vldb12_new/BenediktBL12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/BaghdadiCVT13"
bash ../taco9/BaghdadiCVT13/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/LinWLZ12"
bash ../asplos12/LinWLZ12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/YuAY12"
bash ../sigmod12/YuAY12/es_batch_2.bash $1
sleep 5
echo "SENDING toplas34/Ben-AmramGM12"
bash ../toplas34/Ben-AmramGM12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/LiG12"
bash ../sigmod12/LiG12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/AlbutiuKN12"
bash ../vldb12_new/AlbutiuKN12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/HueskePSRBKT12"
bash ../vldb12_new/HueskePSRBKT12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/ShengZTJ12"
bash ../vldb12_new/ShengZTJ12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/GuanYK12"
bash ../vldb12_new/GuanYK12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/LymberopoulosRSMN12"
bash ../asplos12/LymberopoulosRSMN12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/ChenFETW12"
bash ../asplos12/ChenFETW12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/WangY12"
bash ../tods37/WangY12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/AmsterdamerDMT12"
bash ../tods37/AmsterdamerDMT12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/JestesPLT12"
bash ../vldb12_new/JestesPLT12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/YinCLYC12"
bash ../vldb12_new/YinCLYC12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/XiaZFCW12"
bash ../tods37/XiaZFCW12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/MouratidisY12"
bash ../vldb12_new/MouratidisY12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/PuriniJ13"
bash ../taco9/PuriniJ13/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/ArapinisMRRGRB12"
bash ../ccs12/ArapinisMRRGRB12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/GulloT12"
bash ../vldb12_new/GulloT12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/MoonLLKPK12"
bash ../ccs12/MoonLLKPK12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/JoaoSMP12"
bash ../asplos12/JoaoSMP12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/LuSCO12"
bash ../vldb12_new/LuSCO12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/ClearyCPG13"
bash ../taco9/ClearyCPG13/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/CuiYXF13"
bash ../taco9/CuiYXF13/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/TassaG12"
bash ../tods37/TassaG12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/AngelKSS12"
bash ../vldb12_new/AngelKSS12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/Mironov12"
bash ../ccs12/Mironov12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/SchuchardGTH12"
bash ../ccs12/SchuchardGTH12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/FraternaliMT12"
bash ../sigmod12/FraternaliMT12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/GiatrakosDGSS12"
bash ../sigmod12/GiatrakosDGSS12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/WangGNHB12"
bash ../ccs12/WangGNHB12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/WangKFF12"
bash ../vldb12_new/WangKFF12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/GiannikisAK12"
bash ../vldb12_new/GiannikisAK12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/KingDA12"
bash ../asplos12/KingDA12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/QinYC12"
bash ../vldb12_new/QinYC12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/CongFKLL12"
bash ../tods37/CongFKLL12/es_batch_2.bash $1
sleep 5
echo "SENDING sigmod12/ThomsonDWRSA12"
bash ../sigmod12/ThomsonDWRSA12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/ShengTL12"
bash ../tods37/ShengTL12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/PimplikarS12"
bash ../vldb12_new/PimplikarS12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/JaleelNSSE12"
bash ../asplos12/JaleelNSSE12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/ErdosILTB12"
bash ../vldb12_new/ErdosILTB12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/EyermanE12"
bash ../taco9/EyermanE12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/LimHB12"
bash ../vldb12_new/LimHB12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/OlszewskiZKAA12"
bash ../asplos12/OlszewskiZKAA12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/StrackxP12"
bash ../ccs12/StrackxP12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/CandanRSW12"
bash ../vldb12_new/CandanRSW12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/Bidoit-TolluCU12"
bash ../vldb12_new/Bidoit-TolluCU12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/MoghaddamLDG12"
bash ../ccs12/MoghaddamLDG12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/CaulfieldMEDCS12"
bash ../asplos12/CaulfieldMEDCS12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/GoodrichNOPTTL12"
bash ../vldb12_new/GoodrichNOPTTL12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/AndradeFD12"
bash ../taco9/AndradeFD12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/AlyAO12"
bash ../vldb12_new/AlyAO12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/Jacques-SilvaGWWK12"
bash ../vldb12_new/Jacques-SilvaGWWK12/es_batch_2.bash $1
sleep 5
echo "SENDING asplos12/VasicNMKB12"
bash ../asplos12/VasicNMKB12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/BlunschiJKMS12"
bash ../vldb12_new/BlunschiJKMS12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/XieDSZZ12"
bash ../tods37/XieDSZZ12/es_batch_2.bash $1
sleep 5
echo "SENDING tods37/DavidLT12"
bash ../tods37/DavidLT12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/MetwallyF12"
bash ../vldb12_new/MetwallyF12/es_batch_2.bash $1
sleep 5
echo "SENDING taco9/YanJTF13"
bash ../taco9/YanJTF13/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/ChubakR12"
bash ../vldb12_new/ChubakR12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/TerrovitisLMS12"
bash ../vldb12_new/TerrovitisLMS12/es_batch_2.bash $1
sleep 5
echo "SENDING ccs12/WartellMHL12"
bash ../ccs12/WartellMHL12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/ElghandourA12"
bash ../vldb12_new/ElghandourA12/es_batch_2.bash $1
sleep 5
echo "SENDING vldb12_new/SachanB12"
bash ../vldb12_new/SachanB12/es_batch_2.bash $1
sleep 5

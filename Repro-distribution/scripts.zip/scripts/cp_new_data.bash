#!/bin/bash
# File: cp_new_data.bash
# Author: Alex Warren
# Purpose: replaces old data.txt in the given confrences
# Usage ./addsrc.bash pldi12 ccs12
#       this will add the file and folder to each paper's directory in those conference
#OR with argument blank to run on blank confrences, as determined 5/31
# Note: this script needs to have a data.txt in the script_resources directory

#blank is defined from the status at 5/31
if [ $1 = "blank" ]; then
    arg_list="asplos12 ccs12 sigmod12 taco9 tods37 toplas34"
else
    arg_list="$@"
fi

for arg in $arg_list
do
    echo "In $arg"
    for D in `find ./../$arg -mindepth 1 -maxdepth 1 -type d`
    do
        echo "replacing data.txt in $D/"
	doi=$(sed -n -e 's/ARTICLE:LINK\[url\] //p' $D/data.txt)
        sed 's|DOI|'"$doi"'|g' ./script_resources/data.txt > $D/data.txt
        #echo $doi
        #cp ./script_resources/data.txt $D/data.txt
    done
done

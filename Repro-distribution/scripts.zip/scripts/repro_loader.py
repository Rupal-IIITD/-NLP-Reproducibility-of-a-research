# -*- coding: utf-8 -*-
"""
repro_loader
Used to load the data.txt files of a given conference into a datastructure
that allows easy counting and filtering of results. This is the backend for 
repro_status which accepts command line arguments to perform a variety of 
tasks
"""
# Author :  Alex Warren

import re
import copy
import glob
from os import path
from os import makedirs
import subprocess

import pprint
pp = pprint.PrettyPrinter(indent=4)


regex_url = re.compile(
        r'^https?://'  # http:// or https://
        r'(?:(?:[A-Z0-9](?:[A-Z0-9-]{0,61}[A-Z0-9])?\.)+[A-Z]{2,6}\.?|'  # domain...
        r'\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})' # ...or ip
        r'(?::\d+)?'  # optional port
        r'(?:/?|[/?]\S+)$', re.IGNORECASE)

#urls are complicated so allow anything
regex_url = re.compile(r'.*', re.IGNORECASE)

regex_bibtex_label = re.compile(r"[A-Z0-9]", re.IGNORECASE)

regex_name = re.compile(r"[A-Z_]", re.IGNORECASE)

regex_email = re.compile(r"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$")

class AttrDict(dict):
    """A dict that allows access through attributes"""
    def __init__(self, *args, **kwargs):
        super(AttrDict, self).__init__(*args, **kwargs)
        self.__dict__ = self


# ███████╗██╗███████╗██╗     ██████╗      ██████╗██╗      █████╗ ███████╗███████╗███████╗███████╗
# ██╔════╝██║██╔════╝██║     ██╔══██╗    ██╔════╝██║     ██╔══██╗██╔════╝██╔════╝██╔════╝██╔════╝
# █████╗  ██║█████╗  ██║     ██║  ██║    ██║     ██║     ███████║███████╗███████╗█████╗  ███████╗
# ██╔══╝  ██║██╔══╝  ██║     ██║  ██║    ██║     ██║     ██╔══██║╚════██║╚════██║██╔══╝  ╚════██║
# ██║     ██║███████╗███████╗██████╔╝    ╚██████╗███████╗██║  ██║███████║███████║███████╗███████║
# ╚═╝     ╚═╝╚══════╝╚══════╝╚═════╝      ╚═════╝╚══════╝╚═╝  ╚═╝╚══════╝╚══════╝╚══════╝╚══════╝
class ReproLoadField:
    """A generic class that can load any field based on it's type and parameters"""
    is_loaded = False
    has_value = False
    spec = ""
    value = None
    def __init__(self):
        pass

    def __repr__(self):
        if self.is_loaded:
            return "%s value:%s" % (self.__class__, repr(self.value))
        else:
            return "BLANK %s" % self.__class__

    def __str__(self):
        if self.value is not None:
            return str(self.value)
        else:
            return ""

    def copy(self):
        result = copy.copy(self)
        result.value = copy.copy(self.value)
        return result


class FieldTags(ReproLoadField):
    """Class representing a field with tags"""
    def __init__(self, list_of_tags):
        ReproLoadField.__init__(self)
        self.value = dict()
        self.list_of_tags = list_of_tags
        self.empty()
    def empty(self):
        for tag in self.list_of_tags:
            self.__dict__[tag] = False
            self.value[tag] = self.__dict__[tag]
    def load(self, entry):
        self.is_loaded = True
        tokens = entry.split()
        for token in tokens:
            try:
                if not self.__dict__[token]:
                    self.__dict__[token] = True
                    self.value[token] = self.__dict__[token]
                    self.has_value = True
                else:
                    raise ReproLoadError(None, None, None, None, "duplicate_tag %s" % token)
            except KeyError as e:
                raise ReproLoadError(None, None, None, None, "unknown_tag %s" % token)
    def __str__(self):
        return ' '.join([tag for tag in self.list_of_tags if self.value[tag]])

class FieldInt(ReproLoadField):
    """Class representing a field with an integer value"""
    def __init__(self):
        ReproLoadField.__init__(self)
    def load(self, entry):
        self.is_loaded = True
        try:
            self.value = int(entry)
            self.has_value = True
        except ValueError:
            raise ReproLoadError(None, None, None, None, "expected_int %s" % entry)
    def __str__(self):
        if self.value is None:
            return ""
        return str(self.value)

class FieldString(ReproLoadField):
    """Class representing a field with an string value"""
    def __init__(self, accepts_none):
        ReproLoadField.__init__(self)
        self.accepts_none = accepts_none
    def load(self, entry):
        self.is_loaded = True
        self.value = entry.strip()
        if self.value: self.has_value = True
        if self.accepts_none:
            if self.value == "none":
                self.none = True
                self.value = ""
                self.has_value = True
            else:
                self.none = False
    def __str__(self):
        if self.accepts_none and self.is_loaded:
            if self.none:
                return "none"
        if self.value is None:
            return ""
        return self.value


class FieldRegex(ReproLoadField):
    """Class representing a field with an string value that fits REGEX"""
    def __init__(self, regex):
        ReproLoadField.__init__(self)
        self.regex = regex
    def load(self, entry):
        self.is_loaded = True
        if self.regex.match(entry) is not None:
            self.value = entry
            self.has_value = True
        else:
            raise ReproLoadError(None, None, None, None, "failed_regex_match %s" % (entry))

class FieldRegexList(ReproLoadField):
    """Class representing a field with an string value that fits a list of REGEX"""
    def __init__(self, regex):
        ReproLoadField.__init__(self)
        self.regex = regex
    def load(self, entry):
        self.is_loaded = True
        tokens = entry.split()
        self.value = []
        for token in tokens:
            if self.regex.match(token) is not None:
                self.value.append(token)
                self.has_value = True
            else:
                raise ReproLoadError(None, None, None, None, "failed_regex_match %s" % (token))
    def __str__(self):
        if self.value:
            return ' '.join(self.value)
        return ''

class FieldLink(ReproLoadField):
    """Class representing a field with an string value that fits REGEX"""
    def __init__(self):
        ReproLoadField.__init__(self)
    def load(self, entry):
        self.is_loaded = True
        self.unknown = False
        self.none = False
        self.sent_no_url = False
        self.broken = False
        self.url = ""
        tokens = entry.split()
        if len(tokens)==0:
            self.empty = True
        elif len(tokens) == 1:
            if tokens[0] == "unknown":
                self.unknown = True
                self.has_value = True
            elif tokens[0] == "none":
                self.none = True
                self.has_value = True
            elif tokens[0] == "sent_no_url":
                self.sent_no_url = True
                self.has_value = True
            else:
                if regex_url.match(tokens[0]) is not None:
                    self.url = tokens[0]
                    self.has_value = True
                else:
                    raise ReproLoadError(None, None, None, None, "url_regex_fail %s" % (tokens[0]))
        elif len(tokens) == 2:
            if tokens[0] == "broken":
                self.broken = True
                self.has_value = True
                if not regex_url.match(tokens[1]) is None:
                    self.url = tokens[1]
                else:
                    raise ReproLoadError(None, None, None, None, "url_regex_fail %s" % (tokens[1]))
            else:
                raise ReproLoadError(None, None, None, None, "incorrect_format %s" % (entry))
        else:
            raise ReproLoadError(None, None, None, None, "incorrect_format %s" % (entry))
    def __repr__(self):
        if self.is_loaded:
            self.value = {
                'UNKNOWN':self.unknown,
                'NONE':self.none,
                'SENT_NO_URL':self.sent_no_url,
                'BROKEN':self.broken,
                'URL':self.url
                }
            return "%s value:%s" % (self.__class__, repr(self.value))
        else:
            return "BLANK %s" % self.__class__
    def __str__(self):
        if self.is_loaded:
            if self.unknown:
                return "unknown"
            if self.broken:
                return "broken " + self.url
            if self.sent_no_url:
                return "sent_no_url"
            if self.none:
                return "none"
            if self.url is not None:
                return self.url
        return ""

class BrownResponse:
    dispute = ""
    cleared = ""
    misclass = ""
    problem = ""
    def __init__(self):
        pass

# ███████╗██████╗ ██████╗  ██████╗ ██████╗ 
# ██╔════╝██╔══██╗██╔══██╗██╔═══██╗██╔══██╗
# █████╗  ██████╔╝██████╔╝██║   ██║██████╔╝
# ██╔══╝  ██╔══██╗██╔══██╗██║   ██║██╔══██╗
# ███████╗██║  ██║██║  ██║╚██████╔╝██║  ██║
# ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝
class ReproLoadError(Exception):
    """Generic error class"""
    def __init__(self, record, file_path, section, field, value):
        self.record = record
        self.file_path = file_path
        self.section = section
        self.field = field
        self.value = value
    def __repr__(self):
        return "ReproLoadError(None, %s, %s, %s, %s)" % (repr(self.file_path), 
            repr(self.section), repr(self.field), repr(self.value))
    def __eq__(self, other):
        return (self.file_path == other.file_path and self.section == other.section and 
            self.field == other.field and self.value == other.value)


# ██████╗ ███████╗ ██████╗ ██████╗ ██████╗ ██████╗     ███████╗████████╗██████╗ ██╗   ██╗ ██████╗████████╗
# ██╔══██╗██╔════╝██╔════╝██╔═══██╗██╔══██╗██╔══██╗    ██╔════╝╚══██╔══╝██╔══██╗██║   ██║██╔════╝╚══██╔══╝
# ██████╔╝█████╗  ██║     ██║   ██║██████╔╝██║  ██║    ███████╗   ██║   ██████╔╝██║   ██║██║        ██║   
# ██╔══██╗██╔══╝  ██║     ██║   ██║██╔══██╗██║  ██║    ╚════██║   ██║   ██╔══██╗██║   ██║██║        ██║   
# ██║  ██║███████╗╚██████╗╚██████╔╝██║  ██║██████╔╝    ███████║   ██║   ██║  ██║╚██████╔╝╚██████╗   ██║   
# ╚═╝  ╚═╝╚══════╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═╝╚═════╝     ╚══════╝   ╚═╝   ╚═╝  ╚═╝ ╚═════╝  ╚═════╝   ╚═╝   

#Sections
repro_record_template_article = AttrDict(
    ANALYSIS_BY=FieldTags(['Akash','Alex','Gina','Zuoming']),
    ANALYSIS_TIME=FieldInt(),
    COMMENT=FieldString(False),
    COMMERCIAL_EFFORT=FieldTags(['none','part','full']),
    GRANT_SUPPORT=FieldString(True),
    NSF_SUPPORT=FieldString(True),
    IMPLEMENTATION_EXISTS=FieldTags(['unknown', 'hardware', 'yes', 'no']),
    LINK=FieldRegex(regex_url),
    STATUS=FieldTags(['not_finished','finished']),
    TYPE=FieldTags(['conference', 'journal', 'poster', 'article', 'keynote', 'demonstration', 'abstract', 'panel']),
    PAGE_COUNT=FieldInt()
    )

repro_record_template_author = AttrDict(
    EMAIL_REAL=FieldRegexList(regex_email),
    EMAIL_ORIG=FieldString(False),
    EMAIL_PARSED=FieldString(False),
    NAMES=FieldRegexList(regex_name)
    )

repro_record_template_bibtex = AttrDict(
    LABEL=FieldRegex(regex_bibtex_label),
    LINK=FieldRegexList(regex_url)
    )

repro_record_template_build = AttrDict(
    ANALYSIS_BY=FieldTags(['Akash','Alex','Gina','Zuoming', 'David']),
    ANALYSIS_TIME=FieldInt(),
    COMMENT=FieldString(False),
    STATUS=FieldTags(['unknown', 'needed', 'not_needed', 'started', 'finished', 'downloaded', 'compiles', 'runs', 'online']),
    ERROR_COMMENT=FieldTags(['not_needed', 'DISTRIBUTION_IS_MISSING_FILES', 'UNAVAILABLE_ENVIRONMENT', 'INTERNAL_COMPILER_ERROR', 'PREREQUISITE_FAILED_TO_BUILD','INCOMPLETE_DOCUMENTATION','MISSING_THIRD_PARTY_PACKAGE','OTHER_ERRORS','RUNTIME_ERROR']),
    BENEFIT_OF_DOUBT=FieldTags(['unknown', 'yes', 'no']),
    VERIFY_BY=FieldTags(['Akash','Alex','Gina','Zuoming', 'Pruthvi', 'David', 'Patrick']),
    VERIFY_TIME=FieldInt(),
    VERIFY_COMMENT=FieldString(False),
    VERIFY_STATUS=FieldTags(['needed', 'not_needed', 'started', 'finished']),
    )
# REMARK
# "irrelevant_code"
# "commercial"
# "available_soon"
# "proprietary_academic"
# "bad_code"
# "programmer_left"
# "lost_code"
# "only_partial_code"
# "unusual_software"
# "unusual_hardware"
# "complicated_code"
# "copyright"
# "cleaning_code"
# "controlled_usage"
# "obsolete_software"
# "wrong_version"
# "student_left"
# "working_on_extention"
# "binary"
# "broken"
# "security_privacy_issues"



# ERROR_COMMENT
# 'not_needed'
# 'DISTRIBUTION_IS_MISSING_FILES'
# 'UNAVAILABLE_ENVIRONMENT'
# 'INTERNAL_COMPILER_ERROR'
# 'PREREQUISITE_FAILED_TO_BUILD'
# 'INCOMPLETE_DOCUMENTATION'
# 'MISSING_THIRD_PARTY_PACKAGE'
# 'OTHER_ERRORS'
# 'RUNTIME_ERROR'

repro_record_template_email = AttrDict(
    STATUS=FieldTags(['unknown', 'not_needed', 'not_found', 'needed', 'request_1', 'request_2', 'response_1', 'response_2', 'sent_thank_you'])
    )

repro_record_template_pi = AttrDict(
    COMMENT_CC=FieldString(False),
    COMMENT_TP=FieldString(False)
    )
repro_record_template_tool = AttrDict(
    NAME=FieldString(True),
    ARTICLE_LINK=FieldLink(),
    GOOGLE_LINK=FieldLink(),
    EMAIL_LINK=FieldLink(),
    DATA_LINK=FieldLink()
    )
repro_record_template_verify = AttrDict(
    ANALYSIS_BY=FieldTags(['Akash','Alex','Gina','Zuoming']),
    STATUS=FieldTags(['unknown', 'needed', 'not_needed', 'started', 'finished']),
    COMMENT=FieldString(False)
    )
repro_record_template_email1 = AttrDict(
    CODE_AVAILABLE=FieldTags(['yes', 'no', 'no_response']),
    REMARK=FieldTags(["irrelevant_code", "commercial", "available_soon", "proprietary_academic", 
                        "bad_code", "programmer_left", "lost_code", "only_partial_code", 
                        "unusual_software", "unusual_hardware","complicated_code","copyright",
                        "cleaning_code","controlled_usage","obsolete_software","wrong_version",
                        "student_left","working_on_extention","binary","broken","security_privacy_issues"])
    )

repro_record_template_comment = AttrDict(
    RESPONSE=FieldString(False),
    CORRECTION=FieldString(False),
    UPDATE=FieldString(False)
)

#Complete Record
repro_record_template = AttrDict(
    ARTICLE=repro_record_template_article,
    AUTHOR=repro_record_template_author,
    BIBTEX=repro_record_template_bibtex,
    BUILD=repro_record_template_build,
    EMAIL=repro_record_template_email,
    PI=repro_record_template_pi,
    TOOL=repro_record_template_tool,
    VERIFY=repro_record_template_verify,
    EMAIL1=repro_record_template_email1,
    COMMENT=repro_record_template_comment
    )

#Add [] help speciifications
repro_record_template.ARTICLE.ANALYSIS_BY.spec = "name"
repro_record_template.ARTICLE.ANALYSIS_TIME.spec = "minutes"
repro_record_template.ARTICLE.COMMENT.spec = "string" 
repro_record_template.ARTICLE.COMMERCIAL_EFFORT.spec = "none,part,full"
repro_record_template.ARTICLE.GRANT_SUPPORT.spec = "none or string"
repro_record_template.ARTICLE.NSF_SUPPORT.spec = "none or number"
repro_record_template.ARTICLE.IMPLEMENTATION_EXISTS.spec = "unknown,hardware,yes,no"
repro_record_template.ARTICLE.LINK.spec = "url"
repro_record_template.ARTICLE.STATUS.spec = "not_finished,finished"
repro_record_template.ARTICLE.TYPE.spec = "conference,journal,poster,abstract"
repro_record_template.ARTICLE.PAGE_COUNT.spec = "pages"
repro_record_template.AUTHOR.EMAIL_REAL.spec = "list of strings"
repro_record_template.AUTHOR.EMAIL_PARSED.spec = "list of strings"
repro_record_template.AUTHOR.EMAIL_ORIG.spec = "string"
repro_record_template.BIBTEX.LABEL.spec = "string"
repro_record_template.AUTHOR.NAMES.spec = "list of first_last"
repro_record_template.BIBTEX.LINK.spec = "url"
repro_record_template.BUILD.ANALYSIS_BY.spec = "name"
repro_record_template.BUILD.ANALYSIS_TIME.spec = "minutes"
repro_record_template.BUILD.COMMENT.spec = "string"
repro_record_template.BUILD.STATUS.spec = "one of {unknown,needed,not_needed,started,finished} and list of {downloaded,compiles,runs}"
repro_record_template.BUILD.ERROR_COMMENT.spec = "not_needed,comment"
repro_record_template.BUILD.BENEFIT_OF_DOUBT.spec = "unknown,yes,no"
repro_record_template.BUILD.VERIFY_BY.spec = "name"
repro_record_template.BUILD.VERIFY_TIME.spec = "minutes"
repro_record_template.BUILD.VERIFY_COMMENT.spec = "string"
repro_record_template.BUILD.VERIFY_STATUS.spec = "needed,not_needed,started,finished"
repro_record_template.EMAIL.STATUS.spec = "unknown,not_needed,not_found or list of {needed,request_1,response_1,sent_thank_you}"
repro_record_template.PI.COMMENT_CC.spec = "string"
repro_record_template.PI.COMMENT_TP.spec = "string"
repro_record_template.TOOL.NAME.spec = "string"
repro_record_template.TOOL.ARTICLE_LINK.spec = "unknown,none,url,broken and url"
repro_record_template.TOOL.GOOGLE_LINK.spec = "unknown,none,url,broken and url"
repro_record_template.TOOL.EMAIL_LINK.spec = "unknown,none,sent_no_url,url,broken and url"
repro_record_template.TOOL.DATA_LINK.spec = "unknown,none,url,broken and url"
repro_record_template.VERIFY.ANALYSIS_BY.spec = "name"
repro_record_template.VERIFY.STATUS.spec = "unknown,needed,not_needed,started,finished"
repro_record_template.VERIFY.COMMENT.spec = "string"
repro_record_template.EMAIL1.CODE_AVAILABLE.spec = "yes,no,no_response"
repro_record_template.EMAIL1.REMARK.spec = "comment"

repro_survey_summary_template_list = {
    "CLASSIFICATION":FieldTags(["practical", "theoretical", "hardware"]),
    "PUBLISHED_CODE":FieldTags(["not_applicable", "yes", "no"]),
    "SAME_VERSION":FieldTags(["not_applicable", "yes", "no_but_available", "no_and_not_available"]),
    "STUDY_FOUND_CORRECT_CODE":FieldTags(["not_applicable", "yes", "no"]),
    "CORRECT_CODE_LOCATION":FieldString(False),
    #"BUILD_DIFFICULTY":FieldTags(["reasonable_effort", "code_problematic", "other"]),
    "BUILD_DIFFICULTY":FieldString(False),
}

repro_survey_summary_template = AttrDict(**repro_survey_summary_template_list)

repro_survey_template = AttrDict(
    EMAIL=FieldRegexList(regex_email),
    UNIQUE_ID=FieldString(False),
    CLASSIFICATION_COMMENT=FieldString(False),  #if classification diff tell us
    SAME_VERSION_COMMENT=FieldString(False),
    BUILD_DIFFICULTY_COMMENT=FieldString(False), #other
    BUILD_COMMENT=FieldString(False),
    PUBLIC_COMMENT=FieldString(False),
    ANONYMOUS_COMMENT=FieldString(False),
    **repro_survey_summary_template_list
    )

repro_survey_template.EMAIL.spec = "string"
repro_survey_template.UNIQUE_ID.spec = "string"
repro_survey_template.CLASSIFICATION.spec = "practical,theoretical,hardware"
repro_survey_template.CLASSIFICATION_COMMENT.spec = "string"
repro_survey_template.PUBLISHED_CODE.spec = "not_applicable, yes, no"
repro_survey_template.SAME_VERSION.spec = "not_applicable, yes, no_but_available, no_and_not_available"
repro_survey_template.SAME_VERSION_COMMENT.spec = "string"
repro_survey_template.STUDY_FOUND_CORRECT_CODE.spec = "not_applicable, yes, no"
repro_survey_template.CORRECT_CODE_LOCATION.spec = "string"
repro_survey_template.BUILD_DIFFICULTY.spec = "not_applicable, reasonable_effort, code_problematic or string"
repro_survey_template.BUILD_DIFFICULTY_COMMENT.spec = "string"
repro_survey_template.BUILD_COMMENT.spec = "string"
repro_survey_template.PUBLIC_COMMENT.spec = "string"
repro_survey_template.ANONYMOUS_COMMENT.spec = "string"
repro_record_template_comment.RESPONSE.spec = "string"
repro_record_template_comment.CORRECTION.spec = "string"
repro_record_template_comment.UPDATE.spec = "string"

ALL_CONFERENCES = ["asplos12", "ccs12", "oopsla12", "osdi12",
                "pldi12", "sigmod12", "sosp11", "vldb12"]
ALL_JOURNALS = ["taco9", "tissec15", "tocs30", "tods37", 
                   "toplas34"]


def make_blank_record():
    blank = AttrDict()
    for section_key, section_value in repro_record_template.items():
        blank_section = AttrDict()
        for field_key, field_value in section_value.items():
            blank_section[field_key] = field_value.copy()
            #pp.pprint(field_value.spec)
            #blank_section[field_key].spec = 
        blank[section_key] = blank_section
    return blank

def make_blank_survey():
    blank = AttrDict()
    for field_key, field_value in repro_survey_template.items():
        blank[field_key] = field_value.copy()
    return blank

def make_blank_survey_summary():
    blank = AttrDict()
    for field_key, field_value in repro_survey_summary_template.items():
        blank[field_key] = field_value.copy()
    return blank



# ██████╗  █████╗ ████████╗ █████╗ ██████╗  █████╗ ███████╗███████╗
# ██╔══██╗██╔══██╗╚══██╔══╝██╔══██╗██╔══██╗██╔══██╗██╔════╝██╔════╝
# ██║  ██║███████║   ██║   ███████║██████╔╝███████║███████╗█████╗  
# ██║  ██║██╔══██║   ██║   ██╔══██║██╔══██╗██╔══██║╚════██║██╔══╝  
# ██████╔╝██║  ██║   ██║   ██║  ██║██████╔╝██║  ██║███████║███████╗
# ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝
class repro_database:
    """
    Singleton class for access to the repro database. 
    Includes functions for checking errors and clearing false positives
    """
    all_conference_titles = ["asplos12", "ccs12", "oopsla12", "osdi12",
                    "pldi12", "sigmod12", "sosp11", "taco9", "tissec15", "tocs30",
                    "tods37", "toplas34", "vldb12", "vldb12_new"]
    batch1_conference_titles = ["oopsla12", "osdi12", "pldi12", 
                    "sosp11", "tissec15", "tocs30", "vldb12"]
    batch2_conference_titles = ["asplos12", "ccs12", "sigmod12", 
                    "taco9", "tods37", "toplas34", "vldb12_new"]
    batch3_papers = ["LeeS12","MartignoniMPSM12","CzeskisDKWB12","DamGL12",
                     "Zhang0LZMY12","BelviranliBG13","CoppensSM13","MavrogiannopoulosVVP12",
                     "DioufHCOP13","ShengTL12","KangLM12"]
    removed_conference_titles = [path.join("removed_papers","ccs12"),
                                 path.join("removed_papers","oopsla12"),
                                 path.join("removed_papers","sigmod12"),
                                 path.join("removed_papers","vldb12_new")]
    def __init__(self, repro_root, conferences, 
                 verbose=False, diff_validate=False, normalize=False, 
                 load_brown=False):
        """Loads the repro database"""
        self.verbose = verbose
        self.repro_root = repro_root
        self.errors = []
        self.conferences = AttrDict()
        self.conference_lists = {}
        self.records = []
        if len(conferences) == 1:
            if conferences[0] == "all":
                conferences = self.all_conference_titles
            if conferences[0] == "batch1":
                conferences = self.batch1_conference_titles
            if conferences[0] == "batch2":
                conferences = self.batch2_conference_titles
            if conferences[0] == "removed":
                conferences = self.removed_conference_titles
        for conf in conferences:
            conf_record_files = glob.glob(path.join(repro_root, conf,"*","data.txt"))
            #keep track of which email batch
            if conf in self.batch1_conference_titles:
                batch = 1
            else:
                batch = 2
            #merge vldb12_new into vldb
            if conf ==  "vldb12_new":
                print "Note: vldb12_new added as vldb12"
                conf = "vldb12"
            #this will allow vldb12_new to be combined with vldb12
            #however has the side effect of allowing some conference to be counted twice
            if not conf in self.conferences:
                #Seperate ways to access the records
                self.conferences[conf] = AttrDict()
                self.conference_lists[conf] = []

            if len(conf_record_files)==0:
                print("EMPTY CONFERENCE: %s" % conf)
            for conf_record_file_path in conf_record_files:
                #create a new record
                current_record = make_blank_record()
                bibtex_label = path.split(path.dirname(conf_record_file_path))[1]
                self.conferences[conf][bibtex_label] = current_record
                self.conference_lists[conf].append(current_record)
                self.records.append(current_record)
                current_record.path = conf_record_file_path
                current_record.dir = path.join(*path.split(conf_record_file_path)[0:-1])
                current_record.batch = batch
                current_record.conf = conf
                if bibtex_label in self.batch3_papers:
                    current_record.batch = 3
                
                with open(conf_record_file_path, 'rb') as conf_record_file:
                    raw_record = self.loadDataFile(current_record, conf_record_file)

                if not normalize:
                    current_record.surveys = []
                    current_record.survey_summary = None
                    survey_filename = path.join(current_record.dir, "survey.txt")
                    try:
                        with open(survey_filename, 'rb') as survey_file:
                            self.loadSurveyFile(current_record, survey_file)
                    except IOError as e:
                        pass

                if diff_validate:
                    #Write raw record and data structure for varification diff
                    #self.normalizeLogic(current_record)
                    print "Validate output: %s" % current_record.path
                    out_dir = path.join(repro_root, "py_verify", conf+'_'+bibtex_label)
                    if not path.isdir(out_dir):
                        makedirs(out_dir)
                    header = "AA  ----------\nAB  "+conf+'_'+bibtex_label+"\n"
                    fp_out = open(path.join(out_dir, "raw.txt"),'w')
                    fp_out.write(header+raw_record)
                    fp_out = open(path.join(out_dir, "py_version.txt"),'w')
                    fp_out.write(header+self.printRecord(current_record))
                if normalize:
                    #self.renormalizeArticleType(current_record)
                    fp_out = open(current_record.path, 'w')
                    fp_out.write(self.printRecord(current_record))
                    fp_out.close()
        if load_brown:
            self.loadBrown()
        self.clearNormalLoadErrors()
        self.checkLogicErrors()
        self.clearKnownErrors()
        self.sortErrors()

    def loadSurveyFile(self, current_record, survey_file):
        for line in survey_file:
            if not line.strip():
                print "EMPTY LINE at %s" % current_record.path
                continue
            _, _, remainder = line.partition(':')
            section, _, remainder = remainder.partition(':')
            field, _, remainder = remainder.partition('[')
            _, _, values = remainder.partition(']')
            # print section
            # print field
            # print values
            if section == "SUMMARY":
                if not current_record.survey_summary:
                    current_record.survey_summary = make_blank_survey_summary()
                current_record.survey_summary[field].load(values)
            else:
                index = int(section[-1]) - 1
                if len(current_record.surveys) == index:
                    current_record.surveys.append( make_blank_survey())
                current_record.surveys[index][field].load(values)

    def loadDataFile(self, current_record, conf_record_file):
        raw_record = ""
        for line in conf_record_file:
            raw_record += line
            if not line.strip():
                print "EMPTY LINE at %s" % current_record.path
                continue
            section, _, remainder = line.partition(':')
            field, _, remainder = remainder.partition('[')
            _, _, values = remainder.partition(']')
            values = values.strip()
            section = section.strip()
            #Check if the section exists and get it
            try:
                section_check = current_record[section]
            except KeyError as e:
                self.errors.append(ReproLoadError(current_record, conf_record_file, section, field, "unknown_section"))
                continue
            #If the field exists, attempt to load it
            try:
                #print "%s:%s ->%s" % (section,field,values)
                if not section_check[field].is_loaded:
                    section_check[field].load(values)
                else:
                    self.errors.append(ReproLoadError(current_record, conf_record_file, section, field, "duplicate_field"))
            except KeyError as e:
                self.errors.append(ReproLoadError(current_record, conf_record_file, section, field, "unknown_field"))
            except ReproLoadError as e:
                e.record = current_record
                e.file_path = conf_record_file.name
                e.section = section
                e.field = field
                self.errors.append(e)
        return raw_record

    def loadBrown(self):
        brown_repo_path = path.join(self.repro_root, "brown_repo_response", "data")
        if not path.isdir(brown_repo_path):
            print "Can't load Brown repository."
            print "Update submodule or clone repository in repro root:"
            print "git clone https://github.com/shriram/repro-in-cs.git brown_repo_response"
            return
        for r in self.records:
            r.br = BrownResponse()
            rdir = r.dir.replace('_', '')
            dispute_path = path.join(brown_repo_path, rdir, "dispute.txt")
            cleared_path = path.join(brown_repo_path, rdir, "cleared.txt")
            problem_path = path.join(brown_repo_path, rdir, "problem.txt")
            misclass_path = path.join(brown_repo_path, rdir, "misclass.txt")
            if path.exists(dispute_path):
                f = open(dispute_path, 'r')
                r.br.dispute = f.read()
            if path.exists(cleared_path):
                f = open(cleared_path, 'r')
                r.br.cleared = f.read()
            if path.exists(problem_path):
                f = open(problem_path, 'r')
                r.br.problem = f.read()
            if path.exists(misclass_path):
                f = open(misclass_path, 'r')
                r.br.misclass = f.read()

    def loadPdfInfo(self, record):
        pdf_path = path.join(record.dir, "paper.pdf")
        p = subprocess.Popen(" ".join(["pdftk", pdf_path, "dumpdata"]), shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        for line in p.stdout.readlines():
            if "NumberOfPages:" in line:
                record.number_of_pages = int(line.split()[1])
                print record.number_of_pages
                p.terminate()
                break

    def normalizeArticleType(self, record):
        self.loadPdfInfo(record)
        if record.conf in ALL_CONFERENCES:
            record.ARTICLE.TYPE.load("conference")
        elif record.conf in ALL_JOURNALS:
            record.ARTICLE.TYPE.load("journal")
        else:
            print "UNKNOWN venue %s" % record.conf
        record.ARTICLE.TYPE.load("article")

        record.ARTICLE.PAGE_COUNT.load(record.number_of_pages)

    def renormalizeArticleType(self, record):
        record.ARTICLE.TYPE.value['article'] = False
        print record.ARTICLE.TYPE.value
        if record.ARTICLE.TYPE.poster or record.ARTICLE.TYPE.abstract:
            record.ARTICLE.TYPE.value['conference'] = False


    def normalizeLogicErrorComment(self, record):
        if not record.ARTICLE.IMPLEMENTATION_EXISTS.yes:
            record.BUILD.STATUS.empty()
            record.BUILD.STATUS.load("not_needed")
        if record.BUILD.STATUS.finished and record.BUILD.STATUS.runs:
            record.BUILD.ERROR_COMMENT.empty()
            record.BUILD.ERROR_COMMENT.load("not_needed")
        if record.BUILD.STATUS.not_needed:
            record.BUILD.ERROR_COMMENT.empty()
            record.BUILD.ERROR_COMMENT.load("not_needed")


    def normalizeLogicBuildVerification(self,record):
        if not record.BUILD.BENEFIT_OF_DOUBT.has_value:
            record.BUILD.BENEFIT_OF_DOUBT.load("unknown")
        if not record.BUILD.VERIFY_STATUS.has_value:
            if record.BUILD.STATUS.finished and not record.BUILD.STATUS.compiles:
                record.BUILD.VERIFY_STATUS.load("needed")
            else:
                record.BUILD.VERIFY_STATUS.load("not_needed")

    def sortErrors(self):
        print "\n".join([repr(x) for x in self.errors])
        getKey = lambda x: x.file_path+x.section+x.field
        self.errors.sort(key=getKey)

    def clearNormalLoadErrors(self):
        self.errors = [x for x in self.errors if not self.isNormalLoadError(x)]

    def isNormalLoadError(self, error):
        if error.section == "BUILD" and error.value == "expected_int ":
            if self.verbose: print("Ingore missing build time error: %s" % repr(error))
            return True
        if error.record.ARTICLE.STATUS.not_finished or not error.record.ARTICLE.STATUS.finished:
            if self.verbose: print("Ignore blank record error %s" % repr(error))
            return True
        if error.section == "ARTICLE" and error.field == "LINK" and error.value.rfind("failed_regex_match")>=0:
            if self.verbose: print("Ignore link regex fail error %s" % repr(error))
            return True
        return False

    #known_errors = [ReproLoadError(None, '../oopsla12/KaliberaMJV12/data.txt', 'TOOL', 'ARTICLE_LINK', 'url_regex_fail www.cs.kent.ac.uk/projects/gc/dacapo'),
    #ReproLoadError(None, '../vldb12/FakasCM11/data.txt', 'TOOL', 'GOOGLE_LINK', 'url_regex_fail http:\\\\mudfoot.doc.stu.mmu.ac.uk/research/ksdbos/index.html')]

    #Some hardware builds were sent emails but we decided not to count hardware regarding reporducibility
    known_errors = [ReproLoadError(None, './asplos12/JoaoSMP12/data.txt', 'EMAIL', 'STATUS', 'theoretical_should_not_need_email'),
                    ReproLoadError(None, './taco9/GeraciS12/data.txt', 'EMAIL', 'STATUS', 'theoretical_should_not_need_email')]

    def clearKnownErrors(self):
        self.errors = [x for x in self.errors if not self.isKnownError(x)]

    def isKnownError(self, error):
        for known_error in self.known_errors:
            if known_error == error:
                return True
        return False

    def checkLogicErrors(self):
        for record in self.records:
            self.checkBuildOrder(record)
            self.checkAnalysisFinished(record)
            self.CheckVerificationFinished(record)
            self.CheckVerificationFinished(record)
            self.CheckBuildFinished(record)
            self.CheckEmailLogic(record)
            self.CheckOneSource(record)
            self.CheckBuildVerification(record)

    def CheckBuildVerification(self, record):
        if record.BUILD.VERIFY_STATUS.finished:
            if not record.BUILD.VERIFY_BY.has_value:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "VERIFY_BY", "finished_expected_name"))
            if not record.BUILD.VERIFY_TIME.has_value:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "VERIFY_TIME", "finished_missing_time"))


    def checkBuildOrder(self, record):
        if record.BUILD.STATUS.online:
            if record.BUILD.STATUS.compiles or record.BUILD.STATUS.downloaded:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "STATUS", "online_has_compile_or_download"))
        else:
            if record.BUILD.STATUS.compiles and not record.BUILD.STATUS.downloaded:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "STATUS", "missing_prereq"))
            if record.BUILD.STATUS.finished and not record.BUILD.STATUS.downloaded:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "STATUS", "finished_expected_download"))
            if record.BUILD.STATUS.runs:
                if not record.BUILD.STATUS.compiles or not record.BUILD.STATUS.downloaded:
                    self.errors.append(ReproLoadError(record, record.path, "BUILD", "STATUS", "missing_prereq"))
                    return

    def checkAnalysisFinished(self, record):
        errors = []
        if record.ARTICLE.STATUS.finished:
            check_list = ["ANALYSIS_BY", "ANALYSIS_TIME", "COMMERCIAL_EFFORT", "GRANT_SUPPORT",
                            "NSF_SUPPORT", "IMPLEMENTATION_EXISTS", "LINK"]
            for field in check_list:
                if not record.ARTICLE[field].has_value:
                    errors.append(ReproLoadError(record, record.path, "ARTICLE", field, "finished_expected_value"))
            if not record.AUTHOR.EMAIL_REAL.has_value:
                errors.append(ReproLoadError(record, record.path, "AUTHOR", "EMAIL_REAL", "finished_expected_value"))
            if not record.AUTHOR.NAMES.has_value:
                errors.append(ReproLoadError(record, record.path, "AUTHOR", "NAMES", "finished_expected_value"))
            if not record.BIBTEX.LABEL.has_value:
                errors.append(ReproLoadError(record, record.path, "BIBTEX", "LABEL", "finished_expected_value"))
            if not record.BIBTEX.LINK.has_value:
                if not "osdi12" in record.path: 
                    errors.append(ReproLoadError(record, record.path, "BIBTEX", "LINK", "finished_expected_value"))
            if not record.TOOL.ARTICLE_LINK.has_value:
                errors.append(ReproLoadError(record, record.path, "TOOL", "ARTICLE_LINK", "finished_expected_value"))
            if record.TOOL.ARTICLE_LINK.none:
                if not record.TOOL.GOOGLE_LINK.has_value:
                    errors.append(ReproLoadError(record, record.path, "TOOL", "GOOGLE_LINK", "finished_expected_value"))
        self.errors.extend(errors)

    def CheckVerificationFinished(self, record):
        if record.VERIFY.STATUS.finished:
            if not record.VERIFY.ANALYSIS_BY.has_value:
                errors.append(ReproLoadError(record, record.path, "VERIFY", "ANALYSIS_BY", "missing_verification_name"))

    def CheckBuildFinished(self, record):
        if record.BUILD.STATUS.finished:
            if not record.BUILD.ANALYSIS_BY.has_value:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "ANALYSIS_BY", "finished_expected_name"))
            if not record.BUILD.ANALYSIS_TIME.has_value:
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "ANALYSIS_TIME", "finished_missing_time"))
            if not hasCode(record):
                self.errors.append(ReproLoadError(record, record.path, "BUILD", "STATUS", "finished_but_not_avaiable"))

    def CheckEmailLogic(self, record):
        if not (record.ARTICLE.IMPLEMENTATION_EXISTS.hardware and record.EMAIL.STATUS.needed):
            if not record.ARTICLE.IMPLEMENTATION_EXISTS.yes:
                return
        if record.EMAIL1.CODE_AVAILABLE.yes+record.EMAIL1.CODE_AVAILABLE.no+record.EMAIL1.CODE_AVAILABLE.no_response > 1:
            self.errors.append(ReproLoadError(record, record.path,
                    "EMAIL1", "CODE_AVAILABLE", "multiple_values"))
        if record.EMAIL1.CODE_AVAILABLE.yes or record.EMAIL1.CODE_AVAILABLE.no or record.EMAIL1.CODE_AVAILABLE.no_response:
            if not record.EMAIL.STATUS.request_1:
                self.errors.append(ReproLoadError(record, record.path,
                            "EMAIL", "STATUS", "has_results_expected_request"))
            if not record.EMAIL.STATUS.response_1 and not record.EMAIL1.CODE_AVAILABLE.no_response:
                self.errors.append(ReproLoadError(record, record.path,
                            "EMAIL", "STATUS", "has_results_expected_response"))
        #email not needed if no implementation
        if not (record.ARTICLE.IMPLEMENTATION_EXISTS.yes):
            if not record.EMAIL.STATUS.not_needed:
                self.errors.append(ReproLoadError(record, record.path,
                            "EMAIL", "STATUS", "theoretical_should_not_need_email"))
        #Email isn't needed if we have a link from google or article
        if hasGoogleLink(record) or hasArticleLink(record):
            if not record.EMAIL.STATUS.not_needed:
                self.errors.append(ReproLoadError(record, record.path,
                            "EMAIL", "STATUS", "found_link_should_not_need_email"))
        else: #doesn't have google or article link
            #then it should be needed
            if not record.EMAIL.STATUS.needed:
                self.errors.append(ReproLoadError(record, record.path,
                                "EMAIL", "STATUS", "email_should_be_needed"))
            else: #it is needed
                if record.EMAIL.STATUS.request_1 or record.EMAIL.STATUS.response_1:
                    if not record.EMAIL1.CODE_AVAILABLE.has_value:
                        self.errors.append(ReproLoadError(record, record.path,
                                "EMAIL1", "CODE_AVAILABLE", "expected_email_result"))
        #
        if record.EMAIL.STATUS.response_1 and record.EMAIL1.CODE_AVAILABLE.no_response:
            self.errors.append(ReproLoadError(record, record.path,
                            "EMAIL1", "CODE_AVAILABLE", "both_response_and_no_response"))

    def CheckOneSource(self, record):
        if (hasArticleLink(record) + hasGoogleLink(record) + record.EMAIL1.CODE_AVAILABLE.yes)>1:
            self.errors.append(ReproLoadError(record, record.path,
                            "", "", "multiple_code_sources"))

    def printRecord(self, record):
        #print record.path
        result = []
        for section_name, fields in record.__dict__.items():
            try:
                for field_name, field in fields.__dict__.items():
                    #print("%s:%s %s\n" % (section_name, field_name, str(field)))
                    #don't include EMAIL ORIG and PARSED if they are removed
                    if not (section_name == "AUTHOR" and 
                            (field_name == "EMAIL_ORIG" or field_name == "EMAIL_PARSED") and 
                            field.value is None):

                        result.append("%s:%s[%s] %s\n" % (section_name, field_name, field.spec, str(field)))
            except AttributeError as e:
                #pp.pprint(e)
                #not all attributes are fields
                continue
        result.sort()
        result = ''.join(result)
        #print result
        return result

    def printSurvey(self, record):
        #print record.path
        result = []
        for ii, survey in enumerate(record.surveys):
            for field_name, field in survey.__dict__.items():
                try:
                    section_name = "AUTHOR{}".format(ii+1)
                    result.append("SURVEY:%s:%s[%s] %s\n" % (section_name, field_name, field.spec, str(field)))
                except AttributeError as e:
                    #pp.pprint(e)
                    #not all attributes are fields
                    continue
        summary_result = []
        for field_name, field in record.survey_summary.__dict__.items():
            try:
                summary_result.append("SURVEY:SUMMARY:%s[%s] %s\n" % (field_name, field.spec, str(field)))
            except AttributeError as e:
                continue
        summary_result.sort()
        result.sort()
        summary_result.extend(result)
        result = ''.join(summary_result)
        #print result
        return result        


# ██╗      █████╗ ███╗   ███╗██████╗ ██████╗  █████╗     ███████╗██╗██╗  ████████╗███████╗██████╗ ███████╗
# ██║     ██╔══██╗████╗ ████║██╔══██╗██╔══██╗██╔══██╗    ██╔════╝██║██║  ╚══██╔══╝██╔════╝██╔══██╗██╔════╝
# ██║     ███████║██╔████╔██║██████╔╝██║  ██║███████║    █████╗  ██║██║     ██║   █████╗  ██████╔╝███████╗
# ██║     ██╔══██║██║╚██╔╝██║██╔══██╗██║  ██║██╔══██║    ██╔══╝  ██║██║     ██║   ██╔══╝  ██╔══██╗╚════██║
# ███████╗██║  ██║██║ ╚═╝ ██║██████╔╝██████╔╝██║  ██║    ██║     ██║███████╗██║   ███████╗██║  ██║███████║
# ╚══════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═════╝ ╚═════╝ ╚═╝  ╚═╝    ╚═╝     ╚═╝╚══════╝╚═╝   ╚══════╝╚═╝  ╚═╝╚══════╝

def filterCount(func, records):
    sum = 0
    for record in records:
        if func(record):
            sum += 1
    return sum

isFinishedValidated = lambda x: x.ARTICLE.STATUS.finished and x.VERIFY.STATUS.finished
hasImplementation = lambda x: x.ARTICLE.IMPLEMENTATION_EXISTS.yes
hasImplementationOrHardware = lambda x: x.ARTICLE.IMPLEMENTATION_EXISTS.yes or x.ARTICLE.IMPLEMENTATION_EXISTS.hardware
hasHardware = lambda x: x.ARTICLE.IMPLEMENTATION_EXISTS.hardware
hasArticleLink = lambda x: bool(x.TOOL.ARTICLE_LINK.url and not x.TOOL.ARTICLE_LINK.broken)
hasGoogleLink = lambda x: bool(x.TOOL.GOOGLE_LINK.url and not x.TOOL.GOOGLE_LINK.broken)
hasEmailLink = lambda x: bool(x.TOOL.EMAIL_LINK.url and not x.TOOL.EMAIL_LINK.broken)
hasWorkingLink = lambda x: hasArticleLink(x) or hasGoogleLink(x) or hasEmailLink(x) or x.EMAIL1.CODE_AVAILABLE.yes
hasBrokenLink = lambda x: x.TOOL.ARTICLE_LINK.broken or x.TOOL.GOOGLE_LINK.broken
hasCode = lambda x: hasWorkingLink(x) or x.EMAIL1.CODE_AVAILABLE.yes

isBuildFinished = lambda x: x.BUILD.STATUS.finished
isBuildStarted = lambda x: x.BUILD.STATUS.started
hasBuildNotNeeded = lambda x: x.BUILD.STATUS.not_needed
hasBuildUnknown = lambda x: x.BUILD.STATUS.unknown
hasBuildTodo = lambda x: (hasEmail1Yes(x) or hasWorkingLink(x)) and not x.BUILD.STATUS.finished
hasBuildDownloaded = lambda x: x.BUILD.STATUS.downloaded
hasBuildCompiles = lambda x: x.BUILD.STATUS.compiles
hasBuildRuns = lambda x: x.BUILD.STATUS.runs
hasBuildBlank = lambda x: not x.BUILD.STATUS.has_value
hasBuildOnlineRuns = lambda x: x.BUILD.STATUS.online and x.BUILD.STATUS.runs
hasBuildOnlineNoRuns = lambda x: x.BUILD.STATUS.online and not x.BUILD.STATUS.runs

hasBuildVerifiedNeeded = lambda x: x.BUILD.VERIFY_STATUS.needed
hasBuildVerifiedFinished = lambda x: x.BUILD.VERIFY_STATUS.finished
hasBuildVerifiedUnresolved = lambda x: not x.BUILD.VERIFY_STATUS.not_needed and not x.BUILD.VERIFY_STATUS.finished

#survey_summary
wasSentSurvey = lambda x: x.EMAIL.STATUS.not_needed or (x.EMAIL.STATUS.needed and x.EMAIL.STATUS.request_1)
hasSurveyResult = lambda x: bool(x.survey_summary)
hasSurveyBuildReasonable = lambda x: hasSurveyResult(x) and x.survey_summary.BUILD_DIFFICULTY.value == "reasonable_effort"
hasSurveyBuildReasonableOrNa = lambda x: hasSurveyResult(x) and( x.survey_summary.BUILD_DIFFICULTY.value == "reasonable_effort" or x.survey_summary.BUILD_DIFFICULTY.value == "not_applicable")

hasSurveyCodeExists = lambda x:  hasSurveyResult(x) and x.survey_summary.CLASSIFICATION.practical

hasSurveyPublishedYes = lambda x: hasSurveyResult(x) and x.survey_summary.PUBLISHED_CODE.yes
hasSurveyPublishedNo = lambda x: hasSurveyResult(x) and x.survey_summary.PUBLISHED_CODE.no

hasSurverVersionResponse = lambda x: hasSurveyResult(x) and not x.survey_summary.SAME_VERSION.not_applicable
hasSurveyCorrectVersionPublished = lambda x: hasSurveyResult(x) and x.survey_summary.SAME_VERSION.yes 
hasSurveyCorrectVersionUnpublished = lambda x: hasSurveyResult(x) and  x.survey_summary.SAME_VERSION.no_but_available
hasSurveyCorrectVersionNonextant = lambda x: hasSurveyResult(x) and  x.survey_summary.SAME_VERSION.no_and_not_available
hasSurveyCorrectVersionExists = lambda x: hasSurveyResult(x) and (x.survey_summary.SAME_VERSION.yes or x.survey_summary.SAME_VERSION.no_but_available)

hasBuildWeFailCompileAuthorSaysCompiles = lambda x: hasSurveyResult(x) and not x.BUILD.STATUS.compiles and hasSurveyBuildReasonable(x)
hasBuildWeFailCompileAuthorSaysCompilesOrNa = lambda x: hasSurveyResult(x) and not x.BUILD.STATUS.compiles and hasSurveyBuildReasonableOrNa(x)
hasBuildWeOrAuthorCompileAndCorrectVersionExists = lambda x: (x.BUILD.STATUS.compiles or hasSurveyBuildReasonable(x)) and hasSurveyCorrectVersionExists(x)
isBatch1 = lambda x: x.batch == 1
isBatch2 = lambda x: x.batch == 2
isBatch3 = lambda x: x.batch == 3
hasEmailNeeded = lambda x: x.EMAIL.STATUS.needed
hasEmailRequest1 = lambda x: x.EMAIL.STATUS.request_1
hasEmailNeededNoRequest = lambda x: x.EMAIL.STATUS.needed and not x.EMAIL.STATUS.request_1
hasEmailResponse1 = lambda x: x.EMAIL.STATUS.response_1
hasEmailThank = lambda x: x.EMAIL.STATUS.sent_thank_you
hasEmail1Yes = lambda x: x.EMAIL1.CODE_AVAILABLE.yes
hasEmail1No = lambda x: x.EMAIL1.CODE_AVAILABLE.no
hasEmail1NoResponse = lambda x: x.EMAIL1.CODE_AVAILABLE.no_response
hasEmailBuildFinished = lambda x: x.EMAIL1.CODE_AVAILABLE.yes and x.BUILD.STATUS.finished

hasNoCommercialEffort = lambda x: x.ARTICLE.COMMERCIAL_EFFORT.none
hasPartCommercialEffort = lambda x: x.ARTICLE.COMMERCIAL_EFFORT.part
hasFullCommercialEffort = lambda x: x.ARTICLE.COMMERCIAL_EFFORT.full

hasNSFGrant = lambda x: not x.ARTICLE.NSF_SUPPORT.none
hasNoNSFGrant = lambda x: x.ARTICLE.NSF_SUPPORT.none

hasEmailAddress = lambda x: len(x.AUTHOR.EMAIL_REAL.value) != 0




if __name__ == "__main__":
    print "---------------"
    print "Use repro_status for more options, loader should be used with command line"
    print "ex$ python repro_status.py -h"
    print "---------------"
    database = repro_database("..", ["all",])

    pp.pprint(database.errors)

    finished_validated_records = filter(isFinishedValidated, database.records)
    print "all papers: %s" % len(database.records)
    print "finished and validated: %s" % len(finished_validated_records)
        

#!/bin/bash
# File:              insert_space_after_field.bash
# Author:      Alex Warren
# Purpose:   find places where the space is missing after the ] and add a space
# Usage      bash  insert_space_after_field.bash pldi12 ccs12
#                     bash  insert_space_after_field.bash all
#                         to use on each conference
#
#check for possible issues with: 
#grep '].*]\w' ./*/*/data.txt

if [ $1 = "all" ]; then
    arg_list="asplos12 ccs12 oopsla12 osdi12 pldi12 sigmod12 sosp11 taco9 tissec15 tocs30 tods37 toplas34 vldb12"
else
    arg_list="$@"
fi

for arg in $arg_list
do
    echo "In $arg"
    for D in `find ./../$arg -mindepth 1 -maxdepth 1 -type d`
    do
        #echo "Checking $D/"
        #java -jar Debug $D/data.txt
        sed -i '/\]\w/s/\]/\] /g' $D/data.txt
    done
done

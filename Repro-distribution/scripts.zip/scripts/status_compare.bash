log_files=$(find ../logs/ -name "status*")
logs=$(cat $log_files)
echo "$logs" | grep -m 1 ^CL
echo "$logs" | grep ^CR - | sort -k 2,2 -k 1,1 
echo "$logs" | grep ^CT - | sort -k 2,2 -k 1,1 
echo "$logs" | grep -m 1 ^WL
echo "$logs" | grep ^WR - | sort -k 2,2 -k 1,1 

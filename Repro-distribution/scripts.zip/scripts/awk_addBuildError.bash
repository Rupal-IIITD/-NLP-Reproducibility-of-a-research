#!/bin/bash 

#File:		awk_Refactor.bash
#Author:	Akash Shankaran
#Purpose:	Formats the data.txt -
#		1. add BUILD:ERROR_COMMENT[none,not_needed,comment]
#Usage:		sudo bash ./awk_addBuildError.bash convert_list 


#run AWK script
if [ "$1" = "convert_list" ]; then
    arg_list="oopsla12 pldi12 vldb12 osdi12 tods37 toplas34 asplos12 ccs12 sigmod12 taco9 sosp11 tocs30 tissec15 vldb12_new "
else
    arg_list="$@"
fi

for arg in $arg_list
do
	tput setaf 5
	echo "In $arg"
	tput setaf 7
	directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
	
	for D in $directories; do
		tput setaf 4
		echo "Refactoring $D/data.txt"
		tput setaf 7

		#create a new file
		touch $D/data.txt.new

awk -W source '{
if ( $1 ~ /EMAIL:STATUS.*/ )
{  
print "BUILD:ERROR_COMMENT[none,not_needed,comment] not_needed";
}
print $0;
}' $D/data.txt > $D/data.txt.new

#copy temp file into the original data.txt file
cp $D/data.txt.new $D/data.txt
#remove the temp file
rm -f $D/data.txt.new
done
done

#!/bin/bash
# File:      make_status.bash
# Author:    Alex Warren
# Purpose:   generates status for given confrences
# Usage      bash status -h
#            bash make_status.bash pldi12 ccs12
#            bash make_status.bash all
#                   to use on each conferenceg on every data.txt
#            bash make_status.bash vldb12 | less -R
#                   for colors and pagenation

version="1.0"

usage(){
cat << EOF
NAME
     make_status.bash Reproducibility Research Progress Report
SYNOPSIS 
     bash make_status.bash [options] [conferences]
DESCRIPTION
     This script will go through the confrences given to it and make counts for various tags.
     It assumes that the database is properly formated, only looking for the presence of certain tags.
     Writes results to repro/logs/ when used with options below
OPTIONS
     -h      help - displays this help text
     -w      writes output to logs with time stamped file name
     -e      writes errors to logs with sperate time stamped file name.
     -v      writes all verification comments to seperate files for each worker
     -c      chart - outputs data for GNUplot
     -q      quick mode - skip checking for errors for faster execution
     -b      build - makes notes on what papers still need to be built
     -email  makes a record of all improperly tagged EMAIL:STATUS fields
     all     automatically parse all conferences
CONFERENCES
     Put a list of file directories for the script to go over. Use OPTION all to automatically go through ech conference.
EXAMPLES
     bash make_status.bash -w all
     bash make_status.bash pldi12
     bash make_status.bash -e pldi12
     bash make_status.bash -w -e all
     bash make_status.bash -c -q batch1

EOF
}

OIFS=$IFS
cd ..


for var in "$@"; do
  #if [[ $var = -* ]]; then
  case $var in
  -h)
    usage
    exit 0
    ;;
  -w)
    write="true"
    ;;
  -e)
    write_errors="true"
    ;;
  -v)
    verify_records="true"
    ;;
  -q)
    skip_errors="true"
    ;;
  -c)
    make_charts="true"
    ;;
  -b)
    make_build_record="true"
    ;;
  -email)
    make_email_record="true"
    ;;
  all)
    arg_list=( "asplos12" "ccs12" "oopsla12" "osdi12" "pldi12" "sigmod12" "sosp11" "taco9" "tissec15" "tocs30" "tods37" "toplas34" "vldb12" )
    ;;
  batch1)
    arg_list=( "oopsla12" "osdi12" "pldi12" "sosp11" "tissec15" "tocs30" "vldb12" )
    ;;
  *)
    arg_list=("${arg_list[@]}" "$var")
    ;;
    esac
done

if [[ -z "${arg_list[@]}" ]]; then
  echo "ERROR: no conferences"
  echo "HELP:"
  usage
  exit 0
fi

#starts the "all" report for the bar charts
if [[ "$make_charts" == "true" ]]; then
  bar_chart_all_data="CONF:ALL article google unkn/bkn"
fi

total_papers=0
total_error_papers=0
total_error_total=0
total_warning_total=0
total_implemented=0
total_finished=0
total_verified=0
total_google_link=0
total_article_link=0
total_broken_link=0
total_link_found=0
total_build_started=0
total_build_finished=0
total_build_downloaded=0
total_build_compiles=0
total_build_runs=0
all_error=""
pie_chart_data=""


#Array of every worker. UNKNOWN must be at the end
worker=( "Akash" "Alex" "chirag" "Gina" "Michelle" "zuoming" "UNKNOWN")
for i in "${!worker[@]}"; do
  worker_num_analysis[$i]=0
  worker_analysis_time[$i]=0
  worker_blank_time[$i]=0

  worker_non_verified[$i]=0
  worker_non_verified_errors[$i]=0

  worker_verifications[$i]=0
  worker_verified_errors[$i]=0
  worker_verified_comments[$i]="#Verify comments for ${worker[$i]}"

  worker_num_build[$i]=0
  worker_num_build_finished[$i]=0
  worker_build_time[$i]=0
done

num_workers=${#worker[@]}

timestamp=$(date -u "+%F_%H:%M")
filetimestamp=$(date -u "+%F_%H,%M")
build_record="Builds needed for $timestamp"$'\n'"Finished papers that have a link but not started or finished build"
email_record="Email status anomolies $timestamp"$'\n'"Papers that have an implementation but no link and don't have email needed"
result="#DATABASE STATUS(V$version) for $timestamp"
result="$result$(printf "\nCL%16s] conf     num   f  f&i    %%i  f&v | fi&w_l %%fi&w_l | a_l  g_l  brl | b_s b_f b_d b_c b_r | err  warn" $timestamp )"
#echo "${#arg_list[@]}"
for curr_conf in "${arg_list[@]}"; do
  tput setaf 5
  printf "\n%s" $curr_conf
  tput setaf 7

  num_papers=0
  num_error_papers=0
  num_error_total=0
  num_warning_total=0
  num_implemented=0
  num_finished=0
  num_verified=0
  num_google_link=0
  num_article_link=0
  num_broken_link=0
  num_link_found=0
  num_build_started=0
  num_build_finished=0
  num_build_downloaded=0
  num_build_compiles=0
  num_build_runs=0

 #and has implementataion


 directories=$(find ./$curr_conf -mindepth 1 -maxdepth 1 -type d)
 directories_array=( $ directories )
 for D in $directories; do
   printf "."


   #get field data
   implementation=( $(sed -n -e 's/^ARTICLE:IMPLEMENTATION.*\] //p' $D/data.txt) )
   analysis_status=( $(sed -n -e 's/^ARTICLE:STATUS.*\] //p' $D/data.txt) )
   analysis_by=( $(sed -n -e 's/^ARTICLE:ANALYSIS_BY.*\] //p' $D/data.txt) )
   analysis_time=( $(sed -n -e 's/^ARTICLE:ANALYSIS_TIME.*\] //p' $D/data.txt) )
   verify_status=( $(sed -n -e 's/^VERIFY:STATUS.*\] //p' $D/data.txt) )
   verify_by=( $(sed -n -e 's/^VERIFY:ANALYSIS_BY.*\] //p' $D/data.txt) )
   verify_comment=( $(sed -n -e 's/VERIFY:COMMENT.*\] //p' $D/data.txt) )
   build_status=( $(sed -n -e 's/^BUILD:STATUS.*\] //p' $D/data.txt) )
   build_by=( $(sed -n -e 's/^BUILD:ANALYSIS_BY.*\] //p' $D/data.txt) )
   build_time=( $(sed -n -e 's/^BUILD:ANALYSIS_TIME.*\] //p' $D/data.txt) )
   article_link=( $(sed -n -e 's/^TOOL:ARTICLE_LINK.*\] //p' $D/data.txt) )
   google_link=( $(sed -n -e 's/^TOOL:GOOGLE_LINK.*\] //p' $D/data.txt) )
   email_status=( $(sed -n -e 's/^EMAIL:STATUS.*\] //p' $D/data.txt) )

   #determine worker index for worker arrays
   (( current_worker_a= num_workers - 1 ))
   current_worker_v=$current_worker_a
   current_worker_b=$current_worker_a
   for i in "${!worker[@]}"; do
     if [ "$analysis_by" = ${worker[$i]} ]; then
       #echo "$i did ${worker[$i]}"
       current_worker_a=$i
     fi
     if [ "$verify_by" = ${worker[$i]} ]; then
       #echo "$i did ${worker[$i]}"
       current_worker_v=$i
     fi
     if [ "$build_by" = ${worker[$i]} ]; then
       #echo "$i did ${worker[$i]}"
       current_worker_b=$i
     fi
   done
   #echo "${worker[$current_worker]}"
   #echo "Current: $current_worker"

     
   #get ERROR data or skip
   if [[ "$skip_errors" == "true" ]]; then
     debug_out=""
     num_error=0
     num_warning=0
   else
     debug_out="$(java -jar ./scripts/Debug -q $D/data.txt)"
     num_error="$(echo "$debug_out" | grep -c "ERROR" )"
     num_warning="$(echo "$debug_out" | grep -c "WARNING" )"
   fi
   #Increment counters
   if [[  -n "$debug_out"  ]]; then
     all_error="$all_error"$'\n'"[ERROR_LOG_for:$D/data.txt]"$'\n'"$debug_out"$'\n'"[ERROR_LOG_CLOSE]"
     (( num_error_papers++ ))
   fi
   (( num_error_total+=num_error ))
   (( num_warning_total+=num_warning ))
   (( num_papers++ ))

   #Start checking conditions of data.txt for making totals
   has_link=0
   if [[ "$analysis_status" == "finished" ]]; then
     if [[ "${worker[$current_worker_a]}" == "UNKNOWN" ]]; then
       echo
       echo "UNKNOWN analysis worker:[$analysis_by]"
       echo "in $D"
     fi

     (( num_finished++ ))
     (( worker_num_analysis[$current_worker_a]++ ))
     #check if the analysis time was blank, and don't count that towards average
     if [[ "$analysis_time" == "999" || "$analysis_time" == "?" ]]; then
       (( worker_blank_time[$current_worker_a]++ ))
     else
         (( worker_analysis_time[$current_worker_a]+=analysis_time ))
     fi
     if [[ "$verify_status" == "finished" ]]; then
       if [[ "${worker[$current_worker_v]}" == "UNKNOWN" ]]; then
         echo "\nUNKNOWN verify worker:[$verify_by]"
         echo "in $D"
       fi
       (( num_verified++ ))
       (( worker_verifications[$current_worker_v]++ ))
       (( worker_verified_errors[$current_worker_v]+= num_error ))
       worker_verified_comments[$current_worker_a]="${worker_verified_comments[$current_worker_a]}"$'\n'"[$D:$verify_by]${verify_comment[@]}"
     else
       #echo "not finished: [$verify_status]"
       #echo "in $D"
       (( worker_non_verified[$current_worker_a]++ ))
       (( worker_non_verified_errors[$current_worker_a]+=num_error )) 
     fi
     if [[ "$implementation" == "yes" ]]; then
       (( num_implemented++ ))
        broken=0
        if [[ "$article_link" != "none" ]]; then
          if [[ "$article_link" != "broken" ]]; then
            #assumes a link if the tags don't say otherwise
            (( num_article_link++ ))
            has_link=1
          else
            broken=1
          fi 
       fi
       if [[ ("$article_link" == "none" || "$article_link" == "broken" ) && "$google_link" != "none" ]]; then
         if [[ "$google_link" != "broken" ]]; then
           (( num_google_link++ ))
           has_link=1
           broken=0
         else
           broken=1
         fi 
       fi
       if [[ "$broken" == "1" ]]; then
          (( num_broken_link++ ))
       fi
     fi
     if [[ "$build_status" == "started" || "$build_status" == "finished" ]]; then
       if [[ "${worker[$current_worker_b]}" == "UNKNOWN" ]]; then
          echo "\nUNKNOWN build worker:[$build_by]"
          echo "in $D"
       fi
       (( worker_num_build[$current_worker_b]++ ))
       (( worker_build_time[$current_worker_b]+=build_time ))
       if [[ "$build_status" == "started" ]]; then
         (( num_build_started++ ))
         build_record="$build_record"$'\n'"Build_Started $D/data.txt"
       else 
         (( num_build_finished++ ))
         (( worker_num_build_finished[$current_worker_b]++ ))
       fi
       for i in "${build_status[@]}"; do
         if   [[ "$i" == "downloaded" ]]; then
           (( num_build_downloaded++ ))
         elif [[ "$i" == "compiles" ]]; then
           (( num_build_compiles++ ))
         elif [[ "$i" == "runs" ]]; then
           (( num_build_runs++ ))
         fi
       done
     elif [[ "$has_link" == "1" ]]; then
       #if it has a link and isn't implemented then this will still come up
       build_record="$build_record"$'\n'"Build_Needed $D/data.txt"
     elif [[ "$implementation" == "yes" ]]; then
      #No build status and Doesn't have a link but is implemented: It needs an email
      if [[ "$email_status" != "needed" ]]; then
        email_record="$email_record"$'\n'"Expected_email_needed $D/data.txt"
      fi
     fi
   fi #end is finished
 done

  (( num_link_found = num_google_link+num_article_link ))

 #Calculate worker per 
 for i in "${!worker[@]}"; do
   #check for division by zero before making calculations
   #temp is how many articles have the correct time
   (( temp=worker_num_analysis[$i]-worker_blank_time[$i] ))
   if [ "$temp" -ne "0" ]; then
    ((worker_avg_analysis_time[$i]=worker_analysis_time[$i] / temp ))
  else worker_avg_analysis_time[$i]=0 
  fi
  if [ "${worker_non_verified[$i]}" -ne "0" ] ; then
    ((worker_non_verified_errors_percent[$i]=(100*worker_non_verified_errors[$i])/worker_non_verified[$i] )) 
  else worker_non_verified_errors_percent[$i]=0 
  fi
  if [ "${worker_verifications[$i]}" -ne "0" ]; then
    (( worker_verified_errors_percent[$i]=(100*worker_verified_errors[$i])/worker_verifications[$i] ))
  else worker_verified_errors_percent[$i]=0 
  fi
  if [ "${worker_num_build[$i]}" -ne "0" ]; then
    (( worker_avg_build_time[$i]=worker_build_time[$i]/worker_num_build[$i] ))
  else worker_avg_build_time[$i]=0
  fi
 done

 #calculate percentages
 if [ "$num_finished" -ne "0" ]; then
  (( percent_implemented=(100*num_implemented)/num_finished ))
 else percent_implemented=0; fi
 if [ "$num_implemented" -ne "0" ]; then
  (( percent_link_found=(100*num_link_found)/num_implemented ))
 else percent_link_found=0; fi

  #Add up totals
  (( total_papers+=num_papers ))
  (( total_error_papers+=num_error_papers ))
  (( total_error_total+=num_error_total ))
  (( total_warning_total+=num_warning_total ))
  (( total_implemented+=num_implemented ))
  (( total_finished+=num_finished ))
  (( total_verified+=num_verified ))
  (( total_google_link+=num_google_link ))
  (( total_article_link+=num_article_link ))
  (( total_broken_link+=num_broken_link ))
  (( total_link_found+=num_link_found ))
  (( total_build_started+=num_build_started ))
  (( total_build_finished+=num_build_finished ))
  (( total_build_downloaded+=num_build_downloaded ))
  (( total_build_compiles+=num_build_compiles ))
  (( total_build_runs+=num_build_runs ))
  
 #print results of conference
 #result="$result$(printf "\nCL%16s] conf     num   f  f&i    %%i  f&v | fi&w_l %%fi&w_l | a_l  g_l  brl | b_s b_f b_d b_c b_r | err  warn" $timestamp )"
 result="$result$(printf "\nCR%16s] %-8s %3d %3d  %3d  %3d%%  %3d |    %3d    %3d%% | %3d  %3d  %3d | %3d %3d %3d %3d %3d | %3d   %3d" $timestamp $curr_conf $num_papers $num_finished $num_implemented $percent_implemented $num_verified $num_link_found $percent_link_found $num_article_link $num_google_link $num_broken_link $num_build_started $num_build_finished $num_build_downloaded $num_build_compiles $num_build_runs $num_error_total $num_warning_total )"
 if [[ "$make_charts" == "true" ]]; then
   pie_chart_data="CONF:$curr_conf"$'\n'"\"no imp\" $(( num_finished-num_implemented ))"
   pie_chart_data="$pie_chart_data"$'\n'"\"no/bkn lnk\" $(( num_implemented-num_link_found ))"
   pie_chart_data="$pie_chart_data"$'\n'"\"lnk no run\" $(( num_build_finished-num_build_runs ))"
   pie_chart_data="$pie_chart_data"$'\n'"\"builds runs\" $(( num_build_runs ))"
   pie_chart_data="$pie_chart_data"$'\n'"\"lnk but ukn build\" $(( num_link_found-num_build_finished ))"
   echo "$pie_chart_data" > ./webpage/data/pie/"$curr_conf"-status-pie.txt 

   pie_chart_data_greyless="CONF:$curr_conf"$'\n'"\"no/bkn lnk\" $(( num_implemented-num_link_found ))"
   pie_chart_data_greyless="$pie_chart_data_greyless"$'\n'"\"lnk no run\" $(( num_build_finished-num_build_runs ))"
   pie_chart_data_greyless="$pie_chart_data_greyless"$'\n'"\"builds runs\" $(( num_build_runs ))"
   pie_chart_data_greyless="$pie_chart_data_greyless"$'\n'"\"lnk but ukn build\" $(( num_link_found-num_build_finished ))"
   echo "$pie_chart_data_greyless" > ./webpage/data/pie_greyless/"$curr_conf"-status-pie-greyless.txt 

   bar_chart_data="CONF:$curr_conf article google unkn/bkn"
   bar_chart_data="$bar_chart_data"$'\n'"$curr_conf $(( num_article_link )) $(( num_google_link )) $(( num_implemented - num_article_link - num_google_link ))"
   echo "$bar_chart_data" > ./webpage/data/bar/"$curr_conf"-links-bar.txt 
   if [[ "$num_finished" != "0" ]]; then
    bar_chart_all_data="$bar_chart_all_data"$'\n'"$curr_conf $(( num_article_link )) $(( num_google_link )) $(( num_implemented - num_article_link - num_google_link ))"
   fi
 fi
done

#calculate percentages
if [ "$total_finished" -ne "0" ]; then
 (( total_percent_implemented=(100*total_implemented)/total_finished ))
else total_percent_implemented=0; fi
  if [ "$total_implemented" -ne "0" ]; then
   (( total_percent_link_found=(100*total_link_found)/total_implemented ))
 else total_percent_link_found=0; fi

#Print Totals for conferences
result="$result$(printf "\nCT%16s] total    %3d %3d  %3d  %3d%%  %3d |    %3d    %3d%% | %3d  %3d  %3d | %3d %3d %3d %3d %3d | %3d   %3d" $timestamp $total_papers $total_finished $total_implemented $total_percent_implemented $total_verified $total_link_found $total_percent_link_found $total_article_link $total_google_link $total_broken_link $total_build_started $total_build_finished $total_build_downloaded $total_build_compiles $total_build_runs $total_error_total $total_warning_total)"
if [[ "$make_charts" == "true" ]]; then
 pie_chart_data="CONF:ALL"$'\n'"\"no imp\" $(( total_finished-total_implemented ))"
 pie_chart_data="$pie_chart_data"$'\n'"\"no/bkn lnk\" $(( total_implemented-total_link_found ))"
 pie_chart_data="$pie_chart_data"$'\n'"\"lnk no run\" $(( total_build_finished-total_build_runs ))"
 pie_chart_data="$pie_chart_data"$'\n'"\"builds runs\" $total_build_runs"
 pie_chart_data="$pie_chart_data"$'\n'"\"lnk but ukn build\" $(( total_link_found-total_build_finished ))"
 echo "$pie_chart_data" > ./webpage/data/pie/ALL.txt 

  pie_chart_data_greyless="CONF:ALL"$'\n'"\"no/bkn lnk\" $(( total_implemented-total_link_found ))"
  pie_chart_data_greyless="$pie_chart_data_greyless"$'\n'"\"lnk no run\" $(( total_build_finished-total_build_runs ))"
  pie_chart_data_greyless="$pie_chart_data_greyless"$'\n'"\"builds runs\" $(( total_build_runs ))"
  pie_chart_data_greyless="$pie_chart_data_greyless"$'\n'"\"lnk but ukn build\" $(( total_link_found-total_build_finished ))"
  echo "$pie_chart_data_greyless" > ./webpage/data/pie_greyless/ALL-greyless.txt 

fi

#starts the "all" report for the bar charts
if [[ "$make_charts" == "true" ]]; then
  bar_chart_all_data="$bar_chart_all_data"$'\n'"ALL $(( total_article_link )) $(( total_google_link )) $(( total_implemented - total_article_link - total_google_link ))"
  echo "$bar_chart_all_data" > ./webpage/data/bar/ALL.txt 
fi

#Print results for each worker
result="$result$(printf "\n\nWL%16s] name        #anl  time  avg_time | nonv  err  %%err | ver err %%err |   #b  time  avg_time" $timestamp )"
for i in "${!worker[@]}"; do
 result="$result$(printf "\nWR%16s] %-8s     %3d   %3d       %3d |  %3d %4d  %3d%% | %3d %3d %3d%% |  %3d  %4d       %3d" $timestamp ${worker[$i]}  ${worker_num_analysis[$i]} ${worker_analysis_time[$i]} ${worker_avg_analysis_time[$i]} ${worker_non_verified[$i]} ${worker_non_verified_errors[$i]} ${worker_non_verified_errors_percent[$i]} ${worker_verifications[$i]} ${worker_verified_errors[$i]} ${worker_verified_errors_percent[$i]} ${worker_num_build[$i]} ${worker_build_time[$i]} ${worker_avg_build_time[$i]} )"
done

#print results to screen
echo
echo "$result"


#write results if options were chosen
if [[ "$write" == "true" ]]; then
  echo "$result" > "./logs/status$filetimestamp.log"
fi

if [[ "$write_errors" == "true" ]]; then
  echo "$all_error" > "./logs/error.log"
fi

if [[ "$verify_records" == "true" ]]; then
 for i in "${!worker[@]}"; do
   #echo "${worker_verified_comments[$i]}" 
   echo "${worker_verified_comments[$i]}" > "./logs/verify_comments_${worker[$i]}.txt"
 done
fi

if [[ "$make_build_record" == "true" ]]; then
  echo "$build_record" > "./logs/build_needed.txt"
fi

if [[ "$make_email_record" == "true" ]]; then
  echo "$email_record" > "./logs/email_wrong_tags.txt"
fi
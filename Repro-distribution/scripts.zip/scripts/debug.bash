#!/bin/bash
# File:              debug.bash
# Author:      Alex Warren
# Purpose:   runs the debu
# Usage      bash debug.bash pldi12 ccs12
#                     bash debug.bash all
#                         to use on each conferenceg on every data.txt
#                      bash debug.bash vldb12 | less -R
#                         for colors and pagenation

OIFS=$IFS

spread_titles=( "Labels" "Bibtex entry" "link to paper.pdf" "Commercial Involvement" "Name of tool" "Implemented" "URL in paper" "URL via google" "authors' email" "Grants" "URL via email" "Successful download" "Successful build" "Successful run" "Status analysis" "email status" "Comment" "Time Spent (min)" "Person" "CC Comment" "TP Comment" "AW Comment" )


if [ $1 = "all" ]; then
    arg_list="asplos12 ccs12 oopsla12 osdi12 pldi12 sigmod12 sosp11 taco9 tissec15 tocs30 tods37 toplas34 vldb12"
else
    arg_list="$@"
fi

for arg in $arg_list
do
    tput setaf 5
    echo "In $arg"
    tput setaf 7
    directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
    directories_array=( $ directories )
    for D in $directories; do
        tput setaf 4
        echo "Checking $D/"
        tput setaf 7
        output="$(java -jar Debug $D/data.txt)"
    if [[ ( -n "$output" ) ]]; then
        echo "$output"
    fi
	if [[ ( -n "$output" ) && ( -r $D/from_spreadsheet.txt ) && ( -z "skip this") ]]; then
            echo "original:"
	    echo
            #read spreadsheet < $D/from_spreadsheet.txt
            spreadsheet=$( sed 's|\t| \t|g' $D/from_spreadsheet.txt )
            IFS=$'\t'
            spread_array=($spreadsheet)
            for i in "${!spread_array[@]}"; do
                 echo "[$i]${spread_titles[$i]}: ${spread_array[$i]}"
           done
           IFS=$OIFS
        fi
    done
done

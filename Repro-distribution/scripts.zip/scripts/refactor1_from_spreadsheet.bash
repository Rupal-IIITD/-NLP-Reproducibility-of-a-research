#!/bin/bash
# File:              refactor_from_spreadsheet.bash
# Author:      Alex Warren
# Purpose:   converts to new data.txt format
# Usage      bash refactor_from_spreadsheet.bash vldb12
# Or for every relevant conference (determined 5/31)
#                      bash  refactor_from_spreadsheet.bash convert_list

OIFS=$IFS

if [ $1 = "convert_list" ]; then
    arg_list="vldb12 oopsla12 "
else
    arg_list="$@"
fi

for arg in $arg_list
do
    tput setaf 5
    echo "In $arg"
    tput setaf 7
    directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
    for D in $directories; do
        tput setaf 4
        echo "Refactoring $D/data.txt"
        tput setaf 7

        data=$(<$D/data.txt)
       
        result=$( echo "$data" | sed 's|ARTICLE:STATUS.*]|ARTICLE:STATUS\[not_finished,finished\]|g' )
        result=$( echo "$result" | sed 's|TOOL:LINK.*||g' | tr -s '\n')

        spreadsheet=$( sed 's|\t| \t|g' $D/from_spreadsheet.txt )
        IFS=$'\t'
        spread_array=($spreadsheet)
        IFS=$OIFS
        #${spread_array[$i]}

        sani_google=$( echo "${spread_array[7]}" | sed -e 's/[\/&]/\\&/g' )
        sani_article=$( echo "${spread_array[6]}" | sed -e 's/[\/&]/\\&/g' )
        result=$( echo "$result" | sed '/^TOOL:NAME/a TOOL:ARTICLE_LINK[unknown,none,url,broken and url] '"$sani_article"'\nTOOL:GOOGLE_LINK[unknown,none,url,broken and url] '"$sani_google"'\nTOOL:EMAIL_LINK[unknown,none,sent_no_url,url,broken and url] \nTOOL:DATA_LINK[unknown,none,url,broken and url] unknown')
        result="$result
VERIFY_BUILD:ANALYSIS_BY[name] 
VERIFY_BUILD:STATUS[unknown,needed,not_needed,started,finished] 
VERIFY_BUILD:COMMENT[string] "

       #echo "$result"
        echo "$result" > $D/data.txt

    done
done
#!/bin/bash
# File: addsrcfolder.bash
# Author: Alex Warren
# Purpose: adds build_notes.txt to every depth 1 subdirectory and adds a src folder
# Usage ./addsrc.bash pldi12 ccs12
#       this will add the file and folder to each paper's directory in those conference
# Note: this script needs to have a build_notes.txt in the script_resources directory

for arg in "$@"
do
    echo "In $arg"
    for D in `find ./../$arg -mindepth 1 -maxdepth 1 -type d`
    do
        echo "Adding build_notes.txt and src to $D/"
        mkdir $D/src
		touch $D/src/.blank
        cp ./script_resources/build_notes.txt $D/build_notes.txt
        
    done
done

#!/bin/bash
echo ">>>> lsb_release -a"
lsb_release -a
echo ">>>> uname -a"
uname -a
echo ">>>> lscpu"
lscpu
echo ">>>> javac -version"
javac -version
echo ">>>> gcc --version"
gcc --version
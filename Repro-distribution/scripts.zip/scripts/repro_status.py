#! /usr/bin/python
# -*- coding: utf-8 -*-
"""
repro_status
Various utilities for viewing the reproducibility database. Has options to check
for errors, for incomplete entries, and to output macros for latex and two versions
of a website. Use the help option for descriptions of each utility.
"""

# Author: Alex Warren
# Email : amwarren@email.arizona.edu

from __future__ import division
from repro_loader import *
import argparse
import sys
from collections import OrderedDict
#bibtexparser is needed for generating website
#get using pip
from bibtexparser.bparser import BibTexParser
from bibtexparser.customization import convert_to_unicode
import os
import pprint
pp = pprint.PrettyPrinter(indent=4)

import texttable as tt

parser = argparse.ArgumentParser(
    description='Load repro database, find errors, create statistics and generate logs')
parser.add_argument("dir", help="Root directory of the reproducibility database.")
parser.add_argument("conferences", nargs='+', 
    help="List of conferences for parsing. Special: all, batch1, batch2, removed (must be only argument)")
parser.add_argument("-v", "-verbose", dest="verbose", action="store_true",
        help="Verbose mode, print more information.")
parser.add_argument("-x", "-latex", dest="update_latex", action="store_true",
        help="remake the latex file repro/doc/tr/resultmacros.tex to have correct numbers for constants.")
parser.add_argument("-xt", "-latex-tables", dest="update_latex_table", action="store_true",
        help="remake the latex file repro/doc/tr/resulttable.tex with all the latest macros. Normally not needed.")
parser.add_argument("-c", "-chart", dest="make_chart_data", action="store_true",
        help="Update all the datafiles used with the webpage")
parser.add_argument("-t", "-print-table", dest="make_tables", action="store_true",
        help="Print a table with summary data for each confernce")
parser.add_argument("-e", "-errors", dest="print_errors", action="store_true",
        help="Print each error with the database entry")
parser.add_argument("-le", "-long-errors", dest="long_errors", action="store_true",
        help="Print a list of all reported errors with data.txt file")
parser.add_argument("-validate", dest="diff_validate", action="store_true",
        help="Write original files and files from datastruct for comparison")
parser.add_argument("-ev", "-email-validate", dest="email_name_list", action="store_true",
        help="Write list of emails and names for validation.")
parser.add_argument("-nf", "-not-finished", dest="not_finished_list", action="store_true",
        help="Write list of papers that are not finished or not validated.")
parser.add_argument("-bnf", "-build-not-finished", dest="build_not_finished_list", action="store_true",
        help="Write list of papers that still need to be built.")
parser.add_argument("-mbe", "-missing-build-error", dest="missing_build_error", action="store_true",
        help="Write list of papers that don't build but are not recorded with build error.")
parser.add_argument("-nsf", dest="nsf_results", action="store_true",
        help="Write list of papers that email no or don't respond despite having NSF grant.")
parser.add_argument("-rel", "-recieved-email-list", dest="recieved_email_list", action="store_true",
        help="Write list of emails that got a request.")
parser.add_argument("-sb", "-short-build", dest="short_build", action="store_true",
        help="Find papers where the build didn't run but it was cut short.")
parser.add_argument("-web", dest="generate_website", action="store_true",
        help="Generate the webpage for public display of results.")
parser.add_argument("-special", dest="list_special", action="store_true",
        help="Spot for generic list - to be programmed at need.")
parser.add_argument("-normalize", dest="normalize", action="store_true",
        help="Rewrite the data.txt files with standard representation.")
parser.add_argument("-nbv","-not-build-verified", dest="not_build_verified", action="store_true",
        help="List unresolved build verification.")
parser.add_argument("-eac","-email-address-count", dest="email_address_count", action="store_true",
        help="List number of email addresses for each paper.")
parser.add_argument("-cbvn","-compare-build-verification-needed",  action="store_true",
        dest="compare_build_verification_needed", 
        help="Show mismatches between log and actual data.txt files.")

args = parser.parse_args()

#defaults - possible later arguments
args.normal_table = args.make_tables
args.build_table = args.make_tables
args.email_table = args.make_tables

if args.verbose:
    print("Using arguments:")
    pp.pprint(args)

print("\nLoading database")
database = repro_database(args.dir, args.conferences, 
                          verbose=args.verbose, diff_validate=args.diff_validate,
                          normalize=args.normalize)
print("Finished loading.\n")

#  ██████╗ ██████╗ ███╗   ██╗███████╗████████╗ █████╗ ███╗   ██╗████████╗███████╗
# ██╔════╝██╔═══██╗████╗  ██║██╔════╝╚══██╔══╝██╔══██╗████╗  ██║╚══██╔══╝██╔════╝
# ██║     ██║   ██║██╔██╗ ██║███████╗   ██║   ███████║██╔██╗ ██║   ██║   ███████╗
# ██║     ██║   ██║██║╚██╗██║╚════██║   ██║   ██╔══██║██║╚██╗██║   ██║   ╚════██║
# ╚██████╗╚██████╔╝██║ ╚████║███████║   ██║   ██║  ██║██║ ╚████║   ██║   ███████║
#  ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝   ╚═╝   ╚═╝  ╚═╝╚═╝  ╚═══╝   ╚═╝   ╚══════╝

FORMATTED_CONFERENCE = {'asplos12':'ASPLOS \'12',
                        'ccs12':'CCS \'12',
                        'oopsla12':'OOPSLA \'12',
                        'osdi12':'OSDI \'12',
                        'pldi12':'PLDI \'12',
                        'sigmod12':'SIGMOD \'12',
                        'sosp11':'SOSP \'11',
                        'taco9':'TACO \'9',
                        'tissec15':'TISSEC \'15',
                        'tocs30':'TOCS \'30',
                        'tods37':'TODS \'37',
                        'toplas34':'TOPLAS \'34',
                        'vldb12':'VLDB \'12',
                        'NSF':'NSF',
                        'NoNSF':'No NSF'}

DIVIDER = '-' * 20

# ███████╗██████╗ ██████╗  ██████╗ ██████╗ ███████╗
# ██╔════╝██╔══██╗██╔══██╗██╔═══██╗██╔══██╗██╔════╝
# █████╗  ██████╔╝██████╔╝██║   ██║██████╔╝███████╗
# ██╔══╝  ██╔══██╗██╔══██╗██║   ██║██╔══██╗╚════██║
# ███████╗██║  ██║██║  ██║╚██████╔╝██║  ██║███████║
# ╚══════╝╚═╝  ╚═╝╚═╝  ╚═╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝

if args.print_errors:
    print("ERRORS")
    pp.pprint(database.errors)

if args.long_errors:
    for error in database.errors:
        print DIVIDER
        print repr(error)
        print DIVIDER
        print database.printRecord(error.record)

#  ██████╗  ██████╗     ████████╗ █████╗ ██████╗ ██╗     ███████╗███████╗
# ██╔═══██╗██╔════╝     ╚══██╔══╝██╔══██╗██╔══██╗██║     ██╔════╝██╔════╝
# ██║   ██║██║  ███╗       ██║   ███████║██████╔╝██║     █████╗  ███████╗
# ██║   ██║██║   ██║       ██║   ██╔══██║██╔══██╗██║     ██╔══╝  ╚════██║
# ╚██████╔╝╚██████╔╝       ██║   ██║  ██║██████╔╝███████╗███████╗███████║
#  ╚═════╝  ╚═════╝        ╚═╝   ╚═╝  ╚═╝╚═════╝ ╚══════╝╚══════╝╚══════╝
def summarizeRow(records):
    fv_records = filter(isFinishedValidated, records)
    fv_i_records = filter(hasImplementation, fv_records)
    percent_implemented = 0 if len(fv_records) == 0 else int(len(fv_i_records)*100/len(fv_records))
    working_link = filterCount(hasWorkingLink, fv_i_records)
    percent_working_link = 0 if len(fv_i_records) == 0 else int(working_link*100/len(fv_i_records))
    return [len(records),                                #total number
            len(fv_records),                             #finished and verified
            len(fv_i_records),                             #finished, varified and implemented
            str(percent_implemented)+'%',                #percent of finished, verified with implementation
            working_link,                                #number of f v i with working link
            str(percent_working_link)+'%',                #percent ^^
            filterCount(hasArticleLink, fv_i_records),    #f v i with article link
            filterCount(hasGoogleLink, fv_i_records),    #f v i with google link
            filterCount(hasBrokenLink, fv_i_records)    #f v i with broken link
            ] #ADD EMAIL LINK

def summarizeBuildRow(records):
    isFinishedValidatedImplemented = lambda x: isFinishedValidated(x) and hasImplementation(x)
    fv_i_records = filter(isFinishedValidatedImplemented, records)
    working_link = filterCount(hasWorkingLink, fv_i_records)
    return [len(fv_i_records),                             #finished, varified and implemented
            working_link,                                #number of f v i with working link
            filterCount(hasBuildNotNeeded, fv_i_records),
            filterCount(hasBuildUnknown, fv_i_records),
            filterCount(hasBuildTodo, fv_i_records),
            filterCount(hasBuildBlank, fv_i_records),
            filterCount(isBuildStarted, fv_i_records),
            filterCount(isBuildFinished, fv_i_records),
            filterCount(hasBuildDownloaded, fv_i_records),
            filterCount(hasBuildCompiles, fv_i_records),
            filterCount(hasBuildRuns, fv_i_records),
            filterCount(hasEmail1Yes, fv_i_records),
            filterCount(hasEmailBuildFinished, fv_i_records),
            ]

if args.normal_table:
    #Create table
    print("\nStatus Summary\n--------------")
    table = tt.Texttable()
    table.set_cols_width([13,4,4,4,4,6,7,4,4,4])
    titles = ["conf", "num", "f&v", "fv&i", "fv%i", "fi&w_l",
                "%fi&w_l", "a_l", "g_l", "brl"]
    table.header(titles)
    for conf in database.conference_lists:
        row = [conf,]
        row.extend(summarizeRow(database.conference_lists[conf]))
        table.add_row(row)
    row = ["total",]
    row.extend(summarizeRow(database.records))
    table.add_row(row)
    print table.draw()

if args.build_table:
    print("\nBuild Summary\n-------------")
    table = tt.Texttable()
    table.set_cols_width([13, 4, 4, 6, 6, 7, 6, 5, 6, 6, 6, 6, 6, 6])
    titles = ["conf", "fvi", "w_l", "b_not", "b_ukn", "b_todo", "b_blk",
                 "b_st", "b_fin", "b_dwn", "b_cmp", "b_run", "eml_b", "eml_f"]
    table.header(titles)
    for conf in database.conference_lists:
        row = [conf,]
        row.extend(summarizeBuildRow(database.conference_lists[conf]))
        table.add_row(row)
    row = ["total",]
    row.extend(summarizeBuildRow(database.records))
    table.add_row(row)
    print table.draw()

def summarizeEmailRow(records):
    return [filterCount(hasEmailNeeded, records),
            filterCount(hasEmailRequest1, records),
            filterCount(hasEmailResponse1, records),
            filterCount(hasEmailThank, records),
            filterCount(hasEmail1Yes, records),
            filterCount(hasEmail1No, records),
            filterCount(hasEmail1NoResponse, records)]

if args.email_table:
    print("\nEmail Summary\n-------------")
    table = tt.Texttable()
    table.set_cols_width([5, 4, 5, 5, 5, 3, 3, 6])
    table.header(["batch", "need", "req_1", "res_1", "thank", "yes", "no", "no_res"])
    batch1 = filter(isBatch1, database.records)
    row = ["1"]
    row.extend(summarizeEmailRow(batch1))
    table.add_row(row)
    #Batch 2
    batch2 = filter(isBatch2, database.records)
    row = ["2"]
    row.extend(summarizeEmailRow(batch2))
    table.add_row(row)
    #Batch 3
    batch3 = filter(isBatch3, database.records)
    row = ["3"]
    row.extend(summarizeEmailRow(batch3))
    table.add_row(row)
    #total
    row = ["All"]
    row.extend(summarizeEmailRow(database.records))
    table.add_row(row)
    print table.draw()

#  ██████╗ ████████╗██╗  ██╗███████╗██████╗     ██████╗ ███████╗███████╗██╗   ██╗██╗  ████████╗███████╗
# ██╔═══██╗╚══██╔══╝██║  ██║██╔════╝██╔══██╗    ██╔══██╗██╔════╝██╔════╝██║   ██║██║  ╚══██╔══╝██╔════╝
# ██║   ██║   ██║   ███████║█████╗  ██████╔╝    ██████╔╝█████╗  ███████╗██║   ██║██║     ██║   ███████╗
# ██║   ██║   ██║   ██╔══██║██╔══╝  ██╔══██╗    ██╔══██╗██╔══╝  ╚════██║██║   ██║██║     ██║   ╚════██║
# ╚██████╔╝   ██║   ██║  ██║███████╗██║  ██║    ██║  ██║███████╗███████║╚██████╔╝███████╗██║   ███████║
#  ╚═════╝    ╚═╝   ╚═╝  ╚═╝╚══════╝╚═╝  ╚═╝    ╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝ ╚══════╝╚═╝   ╚══════╝

if args.make_tables:
    print "\nOther Results\n--------------"
    fv_records = filter(isFinishedValidated, database.records)
    fvi_records = filter(hasImplementation, fv_records)
    noneCommercial = filter(hasNoCommercialEffort, fvi_records)
    partCommercial = filter(hasPartCommercialEffort, fvi_records)
    fullCommercial = filter(hasFullCommercialEffort, fvi_records)
    wl_noneCommercial = filterCount(hasWorkingLink, noneCommercial)
    wl_partCommercial = filterCount(hasWorkingLink, partCommercial)
    wl_fullCommercial = filterCount(hasWorkingLink, fullCommercial)
    print "Num finished and verified and implemented: {}".format(len(fvi_records))
    print "Commercial   Num    Working Link   Percent"
    print "none        {:>4}            {:>4}     {:>4}%".format(
        len(noneCommercial), wl_noneCommercial, round(wl_noneCommercial*100/len(noneCommercial)))
    print "part        {:>4}            {:>4}     {:>4}%".format(
        len(partCommercial), wl_partCommercial, round(wl_partCommercial*100/len(partCommercial)))
    print "full        {:>4}            {:>4}     {:>4}%".format(
        len(fullCommercial), wl_fullCommercial, round(wl_fullCommercial*100/len(fullCommercial)))

# ███╗   ██╗███████╗███████╗    ██████╗ ███████╗███████╗██╗   ██╗██╗  ████████╗███████╗
# ████╗  ██║██╔════╝██╔════╝    ██╔══██╗██╔════╝██╔════╝██║   ██║██║  ╚══██╔══╝██╔════╝
# ██╔██╗ ██║███████╗█████╗      ██████╔╝█████╗  ███████╗██║   ██║██║     ██║   ███████╗
# ██║╚██╗██║╚════██║██╔══╝      ██╔══██╗██╔══╝  ╚════██║██║   ██║██║     ██║   ╚════██║
# ██║ ╚████║███████║██║         ██║  ██║███████╗███████║╚██████╔╝███████╗██║   ███████║
# ╚═╝  ╚═══╝╚══════╝╚═╝         ╚═╝  ╚═╝╚══════╝╚══════╝ ╚═════╝ ╚══════╝╚═╝   ╚══════╝

if args.nsf_results:
    fv_records = filter(isFinishedValidated, database.records)
    fvi_records = filter(hasImplementation, fv_records)
    nsf_noEmail = filter(hasNSFGrant, filter(hasEmail1No, fvi_records))
    nsf_noResponseEmail = filter(hasNSFGrant, filter(hasEmail1NoResponse, fvi_records))
    print "With NSF but responds 'No' in email ({}):".format(len(nsf_noEmail))
    print DIVIDER
    for record in nsf_noEmail:
        print record.path
        print "NSF_SUPPORT:  %s" % record.ARTICLE.NSF_SUPPORT.value
        print "EMAIL_REMARK: %s" % str(record.EMAIL1.REMARK)
        print DIVIDER
    print "\n\n"
    print "With NSF but no response ({}):".format(len(nsf_noResponseEmail))
    print DIVIDER
    for record in nsf_noResponseEmail:
        print record.path
        print "NSF_SUPPORT:  %s" % record.ARTICLE.NSF_SUPPORT.value
        print DIVIDER

# ██╗    ██╗███████╗██████╗ ███████╗██╗████████╗███████╗
# ██║    ██║██╔════╝██╔══██╗██╔════╝██║╚══██╔══╝██╔════╝
# ██║ █╗ ██║█████╗  ██████╔╝███████╗██║   ██║   █████╗  
# ██║███╗██║██╔══╝  ██╔══██╗╚════██║██║   ██║   ██╔══╝  
# ╚███╔███╔╝███████╗██████╔╝███████║██║   ██║   ███████╗
#  ╚══╝╚══╝ ╚══════╝╚═════╝ ╚══════╝╚═╝   ╚═╝   ╚══════╝

WEB_TABLE_TITLES = """
<tr>
 <th class="row_bibtex">Label</th>
 <th class="row_group">Venue</th>
 <th class="row_author">Authors</th>
 <th class="row_title">Title</th>
 <th class="row_type">Type</th>
 <th class="row_page_count">Page Count</th>
 <th class="row_classification">Classifi&shy;cation</th>
 <th class="row_code_location">Code Location</th>
 <th class="row_build_results">Build Results</th>
 <th class="skip">&nbsp</th>
 <th class="row_author_comment">Author Comment <small>Distinct responses separated by dashes.</small></th>
 <th class="row_response">Response</th>
 <th class="row_update">Post Study Updates</th>
 <th class="skip">&nbsp</th>
 <th class="row_data_link">Data Entry <small><a href="format.html#data-txt-fields">(help)</a></small></th>
 <th class="row_build_link">Build Notes <small><a href="format.html#build-notes-format">(help)</a></small></th>
 <th class="row_survey_link">Survey <small><a href="format.html#survey-results-format">(help)</a></small></th>
</tr>
"""

CSV_TABLE_TITLES = ['bibtex', 'title', 'venue', 'authors', 'type', 'page_count',
                    'classification', 
                    'code_location',
                    'build_results',
                    'author_comment',
                    'response',
                    'update',
                    'data_path', 'build_path', 'survey_path']

def getPaperTitle(record):
    """
    Get the title of a paper from it's bibtex.
    """
    bib_path = path.join(path.split(record.path)[0],"paper.bib")
    with open(bib_path, 'r') as bibfile:
        bp = BibTexParser(bibfile, customization=convert_to_unicode)
        return bp.get_entry_list()[0]['title'].replace('\n',' ').encode('ascii', 'ignore')

def longestSubstring(string):
    return max(len(x) for x in string.replace('<br/>', ' ').split())

def htmlHyphenate(text, chunk_length=8, thresh=12):
    if text > thresh:
        return "&shy;".join(text[0+i:chunk_length+i] 
                for i in xrange(0, len(text), chunk_length))
    else:
        return text

def webTableRow(record):
    """return a row of the distributed table"""
    row = {}
    venue = record.path.split('/')[-3]
    bibtex = record.path.split('/')[-2]

    row['bibtex'] = bibtex
    row['bibtex_html'] = htmlHyphenate(bibtex)

    row['bibtex_html'] = '<a href="data/{}_{}_bib.html">{}</a>'.format(venue, bibtex, row['bibtex_html'])

    if venue == "vldb12_new":
        row['venue'] = "vldb12"
    else:
        row['venue'] = venue

    row['venue'] = FORMATTED_CONFERENCE[row['venue']].replace("\'", "'")
    row['authors'] = ', '.join([name.replace('_',' ') for name in record.AUTHOR.NAMES.value])
    row['title'] = getPaperTitle(record)

    if record.ARTICLE.IMPLEMENTATION_EXISTS.yes:
        row['classification'] = "BC"
        row['classification_description'] = "Results are backed by code."
        row['row_style'] = "row_backed_code"
        if record.TOOL.ARTICLE_LINK.url and not record.TOOL.ARTICLE_LINK.broken:
            row['code_location'] = "Article"
            row['code_location_html'] = "Article"
            row['code_location_description'] = "Code found from link in the article."
            row['code_location_style'] = "bright_green"
        elif record.TOOL.GOOGLE_LINK.url and not record.TOOL.GOOGLE_LINK.broken:
            row['code_location'] = "Web"
            row['code_location_html'] = "Web"
            row['code_location_description'] = "Code found during web search."
            row['code_location_style'] = "yellow"
        elif record.EMAIL.STATUS.request_1:
            if record.EMAIL1.CODE_AVAILABLE.yes:
                row['code_location'] = "EM_yes"
                row['code_location_html'] = "EM<sup>yes</sup>"
                row['code_location_description'] = "Code provided by author after email request"
                row['code_location_style'] = "yellow"
            elif record.EMAIL1.CODE_AVAILABLE.no:
                row['code_location'] = "EM_no"
                row['code_location_html'] = "EM<sup>no</sup>"
                row['code_location_description'] = "Author responded that code could not be provided."
                row['code_location_style'] = "red"
            elif record.EMAIL1.CODE_AVAILABLE.no_response:
                row['code_location'] = "EM_0"
                row['code_location_html'] = "EM<sup>&Oslash;</sup>"
                row['code_location_description'] = "Authors did not respond to email request within 2 months."
                row['code_location_style'] = "red"
            else:
                print "Error: expected email result {}/{}".format(venue,bibtex)
        else:
            row['classification'] = "EX"
            row['classification_description'] = "Excluded due to overlapping author lists."
            row['row_style'] = "row_not_backed_code"
            row['code_location'] = "-"
            row['code_location_html'] = ""
            row['code_location_description'] = ""
            row['code_location_style'] = "nothing"
    else:
        row['row_style'] = "row_not_backed_code"
        row['code_location'] = "-"
        row['code_location_html'] = ""
        row['code_location_description'] =  ""
        row['code_location_style'] = "nothing"
        if record.ARTICLE.IMPLEMENTATION_EXISTS.hardware:
            row['classification'] = "HW"
            row['classification_description'] = "Excluded due to special hardware requirement."
        else:
            row['classification'] = "NC"
            row['classification_description'] = "Excluded because work not backed by code."

    if record.ARTICLE.IMPLEMENTATION_EXISTS.yes and record.BUILD.STATUS.finished:
        if record.BUILD.STATUS.compiles or record.BUILD.STATUS.online:
            if record.BUILD.VERIFY_STATUS.not_needed:
                row['build_results'] = "OK_leq_30"
                row['build_results_html'] = "OK<sup>&le;30</sup>"
                row['build_results_description'] = "We succeed in building the system in &le;30 minutes."
                row['build_results_style'] = "bright_green"
            else:
                row['build_results'] = "OK_gt_30"
                row['build_results_html'] = "OK<sup>>30</sup>"
                row['build_results_description'] = "We succeed in building the system in >30 minutes."
                row['build_results_style'] = "green"
        else:
            if record.survey_summary and (record.survey_summary.BUILD_DIFFICULTY.value == "reasonable_effort" or record.survey_summary.BUILD_DIFFICULTY.value == "not_applicable"):
                row['build_results'] = "OK_Author"
                row['build_results_html'] = "OK<sup>>Author</sup>"
                row['build_results_description'] = "We fail to build, but the author says the code builds with reasonable effort."
                row['build_results_style'] = "dark_green"
            else:
                row['build_results'] = "Fails"
                row['build_results_html'] = "Fails"
                row['build_results_description'] = "We fail to build, and the author doesn't respond to survey or says code may have problems building."
                row['build_results_style'] = "red"
        #if build is finished it has a build record
        row['build_path'] = "data/{}_{}_build.txt".format(venue,bibtex)
        row['build_link'] = '<a href="{0}">Build notes</a>'.format(row['build_path'])
        if not checkLink(row['build_path']):
            print "{}/{} has finished build but empty build notes".format(venue,bibtex)
    else:
        row['build_results'] = "-"
        row['build_results_html'] = ""
        row['build_results_description'] = ""
        row['build_results_style'] = "nothing"
        row['build_path'] = "-"
        row['build_link'] = "-"

    row['data_path'] = "data/{}_{}_data.txt".format(venue,bibtex)
    assert checkLink(row['data_path']), "{}/{} is missing link".format(venue,bibtex)
    
    if record.survey_summary:
        row['survey_path'] = "data/{}_{}_survey.txt".format(venue,bibtex)
        row['survey_link'] = '<a href="{0}">Survey</a>'.format(row['survey_path'])
        if not checkLink(row['survey_path']):
            print "{}/{} has survey but missing survey file".format(venue,bibtex)
        
        author_comments_html = []
        author_comments = []
        for survey in record.surveys:
            if survey.PUBLIC_COMMENT.value:
                # longest = longestSubstring(survey.PUBLIC_COMMENT.value)
                # if  longest > 40:
                #     print DIVIDER
                #     print "{}/{}".format(venue, bibtex)
                #     print longest
                #     print survey.PUBLIC_COMMENT.value
                author_comments_html.append("<p>{}</p>".format(survey.PUBLIC_COMMENT.value))
                author_comments.append(survey.PUBLIC_COMMENT.value + ";")
        if author_comments:
            row['author_comment_html'] = '<br\>----<br\>'.join(author_comments_html)
            row['author_comment'] = ''.join(author_comments)

        else:
            row['author_comment_html'] = ""
            row['author_comment'] = ""
    else:
        row['survey_path'] = "-"
        row['survey_link'] = "-"
        row['author_comment_html'] = ""
        row['author_comment'] = ""

    row['update'] = ""
    if record.COMMENT.UPDATE.value:
        splitup = record.COMMENT.UPDATE.value.split()
        update_comment = []
        for word in splitup:
            if word[:4] == 'http':
                text = htmlHyphenate(word, chunk_length=12, thresh=14)
                word = '<a href="{}">{}</a>'.format(word, text)
            update_comment.append(word)

        row['update'] = ' '.join(update_comment)


    row['response'] = ""
    row['response_html'] = ""
    if record.COMMENT.RESPONSE.value:
        row['response_html'] += "<p>{}</p>".format(record.COMMENT.RESPONSE.value)
        row['response'] += "{} ;".format(record.COMMENT.RESPONSE.value)
    if record.COMMENT.CORRECTION.value:
        row['response_html'] += "<p>{}</p>".format(record.COMMENT.CORRECTION.value)
        row['response'] += "{} ;".format(record.COMMENT.CORRECTION.value)

    row['type'] = str(record.ARTICLE.TYPE).capitalize()
    row['page_count'] = str(record.ARTICLE.PAGE_COUNT.value)
            


    return row

ROW_FORMAT_STRING = """<tr class="{row_style}">
 <td id="{bibtex}">{bibtex_html}</td>
 <td>{venue}</td>
 <td>{authors}</td>
 <td>{title}</td>
 <td>{type}</td>
 <td>{page_count}</td>
 <td title="{classification_description}">{classification}</td>
 <td class="{code_location_style}" title="{code_location_description}">{code_location_html}</td>
 <td class="{build_results_style}" title="{build_results_description}">{build_results_html}</td>
 <td class="skip"></td>
 <td class="comment">{author_comment_html}</td>
 <td class="comment">{response_html}</td>
 <td class="comment">{update}</td>
 <td class="skip"></td>
 <td><a href="{data_path}">Data</a></td>
 <td>{build_link}</td>
 <td>{survey_link}</td>
</tr>
"""

def convertTableToHTML(rows):
    result = []
    print("{} entries in webtable.".format(len(rows)))
    for ii, row in enumerate(rows):
        if ii%10 == 0:
            result.append(WEB_TABLE_TITLES)
        result.append(ROW_FORMAT_STRING.format(**row))
    return ''.join(result)

WEB_ROOT = "http://reproducibility.cs.arizona.edu/"
def convertTableToCSV(rows):
    result = ['\t'.join([title.replace('_', ' ') for title in CSV_TABLE_TITLES])]
    for row in rows:
        row['data_path'] = WEB_ROOT + row['data_path']
        if row['build_path'] != "-":
            row['build_path'] = WEB_ROOT + row['build_path']
        if row['survey_path'] != "-":
            row['survey_path'] = WEB_ROOT + row['survey_path']
        cvs_row = [row[title] for title in CSV_TABLE_TITLES]
        result.append('\t'.join(cvs_row))
    return '\n'.join(result)

def checkLink(link):
    """
    Check that a path is present in the website directory
    """
    link_path = path.join(database.repro_root, 'docs', 'website', link)
    return os.path.isfile(link_path)

def writeTemplate(template_path, insert_label, text, out_path):
    template_file = open(template_path, 'rb')
    result = []
    for line in template_file:
        if insert_label in line:
            result.append(text)
        else:
            result.append(line)
    template_file.close()
    out_file = open(out_path, 'w')
    out_file.write(''.join(result))
    out_file.close()

def writeToPath(path, text):
    print "Writing {}".format(path)
    f_write = open(path, 'wb')
    f_write.write(text)
    f_write.close()

if args.generate_website:
    print "Preparing database for publishing to web"
    web_table = []
    for conf_name, records in database.conference_lists.items():
        web_table.extend(webTableRow(record) for record in records)
    html = convertTableToHTML(web_table)
    template_path = path.join(database.repro_root, 
                        'docs', 'website', 'index.template')
    html_out_path = path.join(database.repro_root, 'docs', 'website', 'index.html')
    print "Writing " + html_out_path
    writeTemplate(template_path, '<!--INSERT_TABLE-->', html, html_out_path)
    #Make CSV
    csv_path = path.join(database.repro_root, 'docs', 'website', 'data', 'data.csv')
    csv = convertTableToCSV(web_table)
    writeToPath(csv_path, csv)



# ██████╗ ██╗███████╗     ██████╗██╗  ██╗ █████╗ ██████╗ ████████╗███████╗
# ██╔══██╗██║██╔════╝    ██╔════╝██║  ██║██╔══██╗██╔══██╗╚══██╔══╝██╔════╝
# ██████╔╝██║█████╗      ██║     ███████║███████║██████╔╝   ██║   ███████╗
# ██╔═══╝ ██║██╔══╝      ██║     ██╔══██║██╔══██║██╔══██╗   ██║   ╚════██║
# ██║     ██║███████╗    ╚██████╗██║  ██║██║  ██║██║  ██║   ██║   ███████║
# ╚═╝     ╚═╝╚══════╝     ╚═════╝╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   ╚══════╝

def makePieChartArray(records):
    result = []
    fv_records = filter(isFinishedValidated, records)
    i_records = filter(hasImplementation, fv_records)
    i_wl_records = filter(hasWorkingLink, i_records)
    i_wl_r_records = filter(hasBuildRuns, i_wl_records)
    i_wl_unk_records = filter(hasBuildTodo, i_wl_records)

    result.append("\"no imp\" " + str(len(fv_records) - len(i_records)))
    result.append("\"no/bkn lnk\" " + str(len(i_records) - len(i_wl_records)))
    result.append("\"lnk no runs\" " + str(len(i_wl_records) - len(i_wl_r_records)))
    result.append("\"builds runs\" " + str(len(i_wl_r_records)))
    result.append("\"lnk but ukn build\" " + str(len(i_wl_unk_records))) #Todo: these last two are not mutually exclusive
    return result

# article google unkn/bkn
def makeBarChartstring(records):
    fv_records = filter(isFinishedValidated, records)
    article_link_count = filterCount(hasArticleLink, fv_records)
    google_link_count = filterCount(hasGoogleLink, fv_records)
    remainder_count = len(fv_records) - article_link_count - google_link_count
    return " %s %s %s" % (str(article_link_count), str(google_link_count), str(remainder_count))

def writeListToFile(chart_file, rows):
    print "Write %s" % chart_file
    fp = open(chart_file, 'w')
    fp.write('\n'.join(rows))
    fp.close()

#Todo: Check charts
if args.make_chart_data:
    print "\nMake Charts\n-----------"
    chart_data_path = path.join(args.dir, "webpage","data")
    for conf in database.conference_lists:
        rows = ["CONF:"+conf,]
        rows_greyless = ["CONF:"+conf,]
        rows.extend(makePieChartArray(database.conference_lists[conf]))
        rows_greyless.extend(rows[2:])
        #write files
        chart_file = path.join(chart_data_path, "pie", conf+"-status-pie.txt")
        writeListToFile(chart_file, rows)
        chart_file = path.join(chart_data_path, "pie_greyless", conf+"-status-pie-greyless.txt")
        writeListToFile(chart_file, rows_greyless)
    rows = ["CONF:ALL",]
    rows_greyless = ["CONF:"+conf,]
    rows.extend(makePieChartArray(database.records))
    rows_greyless.extend(rows[2:])
    chart_file = path.join(chart_data_path, "pie", "ALL.txt")
    writeListToFile(chart_file, rows)
    chart_file = path.join(chart_data_path, "pie_greyless", "ALL-greyless.txt")
    writeListToFile(chart_file, rows_greyless)

    all_rows = ["CONF:ALL article google unkn/bkn"]
    for conf in database.conference_lists:
        row = conf + makeBarChartstring(database.conference_lists[conf])
        all_rows.append(row)
        chart_file = path.join(chart_data_path, "bar", conf+"-links-bar.txt")
        writeListToFile(chart_file, ["CONF:"+conf+" article google unkn/bkn", row])
    all_rows.append("ALL " + makeBarChartstring(database.records))
    chart_file = path.join(chart_data_path, "bar", "ALL.txt")
    writeListToFile(chart_file, all_rows)
    



# ████████╗███████╗██╗  ██╗    ███╗   ███╗ █████╗  ██████╗██████╗  ██████╗ ███████╗
# ╚══██╔══╝██╔════╝╚██╗██╔╝    ████╗ ████║██╔══██╗██╔════╝██╔══██╗██╔═══██╗██╔════╝
#    ██║   █████╗   ╚███╔╝     ██╔████╔██║███████║██║     ██████╔╝██║   ██║███████╗
#    ██║   ██╔══╝   ██╔██╗     ██║╚██╔╝██║██╔══██║██║     ██╔══██╗██║   ██║╚════██║
#    ██║   ███████╗██╔╝ ██╗    ██║ ╚═╝ ██║██║  ██║╚██████╗██║  ██║╚██████╔╝███████║
#    ╚═╝   ╚══════╝╚═╝  ╚═╝    ╚═╝     ╚═╝╚═╝  ╚═╝ ╚═════╝╚═╝  ╚═╝ ╚═════╝ ╚══════╝

def makePercent(num, total):
    if total == 0:
        return 0
    else:
        #print "{}/{} = {} -> {}".format(num,total,num*100/total,round(num*100/total, 1))
        return round(num*100/total, 1)

tex_title_main = [
    'Total',
    'WithImplementation',
    #'WithImplementationPercentOfTotal',
    'WithNoImplementation',
    #'WithNoImplementationPercentOfTotal',
    'WithHardware',
    #'WithHardwarePercentOfTotal',
    'WithAvailableCode',
    #'WithAvailableCodePercentOfImplementation',
    'WithNoAvailableCode',
    #'WithNoAvailableCodePercentOfImplementation',
    'WithArticleCode',
    #'WithArticleCodePercentOfImplementation',
    #'WithArticleCodePercentOfAvailableCode',
    'WithGoogleCode',
    #'WithGoogleCodePercentOfImplementation',
    #'WithGoogleCodePercentOfAvailableCode',
    'WithEmailCode',
    #'WithEmailCodePercentOfImplementation',
    #'WithEmailCodePercentOfAvailableCode'
    'BackedByCode'
    ]

def TexRowMain(records, prefix):
    p = prefix
    #Use ordered dict, so they will easily go into rows of a table
    r = OrderedDict()
    fv_records = filter(isFinishedValidated, records)
    fv_i_records = filter(hasImplementation, fv_records)
    total = len(fv_records)
    n_available = filterCount(hasCode, fv_i_records)
    n_implementation = len(fv_i_records)
    n_hardware = filterCount(hasHardware, fv_records)

    r[p+'Total'] = total
    r[p+'WithImplementation'] = len(fv_i_records)
    #r[p+'WithImplementationPercentOfTotal'] = makePercent(n_implementation, total) 
    r[p+'WithNoImplementation'] = total - n_implementation-n_hardware
    #r[p+'WithNoImplementationPercentOfTotal'] = makePercent(total - n_implementation-n_hardware, total) 
    r[p+'WithHardware'] = n_hardware
    #r[p+'WithHardwarePercentOfTotal'] = makePercent(n_hardware, total) 
    r[p+'WithAvailableCode'] = n_available
    #r[p+'WithAvailableCodePercentOfImplementation'] = makePercent(n_available, n_implementation)
    r[p+'WithNoAvailableCode'] = n_implementation-n_available
    #r[p+'WithNoAvailableCodePercentOfImplementation'] = makePercent(n_implementation-n_available, n_implementation)
    n_article = filterCount(hasArticleLink, fv_i_records)
    r[p+'WithArticleCode'] = n_article
    #r[p+'WithArticleCodePercentOfImplementation'] = makePercent(n_article, n_implementation)
    #r[p+'WithArticleCodePercentOfAvailableCode'] = makePercent(n_article, n_available)
    n_google = filterCount(hasGoogleLink, fv_i_records)
    r[p+'WithGoogleCode'] = n_google
    #r[p+'WithGoogleCodePercentOfImplementation'] = makePercent(n_google, n_implementation)
    #r[p+'WithGoogleCodePercentOfAvailableCode'] = makePercent(n_google, n_available)
    n_email = filterCount(hasEmail1Yes, fv_i_records)
    r[p+'WithEmailCode'] = n_email
    #r[p+'WithEmailCodePercentOfImplementation'] = makePercent(n_email, n_implementation)
    #r[p+'WithEmailCodePercentOfAvailableCode'] = makePercent(n_email, n_available)
    r[p+'BackedByCode'] = n_implementation - filterCount(hasEmailNeededNoRequest, fv_i_records)
    #pp.pprint(r.items())
    return r
    
tex_title_build = [
    'BuildAttempted',
    # 'BuildAttemptedPercentOfImplementation',
    # 'BuildAttemptedPercentOfAvailableCode',
    'BuildWeCompile',
    'BuildWeCompileInThirtyMinutes',
    'BuildWeCompileInInfiniteMinutes',
    # 'BuildCompilesPercentOfAttempted',
    'BuildWeFailCompileAuthorSaysCompiles',
    'BuildDoesNotCompile',
    'BuildWeAndAuthorFailCompile',
    # 'BuildDoesNotCompilePercentOfAttempted',
    'BuildRuns',
    # 'BuildRunsPercentOfAttempted',
    'BuildCompilesDoesNotRun',
    #'BuildCompilesDoesNotRunPercentOfAttempted',
    'BuildOnlineRuns',
    # 'BuildOnlineRunsPercentOfAttempted',
    'BuildOnlineDoesNotRun',
    'BuildOnlineCompiles',
    # 'BuildOnlineDoesNotRunPercentOfAttempted',
    'BuildWeOrAuthorCompileAndCorrectVersionExists',
    'BuildSuccess',
    # 'BuildSuccessPercentOfAttempted',
    # 'BuildSuccessPercentOfImplementation'
]

def TexRowBuild(records, prefix):
    p = prefix
    r = OrderedDict()
    fv_records = filter(isFinishedValidated, records)
    fv_i_records = filter(hasImplementation, fv_records)
    n_implementation = len(fv_i_records)
    bf_records = filter(isBuildFinished, fv_i_records)
    n_attempted = len(bf_records)
    n_available = filterCount(hasCode, fv_i_records)

    r[p+'BuildAttempted'] = n_attempted
    #r[p+'BuildAttemptedPercentOfImplementation'] = makePercent(n_attempted, n_implementation)
    #r[p+'BuildAttemptedPercentOfAvailableCode'] = makePercent(n_attempted, n_available)
    downloadeds = filter(hasBuildDownloaded, bf_records)
    print("{}: {} vs {}".format(p, n_attempted, len(downloadeds)))
    #r[p+'BuildDownloads'] = n_downloads
    #r[p+'BuildDownloadsPercentOfAttempted'] = makePercent(n_downloads, n_attempted)
    compiles = filter(hasBuildCompiles, downloadeds)
    n_online_run = filterCount(hasBuildOnlineRuns, bf_records)
    n_online_no_run = filterCount(hasBuildOnlineNoRuns, bf_records)
    n_online_compiles = n_online_run + n_online_no_run
    compiles_with_infinite = filter(hasBuildVerifiedFinished, compiles)
    r[p+'BuildWeCompile'] = len(compiles) + n_online_compiles
    r[p+'BuildWeCompileInThirtyMinutes'] = len(compiles) + n_online_compiles - len(compiles_with_infinite)
    r[p+'BuildWeCompileInInfiniteMinutes'] = len(compiles_with_infinite)
    #r[p+'BuildCompilesPercentOfAttempted'] = makePercent(len(compiles), n_attempted)
    r[p+'BuildWeFailCompileAuthorSaysCompiles'] = filterCount(hasBuildWeFailCompileAuthorSaysCompilesOrNa, downloadeds)
    r[p+'BuildDoesNotCompile'] = len(downloadeds) - len(compiles) #number that compiles doesn't include online compiles
    r[p+'BuildWeAndAuthorFailCompile'] = len(downloadeds) - len(compiles) - filterCount(hasBuildWeFailCompileAuthorSaysCompilesOrNa, downloadeds)
    #r[p+'BuildDoesNotCompilePercentOfAttempted'] = makePercent(len(downloadeds)-len(compiles), n_attempted)
    n_runs = filterCount(hasBuildRuns, compiles)
    r[p+'BuildRuns'] = n_runs
    #r[p+'BuildRunsPercentOfAttempted'] = makePercent(n_runs, n_attempted)
    r[p+'BuildCompilesDoesNotRun'] = len(compiles)-n_runs
    #r[p+'BuildCompilesDoesNotRunPercentOfAttempted'] = makePercent(len(compiles)-n_runs, n_attempted)
    r[p+'BuildOnlineRuns'] = n_online_run
    #r[p+'BuildOnlineRunsPercentOfAttempted'] = makePercent(n_online_run, n_attempted)
    r[p+'BuildOnlineDoesNotRun'] = n_online_no_run
    r[p+'BuildOnlineCompiles'] = n_online_no_run + n_online_run
    #r[p+'BuildOnlineDoesNotRunPercentOfAttempted'] = makePercent(n_online_no_run, n_attempted)
    n_success = n_runs + n_online_run
    r[p+'BuildWeOrAuthorCompileAndCorrectVersionExists'] = filterCount(hasBuildWeOrAuthorCompileAndCorrectVersionExists, downloadeds)
    r[p+'BuildSuccess'] = n_success
    #r[p+'BuildSuccessPercentOfAttempted'] = makePercent(n_success, n_attempted)
    #r[p+'BuildSuccessPercentOfImplementation'] = makePercent(n_success, n_implementation)
    return r

tex_title_email = [
    'EmailNeeded',
    'EmailSent',
    'EmailSentPercentOfNeeded',
    'EmailNeededNotSent',
    #'EmailNeededNotSentPercentOfNeeded',
    'EmailGotReply',
    #'EmailGotReplyPercentOfSent',
    'EmailWithoutReply',
    #'EmailWithoutReplyPercentOfSent',
    'EmailGotReplyYes',
    #'EmailGotReplyYesPercentOfSent',
    #'EmailGotReplyYesPercentOfReply',
    'EmailGotReplyNo',
    #'EmailGotReplyNoPercentOfSent',
    #'EmailGotReplyNoPercentOfReply'
    'SurveyPapersForWhichWeSentRequests',
    'SurveyPapersForWhichWeGotResponse',
    'SurveyPapersForWhichAuthorsSayPractical',
    'SurveyPapersForWhichAuthorsSayPublished',
    'SurveyPapersForWhichAuthorsSayNotPublished',
    'SurveyPapersForWhichAuthorsGaveVersionResponse',
    'SurveyPapersForWhichAuthorsSayCorrectVersionExists',
    'SurveyPapersForWhichAuthorsSayCorrectVersionWasPublished',
    'SurveyPapersForWhichAuthorsSayCorrectVersionWasNotPublishedButIsAvailable',
    'SurveyPapersForWhichAuthorsSayCorrectVersionNotAvailable',
    ]

def TexRowEmail(records, prefix):
    p = prefix
    r = OrderedDict()
    fv_records = filter(isFinishedValidated, records)
    fv_i_records = filter(hasImplementation, fv_records)
    e_needed = filter(hasEmailNeeded, fv_i_records)
    e_sent_records = filter(hasEmailRequest1, e_needed)
    n_e_sent = len(e_sent_records)
    n_reply = filterCount(hasEmailResponse1, e_sent_records)

    r[p+'EmailNeeded'] = len(e_needed)
    r[p+'EmailSent'] = n_e_sent
    #r[p+'EmailSentPercentOfNeeded'] = makePercent(n_e_sent, len(e_needed))
    r[p+'EmailNeededNotSent'] = filterCount(hasEmailNeededNoRequest, fv_i_records)
    #r[p+'EmailNeededNotSentPercentOfNeeded'] = makePercent(len(e_needed)-n_e_sent, len(e_needed))
    r[p+'EmailGotReply'] = n_reply
    #r[p+'EmailGotReplyPercentOfSent'] = makePercent(n_reply, n_e_sent)
    r[p+'EmailWithoutReply'] = n_e_sent - n_reply
    #r[p+'EmailWithoutReplyPercentOfSent'] = makePercent(n_e_sent - n_reply, n_e_sent)
    n_reply_yes = filterCount(hasEmail1Yes, e_sent_records)
    r[p+'EmailGotReplyYes'] = n_reply_yes
    #r[p+'EmailGotReplyYesPercentOfSent'] =  makePercent(n_reply_yes, n_e_sent)
    #r[p+'EmailGotReplyYesPercentOfReply'] =  makePercent(n_reply_yes, n_reply)
    n_reply_no = filterCount(hasEmail1No, e_sent_records)
    r[p+'EmailGotReplyNo'] = n_reply_no
    #r[p+'EmailGotReplyNoPercentOfSent'] =  makePercent(n_reply_no, n_e_sent)
    #r[p+'EmailGotReplyNoPercentOfReply'] =  makePercent(n_reply_no, n_reply)

    got_survey_records = filter(wasSentSurvey, records)
    replied_survey_records = filter(hasSurveyResult, records)


    r[p+'SurveyPapersForWhichWeSentRequests'] = len(got_survey_records)
    r[p+'SurveyPapersForWhichWeGotResponse'] = len(replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsSayPractical'] = filterCount(hasSurveyCodeExists, replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsSayPublished'] = filterCount(hasSurveyPublishedYes, replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsSayNotPublished'] = filterCount(hasSurveyPublishedNo, replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsGaveVersionResponse'] = filterCount(hasSurverVersionResponse, replied_survey_records)  
    r[p+'SurveyPapersForWhichAuthorsSayCorrectVersionExists'] = filterCount(hasSurveyCorrectVersionExists, replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsSayCorrectVersionWasPublished'] = filterCount(hasSurveyCorrectVersionPublished, replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsSayCorrectVersionWasNotPublishedButIsAvailable'] = filterCount(hasSurveyCorrectVersionUnpublished, replied_survey_records)
    r[p+'SurveyPapersForWhichAuthorsSayCorrectVersionNotAvailable'] = filterCount(hasSurveyCorrectVersionNonextant, replied_survey_records)
    

    return r

ALL_CONFERENCES = ["asplos12", "ccs12", "oopsla12", "osdi12",
                "pldi12", "sigmod12", "sosp11", "vldb12"]
ALL_JOURNALS = ["taco9", "tissec15", "tocs30", "tods37", 
                   "toplas34"]

def getRowsFromFunction(func):
    rows = []
    journals = []
    conferences = []
    for conf in database.conference_lists:
        conf_macro_name = ''.join(i for i in conf if not i.isdigit())
        conf_macro_name = conf_macro_name.capitalize()
        row = func(database.conference_lists[conf], conf_macro_name)
        rows.append((conf,row))
        if conf in ALL_JOURNALS:
            journals.extend(database.conference_lists[conf])
        if conf in ALL_CONFERENCES:
            conferences.extend(database.conference_lists[conf])
    row = func(journals, 'Journals')
    rows.append(('Journals', row))
    row = func(conferences, 'Conferences')
    rows.append(('Conferences', row))
    row = func(filter(hasNoCommercialEffort, database.records), 'CommercialNone')
    rows.append(('CommercialNone', row))
    row = func(filter(hasPartCommercialEffort, database.records), 'CommercialPart')
    rows.append(('CommercialPart', row))
    row = func(filter(hasFullCommercialEffort, database.records), 'CommercialFull')
    rows.append(('CommercialFull', row))
    row = func(filter(hasNoNSFGrant, database.records), 'NoNSF')
    rows.append(('NoNSF', row))
    row = func(filter(hasNSFGrant, database.records), 'NSF')
    rows.append(('NSF', row))
    row = func(database.records, 'Total')
    rows.append(('Total', row))
    return rows

def formatMacro(title, value):
    xspace = "\\xspace"
    percentsign = "\\percentsign"
    if "DATA" in title:
        xspace = ""
        percentsign = ""
    if "Percent" in title:
        return "\\newcommand{\\"+title+"}{"+str(value)+percentsign+xspace+"}\n"
    else:
        return "\\newcommand{\\"+title+"}{"+str(value)+xspace+"}\n"

def makeTitleMacros(titles):
    return ["\\newcommand{\\"+t+"TITLE}{\\RaggedRight "+addSpacesToCamal(t)+"}\n" for t in titles]


def addSpacesToCamals(strings):
    return [addSpacesToCamal(string) for string in strings]

def addSpacesToCamal(string):
    new_string = []
    is_first = True
    for c in string:
        if c.isupper() and not is_first:
            new_string.append(' '+c)
        else:
            new_string.append(c)
            is_first = False
    return ''.join(new_string).replace('Of', 'of').replace('Percent', '\%')

def makeMacrosFromRows(rows):
    lines = []
    for group, row in rows:
        for title, value in row.items():
            lines.append(formatMacro(title, value))
            lines.append(formatMacro(title+"DATA", value))
    return lines

def makeTexTable(selected_rows, selected_cols, table_title):
    #FORMATTED_CONFERENCE[conf]
    #Get column information
    table_titles = ['Group']
    column_number = 1;
    columns = []
    for col_title in selected_cols:
        assert col_title in col_titles, col_title+" not found when making table "+table_title
        ii = col_titles.index(col_title)
        table_titles.append(
            "\\colref{"+str(column_number)+"} \\"+col_titles[ii]+"TITLE")
        column_number = column_number+1
        columns.append(ii)
    #Create latex code for table
    column_justify = 'lp{#1}'+''.join('p{#1}' for i in range(len(table_titles)))
    latex_table = ["\\newcommand{\\"+table_title+"}[2]{", "\\begin{#2}"]
    latex_table.append("\\begin{tabular}{"+column_justify+"}\\toprule")
    latex_table.append("   " + ' & '.join(table_titles) + "\\\\\midrule")
    for row_title in selected_rows:
        if row_title == "hline":
            latex_table[-1] = latex_table[-1]+"\\hline"
        elif not row_title in row_titles:
            assert False, row_title+" not found when making table "+table_title
        else:
            ii = row_titles.index(row_title)
            if row_title in FORMATTED_CONFERENCE:
                row = [FORMATTED_CONFERENCE[row_title]]
            else:
                row = [addSpacesToCamal(row_title)]
            row.extend(["\\"+complete_macro_table[ii][jj] for jj in columns])
            latex_table.append("   " + (' & '.join(row)) + "\\\\")
    latex_table[-1] = latex_table[-1]+"\\bottomrule"
    latex_table.extend(["\\end{tabular}", "\end{#2}", "}"])
    return '\n'.join(latex_table)

if args.update_latex or args.update_latex_table:
    tex_rows_main = getRowsFromFunction(TexRowMain)
    tex_rows_build = getRowsFromFunction(TexRowBuild)
    tex_rows_email = getRowsFromFunction(TexRowEmail)
    col_titles = []
    col_titles.extend(tex_title_main)
    col_titles.extend(tex_title_build)
    col_titles.extend(tex_title_email)

if args.update_latex:
    lines = ["%Autogenerated Macros\n"]
    lines.extend(makeMacrosFromRows(tex_rows_main))
    lines.extend(makeMacrosFromRows(tex_rows_build))
    lines.extend(makeMacrosFromRows(tex_rows_email))
    lines.extend(makeTitleMacros(col_titles))
    text = ''.join(lines)
    #writeToPath(path.join(args.dir, "docs","tr","data","resultmacros.tex"), text)
    writeToPath(path.join(args.dir, "docs","tr2","data","resultmacros.tex"), text)
    writeToPath(path.join(args.dir, "docs","cacm2","data","resultmacros.tex"), text)

#What to include in the latex tables
all_groups = ['tissec15', 'taco9', 'tods37', 'osdi12', 'sigmod12', 'asplos12', 'oopsla12', 'toplas34', 'pldi12', 'sosp11', 'vldb12', 'tocs30', 'ccs12', 'hline', 'Journals', 'Conferences', 'hline', 'CommercialNone', 'CommercialPart', 'CommercialFull', 'hline', 'NoNSF', 'NSF', 'hline', 'Total']
table_a_columns = ['Total', 'WithImplementation', 'WithImplementationPercentOfTotal', 'WithNoImplementation', 'WithNoImplementationPercentOfTotal', 'WithHardware','WithAvailableCode', 'WithAvailableCodePercentOfImplementation']
table_b_columns = ['WithArticleCode', 'WithArticleCodePercentOfImplementation', 'WithArticleCodePercentOfAvailableCode', 'WithGoogleCode', 'WithGoogleCodePercentOfImplementation', 'WithGoogleCodePercentOfAvailableCode', 'WithEmailCode', 'WithEmailCodePercentOfImplementation', 'WithEmailCodePercentOfAvailableCode']
table_c_columns = ['BuildAttempted', 'BuildAttemptedPercentOfImplementation', 'BuildAttemptedPercentOfAvailableCode', 'BuildCompiles', 'BuildCompilesPercentOfAttempted', 'BuildRuns', 'BuildRunsPercentOfAttempted', 'BuildOnlineRuns', 'BuildOnlineRunsPercentOfAttempted', 'BuildSuccess', 'BuildSuccessPercentOfAttempted']
table_d_columns = ['EmailNeeded', 'EmailSent', 'EmailSentPercentOfNeeded', 'EmailNeededNotSent', 'EmailGotReply', 'EmailGotReplyPercentOfSent', 'EmailWithoutReply', 'EmailWithoutReplyPercentOfSent']
table_e_columns = ['EmailGotReplyYes', 'EmailGotReplyYesPercentOfSent', 'EmailGotReplyYesPercentOfReply', 'EmailGotReplyNo', 'EmailGotReplyNoPercentOfSent', 'EmailGotReplyNoPercentOfReply']
summary_groups = ['tissec15', 'taco9', 'tods37', 'osdi12', 'sigmod12', 'asplos12', 'oopsla12', 'toplas34', 'pldi12', 'sosp11', 'vldb12', 'tocs30', 'ccs12', 'hline', 'Journals', 'Conferences', 'hline', 'NSF', 'hline', 'Total']
summary_columns = ['Total', 'WithImplementation', 'WithAvailableCodePercentOfImplementation', 'BuildAttempted', 'BuildCompilesPercentOfAttempted', 'BuildRunsPercentOfAttempted', 'EmailSent', 'EmailGotReplyPercentOfSent', 'EmailGotReplyYesPercentOfSent']
if args.update_latex_table:
    #Restructure macros into a large table
    #This is the result of refactoring
    row_titles = []
    complete_macro_table = []
    for i in range(len(tex_rows_main)):
        title = tex_rows_main[i][0]
        assert title == tex_rows_build[i][0] and title == tex_rows_email[i][0], "section missmatch"
        row_titles.append(title)
        current_row = []
        complete_macro_table.append(current_row)
        for pair in tex_rows_main[i][1].items():
            #current_row.append(pair[1])
            current_row.append(pair[0])
        for pair in tex_rows_build[i][1].items():
            #current_row.append(pair[1])
            current_row.append(pair[0])
        for pair in tex_rows_email[i][1].items():
            #current_row.append(pair[1])
            current_row.append(pair[0])

    lines = []
    lines.append(makeTexTable(summary_groups,summary_columns, "SummaryTable"))
    lines.append(makeTexTable(all_groups,table_a_columns, "ResultTableA"))
    lines.append(makeTexTable(all_groups,table_b_columns, "ResultTableB"))
    lines.append(makeTexTable(all_groups,table_c_columns, "ResultTableC"))
    lines.append(makeTexTable(all_groups,table_d_columns, "ResultTableD"))
    lines.append(makeTexTable(all_groups,table_e_columns, "ResultTableE"))

    text = '\n'.join(lines)
    writeToPath(path.join(args.dir, "docs","tr2", "data", "resulttables.tex"), text)
    writeToPath(path.join(args.dir, "docs","cacm2", "data", "resulttables.tex"), text)


# ███╗   ███╗██╗███████╗ ██████╗     ██████╗ ██╗   ██╗████████╗
# ████╗ ████║██║██╔════╝██╔════╝    ██╔═══██╗██║   ██║╚══██╔══╝
# ██╔████╔██║██║███████╗██║         ██║   ██║██║   ██║   ██║   
# ██║╚██╔╝██║██║╚════██║██║         ██║   ██║██║   ██║   ██║   
# ██║ ╚═╝ ██║██║███████║╚██████╗    ╚██████╔╝╚██████╔╝   ██║   
# ╚═╝     ╚═╝╚═╝╚══════╝ ╚═════╝     ╚═════╝  ╚═════╝    ╚═╝   

if args.email_name_list:
    print DIVIDER
    for record in database.records:
        if record.batch == 2 and record.EMAIL.STATUS.needed:
            print record.path
            print record.AUTHOR.NAMES
            print record.AUTHOR.EMAIL_REAL
            print DIVIDER

if args.not_finished_list:
    print "Not finished or not validated:"
    for record in database.records:
        if not isFinishedValidated(record):
            print record.path

if args.not_build_verified:
    print "Not build unresolved:"
    for record in database.records:
        if hasBuildVerifiedUnresolved(record) :
            print record.path

if args.build_not_finished_list:
    print "Build unfinished:"
    print DIVIDER
    for record in database.records:
        if hasBuildTodo(record):
            print record.path
            if not hasEmail1Yes(record) and not isBuildStarted(record):
                print database.printRecord(record)
            else:
                print "BUILD:STATUS " + str(record.BUILD.STATUS)
                if record.EMAIL1.CODE_AVAILABLE.yes:
                    print "From email"
            print DIVIDER

if args.recieved_email_list:
    for record in database.records:
        if record.EMAIL.STATUS.request_1:
            for email in record.AUTHOR.EMAIL_REAL.value:
                print email

if False and args.list_special:
    for record in database.records:
        if record.BUILD.STATUS.finished and not record.BUILD.STATUS.downloaded:
            print DIVIDER
            print record.path
            print DIVIDER
            print database.printRecord(record)

if False and args.list_special:
    for record in database.records:
        if record.EMAIL.STATUS.request_1 and record.batch == 1:
            print record.path

if False and args.list_special:
    comment_fields = ["CLASSIFICATION_COMMENT","SAME_VERSION_COMMENT","BUILD_DIFFICULTY_COMMENT","BUILD_COMMENT","PUBLIC_COMMENT","ANONYMOUS_COMMENT"]
    for record in database.records:
        if record.surveys:
            for survey in record.surveys:
                for field in comment_fields:
                    if '-' in survey.__dict__[field].value:
                        print DIVIDER
                        print field
                        print survey.__dict__[field].value #.replace(' - ', '\\n')

if args.list_special:
    for record in database.records:
        if not (record.COMMENT.CORRECTION.value or record.COMMENT.RESPONSE.value):
            continue
        print ""
        print record.path
        print DIVIDER
        if record.COMMENT.CORRECTION.value:
            print "Correction:"
            print record.COMMENT.CORRECTION.value
        if record.COMMENT.RESPONSE.value:
            print "Response:"
            print record.COMMENT.RESPONSE.value

if args.missing_build_error:
    print "Missing Build Error:"
    print DIVIDER
    for record in database.records:
        if isBuildFinished(record) and not (hasBuildRuns(record) or hasBuildOnlineRuns(record)) \
            and (record.BUILD.ERROR_COMMENT.NONE or record.BUILD.ERROR_COMMENT.not_needed):
            print record.path
            print "BUILD:STATUS " + str(record.BUILD.STATUS)
            print "BUILD:ERROR_COMMENT " + str(record.BUILD.ERROR_COMMENT)
            print "BUILD:COMMENT " + str(record.BUILD.COMMENT)
            print DIVIDER
    print "Unneeded Build Error:"
    for record in database.records:
        if not (record.BUILD.ERROR_COMMENT.NONE or record.BUILD.ERROR_COMMENT.not_needed) \
                and (not isBuildFinished(record) or hasBuildRuns(record) or hasBuildOnlineRuns(record)):
            print record.path
            print "BUILD:STATUS " + str(record.BUILD.STATUS)
            print "BUILD:ERROR_COMMENT " + str(record.BUILD.ERROR_COMMENT)
            print "BUILD:COMMENT " + str(record.BUILD.COMMENT)
            print DIVIDER

if args.short_build:
    count = 0
    print "Short build time:"
    print DIVIDER
    for record in database.records:
        if isBuildFinished(record) and not (hasBuildRuns(record) or hasBuildOnlineRuns(record)) \
            and (record.BUILD.ANALYSIS_TIME.value<30):
            count = count + 1
            print record.path
            print "BUILD:ANALYSIS_TIME " + str(record.BUILD.ANALYSIS_TIME)
            print "BUILD:ANALYSIS_BY " + str(record.BUILD.ANALYSIS_BY)
            print "BUILD:STATUS " + str(record.BUILD.STATUS)
            print "BUILD:COMMENT " + str(record.BUILD.COMMENT)
            print DIVIDER
    print "Counted: " + str(count)


if args.email_address_count:
    total = 0
    print "Email address count"
    for record in database.records:
        total += len(record.AUTHOR.EMAIL_REAL.value)
        print "{:<3} {}".format(len(record.AUTHOR.EMAIL_REAL.value), record.path)
    print("Total emails to send: {}".format(total))



USER_CODES = {'a':"Alex", 'p':"Pruthvi", 'c':"Patrick", 'd':"David", '-':"?"}
if args.compare_build_verification_needed:
    build_verification_file = open(os.path.join(database.repro_root, "logs",
            "build_verification_needed.txt"))
    is_in_header = True
    build_error = {"Alex":[], "Pruthvi":[], "Patrick":[], "David":[]}
    time_missing = {"Alex":[], "Pruthvi":[], "Patrick":[], "David":[]}
    for line in build_verification_file:
        if is_in_header:
            if "___" in line:
                is_in_header = False
            continue
        results = line.split()
        record_name = os.path.split(results[0])
        if "vldb12_new" in record_name[0]:
            record_name = ("vldb12", record_name[1])
        try:
            record = database.conferences[record_name[0]][record_name[1]]
        except:
            print results[0]
            print "Missing from database"
            continue
        print("")
        print(DIVIDER)
        print(record.dir)
        #Done
        if not results[2][3] == 'D':
            print("Not done")
            continue
        #Online
        if results[1][2] == 'o':
            print(record.BUILD.VERIFY_STATUS.value)
            print("Online")
            continue
        #Excluded
        if results[1][2] == 'x':
            #print(record.BUILD.VERIFY_STATUS.value)
            print("Excluded")
            continue
        #Verified
        if not results[1][2] == 'v':
            print("Not verified")
            continue
        verifier = USER_CODES[results[1][1]]
        compiles = results[1][3] == 'c'
        runs = results[1][4] == 'r'

        if verifier == '?':
            print "unknown verifier"
        elif not record.BUILD.VERIFY_BY.value[verifier]:
            found = False
            for name, val in record.BUILD.VERIFY_BY.value.items():
                if val:
                    print "data.txt has {} not {}".format(name, verifier)
                    found = True
            if not found:
                print "data.txt has no verifier. Expected {}".format(verifier)

        if not hasBuildVerifiedFinished(record):
            print("Not marked finished")

        if compiles and not hasBuildCompiles(record):
            print("Expected compiles in data.txt")
        if not compiles and hasBuildCompiles(record):
            print("Expected compiles in verification log.")

        if runs and not hasBuildRuns(record):
            print("Expected runs in data.txt")
        if not runs and hasBuildRuns(record):
            print("Expected runs in verification log.")


        if not compiles:
            build_error[verifier].append(record.path)
        if not record.BUILD.VERIFY_TIME.has_value:
            time_missing[verifier].append(record.path)

    # for name, records in build_error.items():
    #     print("")
    #     print(name)
    #     print(DIVIDER)
    #     print("\n".join(records))
    for name, records in time_missing.items():
        print("")
        print(name)
        print(DIVIDER)
        print("\n".join(records))
#!/bin/bash 

#File:		awk_Refactor.bash
#Author:	Akash Shankaran
#Purpose:	Formats the data.txt -
#		1. Removes the BUILD_VERIFY lines (3 lines)
#		2. adds a tag for EMAILS "not found"
#		3. add the field ARTICLE:NSF-SUPPORT[none or number]:
#		4. add the NSF Grant value 
#		5. add the AUTHOR:NAMES[list of first_last] fields
#Usage:		sudo bash ./awk_Refactor.bash convert_list 


#run AWK script
if [ "$1" = "convert_list" ]; then
    arg_list="toplas34 "
else
    arg_list="$@"
fi

for arg in $arg_list
do
	tput setaf 5
	echo "In $arg"
	tput setaf 7
	directories=$(find ./../$arg -mindepth 1 -maxdepth 1 -type d)
	
	for D in $directories; do
		tput setaf 4
		echo "Refactoring $D/data.txt"
		tput setaf 7

		#create a new file
		touch $D/data.txt.new

awk -W source '{
if ( $1 ~ /VERIFY_BUILD.*/ )  
next;
if ( $1 ~ /ARTICLE:LINK*/ )
{
	t = $0;
	next;
}
if ( NR == 8)
{
	print (t);
}
	

if ( $1 ~ /EMAIL:STATUS.*/ )
{
split($1, a,"/not_needed/");
$1=a[1]",not_found"a[2];
}

if (NR ==5 && ($0 ~ /NSF*/ || $0 ~ /nsf*/ || $0 ~ /_ational _cience _oundation/))
{
	num=1;
	for(i=1;i<=NF;i++)
	{
		if($i ~ /[A-Z]-[0-9]/)
		{
		c[num]=$i",";
		num++;
		}
		else if( $i ~ /([A-Z]| )*-[0-9]/ )
		{
		c[num]=$i$(i+1)",";
		num++;
		}
		else if( $i ~ /[A-Z]-( |[0-9])*/ )
		{
		c[num]=$i$(i+1)",";
		num++;
		}
		else if($i ~ /[0-9]/)
		{
		c[num]=$i",";
		num++;
		}
	}
}

if ( NR==6 )
{	
	printf("ARTICLE:NSF-SUPPORT[none or number] ");

	if( length(c) > 0 )
	{
		for( i=1;i<=length(c);i++)
		{
			printf(c[i]);
		}
	}
	else
		printf "none";	
	printf "\n";	
}
if ( NR==12)
{
	print "AUTHOR:NAMES[list of first_last] ";
}
print $0;	
}' $D/data.txt > $D/data.txt.new

#copy temp file into the original data.txt file
cp $D/data.txt.new $D/data.txt
#remove the temp file
rm -f $D/data.txt.new
done
done

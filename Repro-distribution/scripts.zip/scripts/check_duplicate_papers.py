#! /usr/bin/python
"""
check_duplicate_papers
A script to go through each pair of papers to find those that share authors,
and returns a list to be checked by hand
"""

import argparse
from itertools import combinations
from repro_loader import *

def find_similar_pairs(database):
    DIVIDER = "-" * 20
    all_pairs = combinations(database.records, 2)
    print("{} records".format(len(database.records)))
    count = 0
    candidates = []
    for pair in all_pairs:
        if pair[0].dir == pair[1].dir:
            continue
        count += 1
        matches = 0
        authors = [pair[0].AUTHOR.NAMES.value, pair[1].AUTHOR.NAMES.value]
        for author in authors[0]:
            if author in authors[1]:
                matches += 1
        max_matches = min(len(authors[0]), len(authors[1]))
        if matches >= 1 and max_matches <= 2:
            candidates.append(pair)
        elif max_matches - matches < 2 and max_matches > 2:
            candidates.append(pair)
        elif matches >= 3:
            candidates.append(pair)
    print("{} combinations".format(count))
    for pair in candidates:
        print("")
        print("okular {}/paper.pdf {}/paper.pdf".format(pair[0].dir, pair[1].dir))
        print(DIVIDER)
        print(pair[0].dir)
        print(pair[0].AUTHOR.NAMES)
        print(DIVIDER)
        print(pair[1].dir)
        print(pair[1].AUTHOR.NAMES)
        print(DIVIDER)



def main():
    parser = argparse.ArgumentParser(description='create email scripts for distributing the survey')
    parser.add_argument("dir", help="Root directory of the reproducibility database.")

    args = parser.parse_args()
    print("\nLoading database from {}".format(args.dir))
    database = repro_database(args.dir, ["all"])
    find_similar_pairs(database)



if __name__ == "__main__":
    main()